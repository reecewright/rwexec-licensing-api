<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Settings {

    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'restore_booking_form_branding_if_needed' ), 5 );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );

        $groups = array(
            'rwexec_reservations_general_settings',
            'rwexec_reservations_availability_settings',
            'rwexec_reservations_booking_form_settings',
            'rwexec_reservations_booking_form_styling_settings',
            'rwexec_reservations_email_settings',
        );
        foreach ( $groups as $group ) {
            add_filter( 'option_page_capability_' . $group, array( __CLASS__, 'settings_capability' ) );
        }

        foreach ( RWExec_Reservations_Email::template_types() as $type => $config ) {
            add_filter( 'option_page_capability_rwexec_reservations_email_template_' . $type, array( __CLASS__, 'settings_capability' ) );
        }
    }

    public static function booking_form_color_defaults(): array {
        return array(
            'rwexec_form_background_color' => '#ffffff',
            'rwexec_form_border_color' => '#e2e8f0',
            'rwexec_form_label_color' => '#1e293b',
            'rwexec_form_required_color' => '#dc2626',
            'rwexec_form_heading_color' => '#1e293b',
            'rwexec_form_subheading_color' => '#64748b',
            'rwexec_form_field_background_color' => '#ffffff',
            'rwexec_form_field_border_color' => '#cbd5e1',
            'rwexec_form_field_text_color' => '#1e293b',
            'rwexec_form_placeholder_color' => '#94a3b8',
            'rwexec_form_focus_color' => '#1e293b',
            'rwexec_form_button_background_color' => '#1e293b',
            'rwexec_form_button_text_color' => '#ffffff',
            'rwexec_form_button_hover_background_color' => '#334155',
            'rwexec_form_button_hover_text_color' => '#ffffff',
            'rwexec_form_consent_background_color' => '#f8fafc',
            'rwexec_form_consent_border_color' => '#e2e8f0',
            'rwexec_form_consent_text_color' => '#1e293b',
            'rwexec_form_consent_muted_color' => '#64748b',
        );
    }

    /**
     * Repairs the known styling-save regression that could persist every colour
     * as black. Only runs when the saved palette clearly matches that broken
     * state, so intentional individual black colour choices are preserved.
     */
    public static function restore_booking_form_branding_if_needed() {
        if ( '1' === (string) get_option( 'rwexec_form_brand_palette_repaired_v1', '0' ) ) {
            return;
        }

        $defaults = self::booking_form_color_defaults();
        $saved = 0;
        $black = 0;
        foreach ( array_keys( $defaults ) as $option ) {
            $value = strtolower( trim( (string) get_option( $option, '' ) ) );
            if ( '' !== $value ) {
                $saved++;
                if ( in_array( $value, array( '#000', '#000000' ), true ) ) {
                    $black++;
                }
            }
        }

        // The bug reset virtually the whole palette to black. Avoid touching a
        // normal customised palette where black may have been chosen on purpose.
        if ( $saved >= 8 && $black >= max( 8, $saved - 2 ) ) {
            foreach ( $defaults as $option => $value ) {
                update_option( $option, $value );
            }
        }

        update_option( 'rwexec_form_brand_palette_repaired_v1', '1', false );
    }

    public static function settings_capability(): string {
        return RWExec_Reservations_Staff::ADMIN_CAPABILITY;
    }

    public static function sanitize_online_capacity( $value ): int {
        if ( ! RWExec_Reservations_License::is_premium() ) {
            return max( 1, absint( get_option( 'rwexec_online_capacity', 45 ) ) );
        }

        $online = max( 1, absint( $value ) );

        // General settings posts both values together. Prefer the submitted
        // total so lowering venue capacity cannot leave an invalid reservation limit.
        $submitted_total = isset( $_POST['rwexec_total_capacity'] )
            ? max( 1, absint( wp_unslash( $_POST['rwexec_total_capacity'] ) ) )
            : max( 1, absint( get_option( 'rwexec_total_capacity', 60 ) ) );

        return min( $online, $submitted_total );
    }

    public static function register_settings() {
        register_setting( 'rwexec_reservations_general_settings', 'rwexec_total_capacity', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 60,
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_online_capacity', array(
            'type' => 'integer',
            'sanitize_callback' => array( __CLASS__, 'sanitize_online_capacity' ),
            'default' => 45,
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_capacity_mode', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_capacity_mode' ), 'default' => 'online_limit',
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_booking_interval', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 15,
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_reservation_duration', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 105,
        ) );

        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_public_max_party_size', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 12,
        ) );

        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_public_advance_days', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 90,
        ) );

        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_public_min_notice_minutes', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 60,
        ) );

        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_form_heading', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '',
        ) );
        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_form_subheading', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field', 'default' => '',
        ) );

        register_setting( 'rwexec_reservations_booking_form_styling_settings', 'rwexec_form_font_family', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_form_font_family' ), 'default' => 'inherit',
        ) );
        register_setting( 'rwexec_reservations_booking_form_styling_settings', 'rwexec_form_font_size', array(
            'type' => 'integer', 'sanitize_callback' => array( __CLASS__, 'sanitize_form_font_size' ), 'default' => 14,
        ) );
        register_setting( 'rwexec_reservations_booking_form_styling_settings', 'rwexec_form_label_font_size', array(
            'type' => 'integer', 'sanitize_callback' => array( __CLASS__, 'sanitize_form_label_font_size' ), 'default' => 13,
        ) );
        register_setting( 'rwexec_reservations_booking_form_styling_settings', 'rwexec_form_border_radius', array(
            'type' => 'integer', 'sanitize_callback' => array( __CLASS__, 'sanitize_form_border_radius' ), 'default' => 7,
        ) );

        register_setting( 'rwexec_reservations_booking_form_styling_settings', 'rwexec_form_heading_font_size', array(
            'type' => 'integer', 'sanitize_callback' => array( __CLASS__, 'sanitize_form_heading_font_size' ), 'default' => 28,
        ) );
        register_setting( 'rwexec_reservations_booking_form_styling_settings', 'rwexec_form_heading_font_weight', array(
            'type' => 'integer', 'sanitize_callback' => array( __CLASS__, 'sanitize_form_heading_font_weight' ), 'default' => 700,
        ) );
        register_setting( 'rwexec_reservations_booking_form_styling_settings', 'rwexec_form_subheading_font_size', array(
            'type' => 'integer', 'sanitize_callback' => array( __CLASS__, 'sanitize_form_subheading_font_size' ), 'default' => 14,
        ) );

        $booking_form_colors = self::booking_form_color_defaults();
        foreach ( $booking_form_colors as $option => $default ) {
            register_setting( 'rwexec_reservations_booking_form_styling_settings', $option, array(
                'type' => 'string', 'sanitize_callback' => 'sanitize_hex_color', 'default' => $default,
            ) );
        }

        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_booking_communications_text', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field', 'default' => 'We’ll use your contact details to send information about this reservation, such as your confirmation, updates and reminders.',
        ) );
        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_marketing_consent_label', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'Keep me updated',
        ) );
        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_marketing_consent_text', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field', 'default' => 'I’d like to receive occasional news, offers and updates from {restaurant_name} by email.',
        ) );

        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_public_custom_fields', array(
            'type' => 'array', 'sanitize_callback' => array( 'RWExec_Reservations_Form_Builder', 'sanitize_fields' ), 'default' => array(),
        ) );

        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_public_core_fields', array(
            'type' => 'array', 'sanitize_callback' => array( 'RWExec_Reservations_Form_Builder', 'sanitize_core_fields' ), 'default' => RWExec_Reservations_Form_Builder::default_core_fields(),
        ) );

        register_setting( 'rwexec_reservations_booking_form_settings', 'rwexec_public_field_order', array(
            'type' => 'array', 'sanitize_callback' => array( 'RWExec_Reservations_Form_Builder', 'sanitize_field_order' ), 'default' => array(),
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_restaurant_timezone', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_timezone' ), 'default' => 'Europe/London',
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_late_grace_minutes', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 15,
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_no_show_after_minutes', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 120,
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_auto_complete_checked_in', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_checkbox' ), 'default' => '1',
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_auto_complete_hours', array(
            'type' => 'integer', 'sanitize_callback' => array( __CLASS__, 'sanitize_auto_complete_hours' ), 'default' => 3,
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_staff_login_redirect', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_redirect_path' ), 'default' => '',
        ) );
        register_setting( 'rwexec_reservations_general_settings', 'rwexec_admin_login_redirect', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_redirect_path' ), 'default' => '',
        ) );
        register_setting( 'rwexec_reservations_general_settings', 'rwexec_staff_logout_redirect', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_redirect_path' ), 'default' => '',
        ) );
        register_setting( 'rwexec_reservations_general_settings', 'rwexec_staff_logout_text', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'Log Out',
        ) );
        register_setting( 'rwexec_reservations_general_settings', 'rwexec_staff_show_logout', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_checkbox' ), 'default' => '1',
        ) );

        register_setting( 'rwexec_reservations_general_settings', 'rwexec_delete_data_on_uninstall', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_checkbox' ), 'default' => '0',
        ) );

        $email_text_settings = array(
            'rwexec_email_restaurant_name' => get_bloginfo( 'name' ),
            'rwexec_email_from_name' => get_bloginfo( 'name' ),
            'rwexec_email_restaurant_phone' => '',
        );
        foreach ( $email_text_settings as $option => $default ) {
            register_setting( 'rwexec_reservations_email_settings', $option, array(
                'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => $default,
            ) );
        }
        register_setting( 'rwexec_reservations_email_settings', 'rwexec_email_restaurant_address', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field', 'default' => '',
        ) );
        foreach ( array( 'rwexec_email_from_email', 'rwexec_email_contact_email', 'rwexec_email_admin_recipient', 'rwexec_email_test_recipient' ) as $option ) {
            register_setting( 'rwexec_reservations_email_settings', $option, array(
                'type' => 'string', 'sanitize_callback' => 'sanitize_email', 'default' => get_option( 'admin_email' ),
            ) );
        }
        foreach ( array( 'rwexec_email_logo_url', 'rwexec_email_footer_logo_url', 'rwexec_email_feedback_url', 'rwexec_email_website_url' ) as $option ) {
            register_setting( 'rwexec_reservations_email_settings', $option, array(
                'type' => 'string', 'sanitize_callback' => 'esc_url_raw', 'default' => '',
            ) );
        }

        $email_colors = array(
            'rwexec_email_accent_color' => '#1e293b',
            'rwexec_email_secondary_color' => '#c79a2b',
            'rwexec_email_background_color' => '#f3f4f6',
            'rwexec_email_content_background_color' => '#ffffff',
            'rwexec_email_text_color' => '#334155',
            'rwexec_email_details_background_color' => '#f8fafc',
            'rwexec_email_details_border_color' => '#e2e8f0',
            'rwexec_email_footer_background_color' => '#1e293b',
            'rwexec_email_footer_text_color' => '#ffffff',
            'rwexec_email_button_color' => '#1e293b',
            'rwexec_email_button_text_color' => '#ffffff',
        );
        foreach ( $email_colors as $option => $default ) {
            register_setting( 'rwexec_reservations_email_settings', $option, array(
                'type' => 'string', 'sanitize_callback' => 'sanitize_hex_color', 'default' => $default,
            ) );
        }
        foreach ( array( 'rwexec_email_logo_width' => 115, 'rwexec_email_heading_size' => 32, 'rwexec_email_button_radius' => 6 ) as $option => $default ) {
            register_setting( 'rwexec_reservations_email_settings', $option, array(
                'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => $default,
            ) );
        }
        register_setting( 'rwexec_reservations_email_settings', 'rwexec_email_heading_font', array(
            'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_heading_font' ), 'default' => 'serif',
        ) );
        foreach ( array( 'rwexec_email_heading_divider', 'rwexec_email_footer_contact', 'rwexec_email_footer_copyright' ) as $option ) {
            register_setting( 'rwexec_reservations_email_settings', $option, array(
                'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_checkbox' ), 'default' => '1',
            ) );
        }
        register_setting( 'rwexec_reservations_email_settings', 'rwexec_email_footer_text', array(
            'type' => 'string', 'sanitize_callback' => 'wp_kses_post', 'default' => '',
        ) );

        foreach ( array( 'confirmation', 'update', 'cancellation', 'reminder', 'feedback', 'admin_new_booking', 'admin_update', 'admin_cancellation', 'admin_status' ) as $type ) {
            register_setting( 'rwexec_reservations_email_settings', 'rwexec_email_' . $type . '_enabled', array(
                'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_checkbox' ), 'default' => '1',
            ) );
        }

        register_setting( 'rwexec_reservations_email_settings', 'rwexec_email_reminder_hours', array(
            'type' => 'integer', 'sanitize_callback' => array( __CLASS__, 'sanitize_reminder_hours' ), 'default' => 24,
        ) );
        register_setting( 'rwexec_reservations_email_settings', 'rwexec_email_feedback_delay_hours', array(
            'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 2,
        ) );

        foreach ( RWExec_Reservations_Email::template_types() as $type => $config ) {
            register_setting( 'rwexec_reservations_email_template_' . $type, 'rwexec_email_' . $type . '_enabled', array(
                'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_checkbox' ), 'default' => '1',
            ) );
            register_setting( 'rwexec_reservations_email_template_' . $type, 'rwexec_email_template_' . $type . '_subject', array(
                'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => $config['default_subject'],
            ) );
            register_setting( 'rwexec_reservations_email_template_' . $type, 'rwexec_email_template_' . $type . '_heading', array(
                'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => $config['default_heading'],
            ) );
            register_setting( 'rwexec_reservations_email_template_' . $type, 'rwexec_email_template_' . $type . '_body', array(
                'type' => 'string', 'sanitize_callback' => 'wp_kses_post', 'default' => $config['default_body'],
            ) );
            register_setting( 'rwexec_reservations_email_template_' . $type, 'rwexec_email_template_' . $type . '_button_text', array(
                'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => $config['default_button_text'],
            ) );
            register_setting( 'rwexec_reservations_email_template_' . $type, 'rwexec_email_template_' . $type . '_button_url', array(
                'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_template_url' ), 'default' => $config['default_button_url'],
            ) );
            register_setting( 'rwexec_reservations_email_template_' . $type, 'rwexec_email_template_' . $type . '_detail_fields', array(
                'type' => 'array', 'sanitize_callback' => array( __CLASS__, 'sanitize_email_detail_fields' ), 'default' => RWExec_Reservations_Email::default_detail_fields( $type ),
            ) );
        }

        foreach ( self::get_days() as $day => $label ) {
            register_setting( 'rwexec_reservations_availability_settings', 'rwexec_' . $day . '_booking_status', array(
                'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_booking_status' ), 'default' => 'open',
            ) );
            register_setting( 'rwexec_reservations_availability_settings', 'rwexec_' . $day . '_booking_start', array(
                'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_booking_time' ), 'default' => '12:00',
            ) );
            register_setting( 'rwexec_reservations_availability_settings', 'rwexec_' . $day . '_booking_end', array(
                'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'sanitize_booking_time' ), 'default' => '22:00',
            ) );
        }
    }

    public static function sanitize_timezone( $value ): string {
        $value = sanitize_text_field( (string) $value );
        return in_array( $value, timezone_identifiers_list(), true ) ? $value : 'Europe/London';
    }

    public static function sanitize_redirect_path( $value ): string {
        $value = trim( sanitize_text_field( (string) $value ) );
        if ( '' === $value ) {
            return '';
        }
        if ( 0 === strpos( $value, '/' ) ) {
            return '/' . ltrim( $value, '/' );
        }
        $url = esc_url_raw( $value, array( 'http', 'https' ) );
        return $url ? wp_validate_redirect( $url, '' ) : '';
    }

    public static function sanitize_capacity_mode( $value ): string {
        if ( ! RWExec_Reservations_License::is_premium() ) {
            $saved = sanitize_key( (string) get_option( 'rwexec_capacity_mode', 'online_limit' ) );
            return in_array( $saved, array( 'online_limit', 'combined_live' ), true ) ? $saved : 'online_limit';
        }

        $value = sanitize_key( (string) $value );
        return in_array( $value, array( 'online_limit', 'combined_live' ), true ) ? $value : 'online_limit';
    }

    public static function sanitize_booking_status( $value ): string {
        $value = sanitize_key( (string) $value );
        return in_array( $value, array( 'open', 'walk_ins_only', 'closed' ), true ) ? $value : 'closed';
    }

    public static function sanitize_booking_time( $value ): string {
        $value = substr( sanitize_text_field( (string) $value ), 0, 5 );
        return preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $value ) ? $value : '';
    }

    public static function sanitize_auto_complete_hours( $value ): int {
        $hours = absint( $value );
        return min( 24, max( 1, $hours ) );
    }

    public static function sanitize_reminder_hours( $value ): int {
        // Free installations always use the included 12-hour reminder. Keep any
        // previously saved Premium value intact so it is restored after renewal.
        if ( ! RWExec_Reservations_License::is_premium() ) {
            return max( 1, absint( get_option( 'rwexec_email_reminder_hours', 24 ) ) );
        }
        return min( 168, max( 1, absint( $value ) ) );
    }

    public static function sanitize_checkbox( $value ): string {
        return '1' === (string) $value ? '1' : '0';
    }

    public static function sanitize_heading_font( $value ): string {
        return 'sans' === sanitize_key( $value ) ? 'sans' : 'serif';
    }

    public static function sanitize_form_font_family( $value ): string {
        $value = sanitize_key( (string) $value );
        $allowed = array( 'inherit', 'system', 'arial', 'helvetica', 'georgia', 'verdana', 'trebuchet' );
        return in_array( $value, $allowed, true ) ? $value : 'inherit';
    }

    public static function sanitize_form_font_size( $value ): int {
        return max( 12, min( 20, absint( $value ) ) );
    }

    public static function sanitize_form_label_font_size( $value ): int {
        return max( 11, min( 18, absint( $value ) ) );
    }

    public static function sanitize_form_border_radius( $value ): int {
        return max( 0, min( 24, absint( $value ) ) );
    }

    public static function sanitize_form_heading_font_size( $value ): int {
        return max( 16, min( 48, absint( $value ) ) );
    }

    public static function sanitize_form_heading_font_weight( $value ): int {
        $value = absint( $value );
        return in_array( $value, array( 400, 500, 600, 700, 800 ), true ) ? $value : 700;
    }

    public static function sanitize_form_subheading_font_size( $value ): int {
        return max( 11, min( 24, absint( $value ) ) );
    }

    public static function sanitize_email_detail_fields( $value ): array {
        $allowed = array_keys( RWExec_Reservations_Email::detail_field_choices() );
        if ( ! is_array( $value ) ) {
            return array();
        }
        return array_values( array_intersect( $allowed, array_map( 'sanitize_key', $value ) ) );
    }

    public static function sanitize_template_url( $value ): string {
        $value = trim( (string) $value );
        if ( preg_match( '/^\{[a-z0-9_]+\}$/', $value ) ) {
            return sanitize_text_field( $value );
        }
        return esc_url_raw( $value );
    }

    public static function get_days(): array {
        return array(
            'monday' => 'Monday', 'tuesday' => 'Tuesday', 'wednesday' => 'Wednesday',
            'thursday' => 'Thursday', 'friday' => 'Friday', 'saturday' => 'Saturday', 'sunday' => 'Sunday',
        );
    }

    public static function get_weekly_hours(): array {
        $weekly = array();
        foreach ( self::get_days() as $day => $label ) {
            $weekly[ $day ] = array(
                'status' => get_option( 'rwexec_' . $day . '_booking_status', 'open' ),
                'start' => get_option( 'rwexec_' . $day . '_booking_start', '12:00' ),
                'end' => get_option( 'rwexec_' . $day . '_booking_end', '22:00' ),
            );
        }
        return $weekly;
    }
}
