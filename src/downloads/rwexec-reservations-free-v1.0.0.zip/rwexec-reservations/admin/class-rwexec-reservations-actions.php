<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Actions {

    public static function init() {
        add_action( 'admin_post_rwexec_create_reservation', array( __CLASS__, 'handle_create_reservation' ) );
        add_action( 'admin_post_rwexec_quick_add_walk_in', array( __CLASS__, 'handle_quick_add_walk_in' ) );
        add_action( 'admin_post_rwexec_update_reservation', array( __CLASS__, 'handle_update_reservation' ) );
        add_action( 'admin_post_rwexec_set_reservation_status', array( __CLASS__, 'handle_set_status' ) );
        add_action( 'admin_post_rwexec_set_table_reference', array( __CLASS__, 'handle_set_table_reference' ) );
        add_action( 'admin_post_rwexec_delete_reservation', array( __CLASS__, 'handle_delete_reservation' ) );
        add_action( 'admin_post_rwexec_save_special_date', array( __CLASS__, 'handle_save_special_date' ) );
        add_action( 'admin_post_rwexec_delete_special_date', array( __CLASS__, 'handle_delete_special_date' ) );
        add_action( 'admin_post_rwexec_preview_email', array( __CLASS__, 'handle_preview_email' ) );
        add_action( 'admin_post_rwexec_test_email', array( __CLASS__, 'handle_test_email' ) );
        add_action( 'admin_post_rwexec_save_customer', array( __CLASS__, 'handle_save_customer' ) );
        add_action( 'admin_post_rwexec_export_marketing_contacts', array( __CLASS__, 'handle_export_marketing_contacts' ) );
        add_action( 'admin_post_rwexec_record_marketing_consent', array( __CLASS__, 'handle_record_marketing_consent' ) );
        add_action( 'admin_post_rwexec_withdraw_marketing_consent', array( __CLASS__, 'handle_withdraw_marketing_consent' ) );
    }

    private static function require_permission() {
        if ( ! RWExec_Reservations_Staff::can_manage() ) {
            wp_die( 'You do not have permission to manage reservations.' );
        }
    }

    private static function require_admin_permission() {
        if ( ! RWExec_Reservations_Staff::can_admin() ) {
            wp_die( 'You do not have permission to manage reservation settings.' );
        }
    }

    private static function require_post_request() {
        if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
            status_header( 405 );
            wp_die( 'Invalid request method.' );
        }
    }

    private static function csv_safe( $value ): string {
        $value = (string) $value;
        if ( preg_match( '/^[=+\-@]/', ltrim( $value ) ) ) {
            return "'" . $value;
        }
        return $value;
    }

    private static function store_form_state( array $state ): string {
        $token = substr( md5( wp_generate_uuid4() . wp_rand() ), 0, 24 );
        set_transient(
            'rwexec_form_state_' . get_current_user_id() . '_' . $token,
            $state,
            10 * MINUTE_IN_SECONDS
        );
        return $token;
    }

    public static function consume_form_state( string $token ): array {
        $token = sanitize_key( $token );
        if ( '' === $token ) {
            return array();
        }
        $key = 'rwexec_form_state_' . get_current_user_id() . '_' . $token;
        $state = get_transient( $key );
        delete_transient( $key );
        return is_array( $state ) ? $state : array();
    }

    private static function reservation_form_values(): array {
        return array(
            'customer_name' => sanitize_text_field( wp_unslash( $_POST['customer_name'] ?? '' ) ),
            'customer_email' => sanitize_email( wp_unslash( $_POST['customer_email'] ?? '' ) ),
            'customer_phone' => sanitize_text_field( wp_unslash( $_POST['customer_phone'] ?? '' ) ),
            'no_customer_email' => ! empty( $_POST['no_customer_email'] ) ? 1 : 0,
            'no_customer_phone' => ! empty( $_POST['no_customer_phone'] ) ? 1 : 0,
            'is_historic' => ! empty( $_POST['is_historic'] ) ? 1 : 0,
            'reservation_date' => sanitize_text_field( wp_unslash( $_POST['reservation_date'] ?? '' ) ),
            'start_time' => sanitize_text_field( wp_unslash( $_POST['start_time'] ?? '' ) ),
            'guest_count' => absint( $_POST['guest_count'] ?? 0 ),
            'table_reference' => sanitize_text_field( wp_unslash( $_POST['table_reference'] ?? '' ) ),
            'allergies' => sanitize_textarea_field( wp_unslash( $_POST['allergies'] ?? '' ) ),
            'additional_information' => sanitize_textarea_field( wp_unslash( $_POST['additional_information'] ?? '' ) ),
        );
    }

    private static function prepare_manual_contact_values( array $values ) {
        $no_email = ! empty( $values['no_customer_email'] );
        $no_phone = ! empty( $values['no_customer_phone'] );

        if ( $no_email ) {
            $values['customer_email'] = '';
        } elseif ( empty( $values['customer_email'] ) ) {
            return new WP_Error( 'rwexec_customer_email_required', 'Enter the customer email address or tick “No email address provided”.' );
        }

        if ( $no_phone ) {
            $values['customer_phone'] = '';
        } elseif ( empty( trim( (string) $values['customer_phone'] ) ) ) {
            return new WP_Error( 'rwexec_customer_phone_required', 'Enter the customer telephone number or tick “No telephone number provided”.' );
        }

        return $values;
    }

    private static function get_override_signature( array $data ): string {
        $values = array(
            'customer_name' => sanitize_text_field( $data['customer_name'] ?? '' ),
            'customer_email' => sanitize_email( $data['customer_email'] ?? '' ),
            'customer_phone' => sanitize_text_field( $data['customer_phone'] ?? '' ),
            'no_customer_email' => ! empty( $data['no_customer_email'] ) ? 1 : 0,
            'no_customer_phone' => ! empty( $data['no_customer_phone'] ) ? 1 : 0,
            'is_historic' => ! empty( $data['is_historic'] ) ? 1 : 0,
            'reservation_date' => sanitize_text_field( $data['reservation_date'] ?? '' ),
            'start_time' => sanitize_text_field( $data['start_time'] ?? '' ),
            'guest_count' => absint( $data['guest_count'] ?? 0 ),
            'table_reference' => sanitize_text_field( $data['table_reference'] ?? '' ),
            'allergies' => sanitize_textarea_field( $data['allergies'] ?? '' ),
            'additional_information' => sanitize_textarea_field( $data['additional_information'] ?? '' ),
        );
        return hash( 'sha256', wp_json_encode( $values ) );
    }


    private static function frontend_base(): string {
        $base = isset( $_POST['rwexec_frontend_base'] ) ? esc_url_raw( wp_unslash( $_POST['rwexec_frontend_base'] ) ) : '';
        return $base ? wp_validate_redirect( $base, '' ) : '';
    }


    public static function handle_save_customer() {
        self::require_post_request();
        self::require_permission();
        if ( ! RWExec_Reservations_License::is_premium() ) { wp_die( 'This feature requires RWExec Reservations Premium.' ); }
        check_admin_referer( 'rwexec_save_customer', 'rwexec_customer_nonce' );
        $customer_id = absint( $_POST['customer_id'] ?? 0 );
        if ( ! $customer_id ) { wp_die( 'Invalid customer.' ); }
        RWExec_Reservations_Customers::save_notes(
            $customer_id,
            wp_unslash( $_POST['staff_notes'] ?? '' ),
            wp_unslash( $_POST['preferences'] ?? '' )
        );
        $frontend = self::frontend_base();
        $redirect = $frontend
            ? add_query_arg( array( 'rwexec_action'=>'customer', 'customer_id'=>$customer_id, 'customer_saved'=>1 ), $frontend )
            : add_query_arg( array( 'page'=>'rwexec-reservations-customer', 'customer_id'=>$customer_id, 'customer_saved'=>1 ), admin_url('admin.php') );
        wp_safe_redirect( $redirect ); exit;
    }


    public static function handle_export_marketing_contacts() {
        if ( ! RWExec_Reservations_License::is_premium() ) {
            wp_die( 'This feature requires RWExec Reservations Premium.' );
        }
        if ( ! RWExec_Reservations_Staff::can_admin() ) {
            wp_die( 'You do not have permission to export marketing contacts.' );
        }
        check_admin_referer( 'rwexec_export_marketing_contacts' );
        $contacts = RWExec_Reservations_Customers::marketing_contacts();
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=rwexec-marketing-contacts-' . gmdate( 'Y-m-d' ) . '.csv' );
        $out = fopen( 'php://output', 'w' );
        if ( false === $out ) { wp_die( 'Unable to create export.' ); }
        fputcsv( $out, array( 'Customer Name', 'Email', 'Consent Date', 'Consent Source', 'Consent Wording', 'Last Booking Date' ) );
        foreach ( $contacts as $customer ) {
            fputcsv( $out, array(
                self::csv_safe( $customer->customer_name ),
                self::csv_safe( $customer->customer_email ),
                self::csv_safe( $customer->marketing_consent_at ?: '' ),
                self::csv_safe( $customer->marketing_consent_source ?: '' ),
                self::csv_safe( $customer->marketing_consent_text ?: '' ),
                self::csv_safe( $customer->last_booking ?: '' ),
            ) );
        }
        fclose( $out );
        exit;
    }

    public static function handle_record_marketing_consent() {
        self::require_post_request();
        self::require_permission();
        if ( ! RWExec_Reservations_License::is_premium() ) { wp_die( 'This feature requires RWExec Reservations Premium.' ); }
        $customer_id = absint( $_POST['customer_id'] ?? 0 );
        check_admin_referer( 'rwexec_record_marketing_consent_' . $customer_id, 'rwexec_marketing_nonce' );

        $customer = $customer_id ? RWExec_Reservations_Customers::get( $customer_id ) : null;
        $confirmed = ! empty( $_POST['marketing_consent_confirmed'] ) && '1' === (string) wp_unslash( $_POST['marketing_consent_confirmed'] );
        $consent_text = sanitize_textarea_field( wp_unslash( $_POST['marketing_consent_text'] ?? '' ) );

        $error = '';
        if ( ! $customer ) {
            $error = 'invalid_customer';
        } elseif ( empty( $customer->customer_email ) ) {
            $error = 'missing_email';
        } elseif ( ! $confirmed ) {
            $error = 'confirmation_required';
        } elseif ( '' === trim( $consent_text ) ) {
            $error = 'wording_required';
        } else {
            RWExec_Reservations_Customers::record_marketing_consent( $customer_id, $consent_text );
        }

        $frontend = self::frontend_base();
        $args = array( 'customer_id' => $customer_id );
        if ( $frontend ) {
            $args['rwexec_action'] = 'customer';
        } else {
            $args['page'] = 'rwexec-reservations-customer';
        }
        if ( $error ) {
            $args['marketing_consent_error'] = $error;
        } else {
            $args['marketing_consent_recorded'] = 1;
        }
        $redirect = add_query_arg( $args, $frontend ?: admin_url( 'admin.php' ) );
        wp_safe_redirect( $redirect ); exit;
    }

    public static function handle_withdraw_marketing_consent() {
        self::require_post_request();
        self::require_permission();
        if ( ! RWExec_Reservations_License::is_premium() ) { wp_die( 'This feature requires RWExec Reservations Premium.' ); }
        $customer_id = absint( $_POST['customer_id'] ?? 0 );
        check_admin_referer( 'rwexec_withdraw_marketing_consent_' . $customer_id, 'rwexec_marketing_nonce' );
        if ( $customer_id ) { RWExec_Reservations_Customers::withdraw_marketing_consent( $customer_id ); }
        $frontend = self::frontend_base();
        $redirect = $frontend
            ? add_query_arg( array( 'rwexec_action'=>'customer', 'customer_id'=>$customer_id, 'marketing_withdrawn'=>1 ), $frontend )
            : add_query_arg( array( 'page'=>'rwexec-reservations-customer', 'customer_id'=>$customer_id, 'marketing_withdrawn'=>1 ), admin_url('admin.php') );
        wp_safe_redirect( $redirect ); exit;
    }


    public static function handle_set_table_reference() {
        self::require_post_request();
        self::require_permission();
        $reservation_id = absint( $_POST['reservation_id'] ?? 0 );
        check_admin_referer( 'rwexec_set_table_reference_' . $reservation_id, 'rwexec_table_nonce' );

        $table_reference = sanitize_text_field( wp_unslash( $_POST['table_reference'] ?? '' ) );
        $result = RWExec_Reservations_Service::update_table_reference( $reservation_id, $table_reference );
        $return_to = isset( $_POST['return_to'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_POST['return_to'] ) ), '' ) : '';
        if ( ! $return_to ) {
            $return_to = admin_url( 'admin.php?page=rwexec-reservations' );
        }

        if ( is_wp_error( $result ) ) {
            $return_to = add_query_arg( 'action_error', rawurlencode( $result->get_error_message() ), $return_to );
        } else {
            $return_to = add_query_arg( 'table_updated', 1, $return_to );
        }

        wp_safe_redirect( $return_to );
        exit;
    }

    public static function handle_quick_add_walk_in() {
        self::require_post_request();
        self::require_permission();
        check_admin_referer( 'rwexec_quick_add_walk_in', 'rwexec_quick_add_nonce' );

        $guest_count = absint( $_POST['guest_count'] ?? 0 );
        $table_reference = sanitize_text_field( wp_unslash( $_POST['table_reference'] ?? '' ) );
        $table_reference = function_exists( 'mb_substr' )
            ? mb_substr( $table_reference, 0, 50 )
            : substr( $table_reference, 0, 50 );

        $return_to = isset( $_POST['return_to'] )
            ? wp_validate_redirect( esc_url_raw( wp_unslash( $_POST['return_to'] ) ), '' )
            : '';
        if ( ! $return_to ) {
            $return_to = admin_url( 'admin.php?page=rwexec-reservations' );
        }

        if ( $guest_count < 1 ) {
            wp_safe_redirect( add_query_arg( 'action_error', rawurlencode( 'Enter at least 1 guest for the walk-in.' ), $return_to ) );
            exit;
        }

        $now = RWExec_Reservations_Service::restaurant_now();
        $minute = (int) $now->format( 'i' );
        $minutes_to_add = 0 === ( $minute % 15 ) ? 0 : 15 - ( $minute % 15 );
        $slot = $now->setTime( (int) $now->format( 'H' ), $minute, 0 );
        if ( $minutes_to_add > 0 ) {
            $slot = $slot->modify( '+' . $minutes_to_add . ' minutes' );
        }

        $result = RWExec_Reservations_Service::create_reservation(
            array(
                'customer_name' => 'Walk-in',
                'customer_email' => '',
                'customer_phone' => '',
                'reservation_date' => $slot->format( 'Y-m-d' ),
                'start_time' => $slot->format( 'H:i' ),
                'guest_count' => $guest_count,
                'table_reference' => $table_reference,
                'status' => 'checked_in',
                'source' => 'walk_in',
                'suppress_notifications' => 1,
            )
        );

        if ( is_wp_error( $result ) ) {
            wp_safe_redirect( add_query_arg( 'action_error', rawurlencode( $result->get_error_message() ), $return_to ) );
            exit;
        }

        wp_safe_redirect(
            add_query_arg(
                array(
                    'walk_in_added' => 1,
                    'walk_in_guests' => $guest_count,
                    'walk_in_time' => $slot->format( 'H:i' ),
                ),
                $return_to
            )
        );
        exit;
    }

    public static function handle_create_reservation() {
        self::require_post_request();
        self::require_permission();
        check_admin_referer( 'rwexec_create_reservation', 'rwexec_reservation_nonce' );

        $values = self::reservation_form_values();
        $prepared = self::prepare_manual_contact_values( $values );
        if ( is_wp_error( $prepared ) ) {
            $frontend = self::frontend_base();
            $state_token = self::store_form_state( array_merge( $values, array(
                'reservation_error' => $prepared->get_error_code(),
                'reservation_message' => $prepared->get_error_message(),
            ) ) );
            if ( $frontend ) {
                wp_safe_redirect( add_query_arg( array( 'rwexec_action'=>'add', 'form_state'=>$state_token ), $frontend ) );
            } else {
                wp_safe_redirect( add_query_arg( array( 'page'=>'rwexec-reservations-add', 'form_state'=>$state_token ), admin_url( 'admin.php' ) ) );
            }
            exit;
        }
        $values = $prepared;
        $marketing_consent = RWExec_Reservations_License::is_premium() && ! empty( $_POST['marketing_email_consent'] ) && '1' === (string) wp_unslash( $_POST['marketing_email_consent'] ) && ! empty( $values['customer_email'] );
        $marketing_label = (string) get_option( 'rwexec_marketing_consent_label', 'Keep me updated' );
        $marketing_text = str_replace( '{restaurant_name}', (string) get_option( 'rwexec_email_restaurant_name', get_bloginfo( 'name' ) ), (string) get_option( 'rwexec_marketing_consent_text', 'I’d like to receive occasional news, offers and updates from {restaurant_name} by email.' ) );
        $values['marketing_email_consent'] = $marketing_consent ? 1 : 0;
        $values['marketing_consent_text'] = $marketing_consent ? trim( $marketing_label . ( $marketing_text ? ': ' . $marketing_text : '' ) ) : '';
        $values['marketing_consent_at'] = $marketing_consent ? RWExec_Reservations_Service::restaurant_now()->format( 'Y-m-d H:i:s' ) : null;
        $is_historic = ! empty( $values['is_historic'] );
        $result = RWExec_Reservations_Service::create_reservation( array_merge( $values, array(
            'status' => $is_historic ? 'completed' : 'confirmed',
            'source' => 'manual',
            'is_historic' => $is_historic ? 1 : 0,
            'suppress_notifications' => $is_historic ? 1 : 0,
        ) ) );

        if ( is_wp_error( $result ) ) {
            $frontend = self::frontend_base();
            $state_token = self::store_form_state( array_merge( $values, array(
                'reservation_error' => $result->get_error_code(),
                'reservation_message' => $result->get_error_message(),
            ) ) );
            if ( $frontend ) {
                wp_safe_redirect( add_query_arg( array( 'rwexec_action'=>'add', 'form_state'=>$state_token ), $frontend ) );
            } else {
                wp_safe_redirect( add_query_arg( array( 'page'=>'rwexec-reservations-add', 'form_state'=>$state_token ), admin_url( 'admin.php' ) ) );
            }
            exit;
        }

        $frontend = self::frontend_base();
        wp_safe_redirect( $frontend ? add_query_arg( 'created', 1, $frontend ) : admin_url( 'admin.php?page=rwexec-reservations&created=1' ) );
        exit;
    }

    public static function handle_update_reservation() {
        self::require_post_request();
        self::require_permission();
        check_admin_referer( 'rwexec_update_reservation', 'rwexec_update_reservation_nonce' );

        $reservation_id = absint( $_POST['reservation_id'] ?? 0 );
        if ( ! $reservation_id ) {
            wp_die( 'Invalid reservation.' );
        }

        $values = self::reservation_form_values();
        $prepared = self::prepare_manual_contact_values( $values );
        if ( is_wp_error( $prepared ) ) {
            $frontend = self::frontend_base();
            $state_token = self::store_form_state( array_merge( $values, array(
                'reservation_error' => $prepared->get_error_code(),
                'reservation_message' => $prepared->get_error_message(),
            ) ) );
            $base_args = array( 'reservation_id'=>$reservation_id, 'form_state'=>$state_token );
            if ( $frontend ) {
                $base_args['rwexec_action'] = 'edit';
                wp_safe_redirect( add_query_arg( $base_args, $frontend ) );
            } else {
                $base_args['page'] = 'rwexec-reservation-edit';
                wp_safe_redirect( add_query_arg( $base_args, admin_url( 'admin.php' ) ) );
            }
            exit;
        }
        $values = $prepared;
        $allow_override = false;

        if ( isset( $_POST['allow_override'], $_POST['override_signature'] ) && '1' === $_POST['allow_override'] ) {
            $submitted = self::get_override_signature( $values );
            $stored = sanitize_text_field( wp_unslash( $_POST['override_signature'] ) );
            $allow_override = hash_equals( $stored, $submitted );
        }

        $values['override_reason'] = sanitize_key( wp_unslash( $_POST['override_reason'] ?? '' ) );
        $result = RWExec_Reservations_Service::update_reservation( $reservation_id, $values, $allow_override );

        if ( is_wp_error( $result ) ) {
            $signature = self::get_override_signature( $values );
            $frontend = self::frontend_base();
            $state_token = self::store_form_state( array_merge( $values, array(
                'override_required' => $result->get_error_code(),
                'override_message' => $result->get_error_message(),
                'override_signature' => $signature,
            ) ) );
            $base_args = array( 'reservation_id'=>$reservation_id, 'form_state'=>$state_token );
            if ( $frontend ) {
                $base_args['rwexec_action'] = 'edit';
                wp_safe_redirect( add_query_arg( $base_args, $frontend ) );
            } else {
                $base_args['page'] = 'rwexec-reservation-edit';
                wp_safe_redirect( add_query_arg( $base_args, admin_url( 'admin.php' ) ) );
            }
            exit;
        }

        $frontend = self::frontend_base();
        wp_safe_redirect( $frontend ? add_query_arg( array( 'rwexec_action'=>'view', 'reservation_id'=>$reservation_id, 'updated'=>1 ), $frontend ) : add_query_arg( array( 'page'=>'rwexec-reservation-details', 'reservation_id'=>$reservation_id, 'updated'=>1 ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function handle_set_status() {
        self::require_post_request();
        self::require_permission();
        check_admin_referer( 'rwexec_set_reservation_status', 'rwexec_status_nonce' );

        $reservation_id = absint( $_POST['reservation_id'] ?? 0 );
        $status = sanitize_key( wp_unslash( $_POST['status'] ?? '' ) );
        $result = RWExec_Reservations_Service::set_status( $reservation_id, $status );

        $default_redirect = add_query_arg(
            array(
                'page' => 'rwexec-reservation-details',
                'reservation_id' => $reservation_id,
            ),
            admin_url( 'admin.php' )
        );

        $requested_redirect = isset( $_POST['return_to'] )
            ? esc_url_raw( wp_unslash( $_POST['return_to'] ) )
            : '';

        $redirect = wp_validate_redirect( $requested_redirect, $default_redirect );

        if ( is_wp_error( $result ) ) {
            $redirect = add_query_arg(
                'action_error',
                rawurlencode( $result->get_error_message() ),
                $redirect
            );
        } else {
            $redirect = add_query_arg( 'status_updated', 1, $redirect );
        }

        wp_safe_redirect( $redirect );
        exit;
    }

    public static function handle_delete_reservation() {
        self::require_post_request();
        self::require_admin_permission();
        check_admin_referer( 'rwexec_delete_reservation', 'rwexec_delete_nonce' );

        $reservation_id = absint( $_POST['reservation_id'] ?? 0 );
        RWExec_Reservations_Service::delete_reservation( $reservation_id );
        $frontend = self::frontend_base();
        wp_safe_redirect( $frontend ? add_query_arg( 'deleted', 1, $frontend ) : admin_url( 'admin.php?page=rwexec-reservations&deleted=1' ) );
        exit;
    }

    public static function handle_save_special_date() {
        self::require_post_request();
        self::require_admin_permission();
        if ( ! RWExec_Reservations_License::is_premium() ) { wp_die( 'This feature requires RWExec Reservations Pro.' ); }
        check_admin_referer( 'rwexec_save_special_date', 'rwexec_special_date_nonce' );

        $result = RWExec_Reservations_Special_Dates::save( wp_unslash( $_POST ) );
        $args = array( 'page' => 'rwexec-reservations-settings', 'tab' => 'special-dates' );

        if ( is_wp_error( $result ) ) {
            $args['special_error'] = rawurlencode( $result->get_error_message() );
        } else {
            $args['special_saved'] = 1;
        }

        wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function handle_delete_special_date() {
        self::require_post_request();
        self::require_admin_permission();
        if ( ! RWExec_Reservations_License::is_premium() ) { wp_die( 'This feature requires RWExec Reservations Pro.' ); }
        check_admin_referer( 'rwexec_delete_special_date', 'rwexec_delete_special_nonce' );
        RWExec_Reservations_Special_Dates::delete( absint( $_POST['special_date_id'] ?? 0 ) );
        wp_safe_redirect( admin_url( 'admin.php?page=rwexec-reservations-settings&tab=special-dates&special_deleted=1' ) );
        exit;
    }
    public static function handle_preview_email() {
        self::require_admin_permission();
        $type = sanitize_key( wp_unslash( $_GET['type'] ?? '' ) );
        check_admin_referer( 'rwexec_preview_email_' . $type );

        $html = RWExec_Reservations_Email::preview_template( $type );
        if ( ! $html ) {
            wp_die( 'Invalid email template.' );
        }

        nocache_headers();
        header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Complete sanitized email preview HTML.
        exit;
    }

    public static function handle_test_email() {
        self::require_admin_permission();
        $type = sanitize_key( wp_unslash( $_GET['type'] ?? '' ) );
        check_admin_referer( 'rwexec_test_email_' . $type );

        $recipient = sanitize_email( get_option( 'rwexec_email_test_recipient', get_option( 'admin_email' ) ) );
        $sent = RWExec_Reservations_Email::send_test( $type, $recipient );

        $redirect = add_query_arg(
            array(
                'page' => 'rwexec-reservations-settings',
                'tab' => 'emails',
                'template' => $type,
                $sent ? 'test_sent' : 'test_failed' => 1,
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect );
        exit;
    }
}
