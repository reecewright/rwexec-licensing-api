<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Settings_Page {

    public static function render() {
        $tabs = array(
            'general'        => 'General',
            'availability'   => 'Availability',
            'special-dates'  => 'Special Dates',
            'booking-form'   => 'Booking Form',
            'emails'         => 'Email Settings',
            'email-templates'=> 'Email Templates',
            'licence'        => 'Licence',
            'shortcodes'     => 'Shortcodes',
            'setup-wizard'   => 'Setup Wizard',
        );

        $active = sanitize_key( wp_unslash( $_GET['tab'] ?? 'general' ) );
        if ( ! isset( $tabs[ $active ] ) ) {
            $active = 'general';
        }
        ?>
        <div class="wrap rwexec-admin rwexec-settings">
            <div class="rwexec-settings-header">
                <h1>Reservation Settings</h1>
                <?php if ( ! RWExec_Reservations_License::is_premium() ) : ?>
                    <?php echo wp_kses_post( RWExec_Reservations_License::premium_badge( 'Upgrade to Pro' ) ); ?>
                <?php endif; ?>
            </div>
            <nav class="nav-tab-wrapper rwexec-settings-tabs">
                <?php foreach ( $tabs as $key => $label ) :
                    $url = add_query_arg(
                        array( 'page' => 'rwexec-reservations-settings', 'tab' => $key ),
                        admin_url( 'admin.php' )
                    );
                    ?>
                    <a class="nav-tab <?php echo $active === $key ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $label ); ?><?php if ( in_array( $key, array( 'special-dates', 'email-templates' ), true ) && ! RWExec_Reservations_License::is_premium() ) : ?><span class="rwexec-tab-premium-icon"><?php echo wp_kses_post( RWExec_Reservations_License::premium_icon() ); ?></span><?php endif; ?></a>
                <?php endforeach; ?>
            </nav>

            <?php
            switch ( $active ) {
                case 'licence':
                    self::render_licence();
                    break;
                case 'shortcodes':
                    self::render_shortcodes();
                    break;
                case 'setup-wizard':
                    self::render_setup_wizard_tab();
                    break;
                case 'availability':
                    self::render_availability();
                    break;
                case 'special-dates':
                    if ( class_exists( 'RWExec_Reservations_Special_Dates_Page' ) && RWExec_Reservations_License::is_premium() ) { RWExec_Reservations_Special_Dates_Page::render( true ); } else { RWExec_Reservations_Admin::render_pro_gate( 'Special Dates', 'One-off closures, bank holidays, special opening hours and date overrides are included with RWExec Reservations Pro.' ); }
                    break;
                case 'booking-form':
                    self::render_booking_form();
                    break;
                case 'emails':
                    self::render_emails();
                    break;
                case 'email-templates':
                    if ( class_exists( 'RWExec_Reservations_Email_Templates_Page' ) && RWExec_Reservations_License::is_premium() ) { RWExec_Reservations_Email_Templates_Page::render( true ); } else { RWExec_Reservations_Admin::render_pro_gate( 'Email Templates', 'Editable email templates and advanced automated communications are included with RWExec Reservations Pro.' ); }
                    break;
                case 'general':
                default:
                    self::render_general();
                    break;
            }
            ?>
        </div>
        <?php
    }

    private static function render_licence() {
        $license_key = RWExec_Reservations_License::get_license_key();
        $state = RWExec_Reservations_License::get_state();
        $entitlement = RWExec_Reservations_License::entitlement_status();
        $notice = sanitize_key( wp_unslash( $_GET['license_notice'] ?? '' ) );
        $is_activated = in_array( $entitlement, array( 'active', 'grace' ), true );
        $pro_addon_active = RWExec_Reservations_License::is_pro_addon_active();

        $notices = array(
            'activated'           => array( 'success', __( 'Licence activated successfully.', 'rwexec-reservations' ) ),
            'validated'           => array( 'success', __( 'Licence validated successfully.', 'rwexec-reservations' ) ),
            'deactivated'         => array( 'success', __( 'Licence deactivated for this site.', 'rwexec-reservations' ) ),
            'missing_key'         => array( 'error', __( 'Enter a licence key first.', 'rwexec-reservations' ) ),
            'connection_error'    => array( 'warning', __( 'The licensing service could not be reached. Please try again shortly.', 'rwexec-reservations' ) ),
            'activation_failed'   => array( 'error', __( 'The licence could not be activated.', 'rwexec-reservations' ) ),
            'validation_failed'   => array( 'error', __( 'This licence is not currently valid for this website.', 'rwexec-reservations' ) ),
            'deactivation_failed' => array( 'error', __( 'The licence could not be deactivated. Please try again or manage it from your RWExec account.', 'rwexec-reservations' ) ),
        );

        if ( isset( $notices[ $notice ] ) ) {
            list( $type, $message ) = $notices[ $notice ];
            echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
        }

        $status_labels = array(
            'active'                   => __( 'Active', 'rwexec-reservations' ),
            'grace'                    => __( 'Grace period', 'rwexec-reservations' ),
            'inactive'                 => __( 'Not activated', 'rwexec-reservations' ),
            'deactivated'              => __( 'Not activated', 'rwexec-reservations' ),
            'expired'                  => __( 'Expired', 'rwexec-reservations' ),
            'subscription_inactive'    => __( 'Subscription inactive', 'rwexec-reservations' ),
            'suspended'                => __( 'Suspended', 'rwexec-reservations' ),
            'revoked'                  => __( 'Revoked', 'rwexec-reservations' ),
            'invalid'                  => __( 'Invalid licence', 'rwexec-reservations' ),
            'activation_limit_reached' => __( 'Activation limit reached', 'rwexec-reservations' ),
        );
        $status_label = $status_labels[ $entitlement ] ?? ucfirst( str_replace( '_', ' ', $entitlement ) );

        $issue_messages = array(
            'activation_limit_reached' => __( 'This licence is already active on the maximum number of websites. Deactivate it from another site or manage your activations in your RWExec account.', 'rwexec-reservations' ),
            'expired'                  => __( 'This licence has expired. Premium features are unavailable, but existing reservation data and core booking functionality are unaffected. Renew or manage your subscription in your RWExec account.', 'rwexec-reservations' ),
            'subscription_inactive'    => __( 'Your RWExec subscription is inactive. Premium features are unavailable, but existing reservation data and core booking functionality are unaffected. Open your RWExec account to renew or manage your subscription.', 'rwexec-reservations' ),
            'suspended'                => __( 'This licence is currently suspended. Open your RWExec account to review the licence status.', 'rwexec-reservations' ),
            'revoked'                  => __( 'This licence is no longer valid. Open your RWExec account to review your licences.', 'rwexec-reservations' ),
            'invalid'                  => __( 'This licence key is not valid for this installation. Check the key or open your RWExec account to manage your licences.', 'rwexec-reservations' ),
        );
        $issue_message = $issue_messages[ $entitlement ] ?? __( 'This licence is not active on this website. Check the key or manage your licences in your RWExec account.', 'rwexec-reservations' );
        ?>
        <div class="rwexec-settings-card rwexec-license-card">
            <div class="rwexec-license-heading">
                <div>
                    <h2><?php echo esc_html__( 'RWExec Licence', 'rwexec-reservations' ); ?></h2>
                    <p><?php echo esc_html__( 'Your licence authorises RWExec Reservations Pro. The separate Pro add-on must also be installed and active to use Pro features.', 'rwexec-reservations' ); ?></p>
                </div>
                <span class="rwexec-license-badge rwexec-license-badge--<?php echo esc_attr( $entitlement ); ?>"><?php echo esc_html( $status_label ); ?></span>
            </div>

            <?php if ( 'grace' === $entitlement ) : ?>
                <div class="notice notice-warning inline"><p><?php echo esc_html__( 'The licensing service is temporarily unreachable. Your last successful validation is being honoured during the seven-day grace period.', 'rwexec-reservations' ); ?></p></div>
            <?php endif; ?>

            <div class="rwexec-pro-status rwexec-pro-status--<?php echo $is_activated && $pro_addon_active ? 'active' : ( $is_activated ? 'warning' : ( $pro_addon_active ? 'warning' : 'neutral' ) ); ?>">
                <div class="rwexec-pro-status__content">
                    <?php if ( $is_activated && $pro_addon_active ) : ?>
                        <strong><?php echo esc_html__( 'Pro add-on active', 'rwexec-reservations' ); ?></strong>
                        <p><?php echo esc_html__( 'Your Pro licence is active and RWExec Reservations Pro is installed. Pro features are unlocked.', 'rwexec-reservations' ); ?></p>
                    <?php elseif ( $is_activated ) : ?>
                        <strong><?php echo esc_html__( 'Pro licence active — add-on required', 'rwexec-reservations' ); ?></strong>
                        <p><?php echo esc_html__( 'Your licence is valid, but RWExec Reservations Pro is not installed or active. Install and activate the Pro add-on to unlock Pro features.', 'rwexec-reservations' ); ?></p>
                    <?php elseif ( $pro_addon_active ) : ?>
                        <strong><?php echo esc_html__( 'Pro add-on installed — licence required', 'rwexec-reservations' ); ?></strong>
                        <p><?php echo esc_html__( 'RWExec Reservations Pro is installed, but a valid Pro licence must be activated before Pro features can be used.', 'rwexec-reservations' ); ?></p>
                    <?php else : ?>
                        <strong><?php echo esc_html__( 'Free edition active', 'rwexec-reservations' ); ?></strong>
                        <p><?php echo esc_html__( 'Upgrade to Pro for advanced capacity controls, special dates, customer tools, automated communications and advanced customisation.', 'rwexec-reservations' ); ?></p>
                    <?php endif; ?>
                </div>
                <?php if ( $is_activated && ! $pro_addon_active ) : ?>
                    <a class="button button-primary" href="<?php echo esc_url( RWExec_Reservations_License::account_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Download Pro add-on', 'rwexec-reservations' ); ?></a>
                <?php elseif ( ! $is_activated && ! $pro_addon_active ) : ?>
                    <?php echo wp_kses_post( RWExec_Reservations_License::premium_badge( 'Get RWExec Reservations Pro' ) ); ?>
                <?php endif; ?>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="rwexec_license_activate">
                <?php wp_nonce_field( 'rwexec_license_activate' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th><label for="rwexec_license_key"><?php echo esc_html__( 'Licence Key', 'rwexec-reservations' ); ?></label></th>
                        <td>
                            <input type="text" class="regular-text rwexec-license-key" id="rwexec_license_key" name="license_key" value="<?php echo esc_attr( $license_key ); ?>" autocomplete="off" spellcheck="false" placeholder="RWRES-XXXX-XXXX-XXXX-XXXX">
                            <p class="description"><?php echo esc_html__( 'Enter the licence key issued for RWExec Reservations.', 'rwexec-reservations' ); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button( $is_activated ? __( 'Change Licence', 'rwexec-reservations' ) : __( 'Activate Licence', 'rwexec-reservations' ), 'primary', 'submit', false ); ?>
            </form>

            <?php if ( $is_activated ) : ?>
                <div class="rwexec-license-active-grid">
                    <div class="rwexec-license-details rwexec-license-details--compact">
                        <h3><?php echo esc_html__( 'Licence Details', 'rwexec-reservations' ); ?></h3>
                        <dl>
                            <div><dt><?php echo esc_html__( 'Status', 'rwexec-reservations' ); ?></dt><dd><?php echo esc_html( $status_label ); ?></dd></div>
                            <div><dt><?php echo esc_html__( 'Expiry', 'rwexec-reservations' ); ?></dt><dd><?php echo esc_html( self::format_license_expiry( $state['expires_at'] ) ); ?></dd></div>
                            <div><dt><?php echo esc_html__( 'Activations', 'rwexec-reservations' ); ?></dt><dd><?php echo esc_html( self::format_activation_count( $state ) ); ?></dd></div>
                        </dl>
                    </div>

                    <div class="rwexec-license-actions-column">
                        <h3><?php echo esc_html__( 'Licence Actions', 'rwexec-reservations' ); ?></h3>
                        <div class="rwexec-license-actions">
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                <input type="hidden" name="action" value="rwexec_license_validate">
                                <?php wp_nonce_field( 'rwexec_license_validate' ); ?>
                                <?php submit_button( __( 'Check Licence Now', 'rwexec-reservations' ), 'secondary', 'submit', false ); ?>
                            </form>
                            <div class="rwexec-license-action-card"><a class="button button-secondary rwexec-license-account-button" href="<?php echo esc_url( RWExec_Reservations_License::account_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Manage Subscription & Billing', 'rwexec-reservations' ); ?></a></div>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Deactivate this licence on this website?', 'rwexec-reservations' ) ); ?>');">
                                <input type="hidden" name="action" value="rwexec_license_deactivate">
                                <?php wp_nonce_field( 'rwexec_license_deactivate' ); ?>
                                <?php submit_button( __( 'Deactivate Licence', 'rwexec-reservations' ), 'secondary', 'submit', false ); ?>
                            </form>
                        </div>
                    </div>
                </div>
            <?php elseif ( '' !== $license_key ) : ?>
                <div class="rwexec-license-issue" role="status">
                    <div>
                        <strong><?php echo esc_html( $status_label ); ?></strong>
                        <p><?php echo esc_html( $issue_message ); ?></p>
                    </div>
                    <div class="rwexec-license-actions">
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                            <input type="hidden" name="action" value="rwexec_license_validate">
                            <?php wp_nonce_field( 'rwexec_license_validate' ); ?>
                            <?php submit_button( __( 'Check Licence Now', 'rwexec-reservations' ), 'secondary', 'submit', false ); ?>
                        </form>
                        <div class="rwexec-license-action-card"><a class="button button-secondary rwexec-license-account-button" href="<?php echo esc_url( RWExec_Reservations_License::account_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Open RWExec Account', 'rwexec-reservations' ); ?></a></div>
                    </div>
                </div>
            <?php else : ?>
                <div class="rwexec-license-account-prompt">
                    <p><?php echo esc_html__( 'Need to find, move or manage a licence?', 'rwexec-reservations' ); ?></p>
                    <a class="button button-secondary" href="<?php echo esc_url( RWExec_Reservations_License::account_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Log in to RWExec Account', 'rwexec-reservations' ); ?></a>
                </div>
            <?php endif; ?>

            <div class="rwexec-license-policy">
                <strong><?php echo esc_html__( 'Your reservation data stays available.', 'rwexec-reservations' ); ?></strong>
                <p><?php echo esc_html__( 'A missing, expired or temporarily unreachable licence does not remove reservation data or lock staff out. Premium features simply remain unavailable until a valid licence is active.', 'rwexec-reservations' ); ?></p>
            </div>
        </div>
        <?php
    }

    private static function format_license_expiry( $expires_at ): string {
        $expires_at = trim( (string) $expires_at );
        if ( '' === $expires_at ) {
            return __( 'No expiry', 'rwexec-reservations' );
        }
        $timestamp = strtotime( $expires_at );
        return $timestamp ? wp_date( get_option( 'date_format' ), $timestamp ) : $expires_at;
    }

    private static function format_activation_count( array $state ): string {
        if ( null === $state['activations'] && null === $state['activation_limit'] ) {
            return '—';
        }
        $used = null === $state['activations'] ? 0 : absint( $state['activations'] );
        $limit = null === $state['activation_limit'] ? '—' : absint( $state['activation_limit'] );
        return $used . ' / ' . $limit;
    }

    private static function format_license_timestamp( int $timestamp ): string {
        if ( ! $timestamp ) {
            return __( 'Not checked yet', 'rwexec-reservations' );
        }
        return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
    }

    private static function render_shortcodes() {
        $shortcodes = array(
            '[rwexec_reservations]' => array(
                'Customer booking form',
                'Add this to the public page where customers make a reservation.',
            ),
            '[rwexec_reservations_admin]' => array(
                'Staff reservation management',
                'Add this to the private staff management page. Authorised staff can view, search, add and manage reservations and customers.',
            ),
            '[rwexec_logout_button]' => array(
                'Staff logout button',
                'Optional standalone logout button. The staff management screen can also show its own logout button.',
            ),
            '[rwexec_logout_button text="Sign Out"]' => array(
                'Custom logout button text',
                'Optional example showing how to change the standalone logout button label.',
            ),
        );
        ?>
        <div class="rwexec-settings-card rwexec-shortcodes-card">
            <h2><?php echo esc_html__( 'Available Shortcodes', 'rwexec-reservations' ); ?></h2>
            <p><?php echo esc_html__( 'Copy these into a WordPress Shortcode block/widget or into your page builder.', 'rwexec-reservations' ); ?></p>
            <div class="rwexec-shortcode-list">
                <?php foreach ( $shortcodes as $code => $details ) : ?>
                    <div class="rwexec-shortcode-row">
                        <div>
                            <strong><?php echo esc_html( $details[0] ); ?></strong>
                            <p><?php echo esc_html( $details[1] ); ?></p>
                        </div>
                        <div class="rwexec-shortcode-copy">
                            <code><?php echo esc_html( $code ); ?></code>
                            <button type="button" class="button rwexec-copy-shortcode" data-shortcode="<?php echo esc_attr( $code ); ?>"><?php echo esc_html__( 'Copy', 'rwexec-reservations' ); ?></button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <script>
        document.addEventListener('click',function(e){
            var b=e.target.closest('.rwexec-copy-shortcode');
            if(!b){return;}
            var text=b.getAttribute('data-shortcode')||'';
            if(navigator.clipboard&&navigator.clipboard.writeText){
                navigator.clipboard.writeText(text).then(function(){var old=b.textContent;b.textContent='Copied';setTimeout(function(){b.textContent=old;},1400);});
            }
        });
        </script>
        <?php
    }

    private static function render_setup_wizard_tab() {
        $setup_completed = '1' === (string) get_option( 'rwexec_setup_wizard_completed', '0' );
        $setup_url = add_query_arg(
            array(
                'page' => RWExec_Reservations_Setup_Page::PAGE_SLUG,
                'step' => 1,
            ),
            admin_url( 'admin.php' )
        );
        ?>
        <div class="rwexec-settings-card rwexec-setup-launcher">
            <div class="rwexec-setup-launcher__content">
                <div>
                    <h2><?php echo esc_html__( 'Setup Wizard', 'rwexec-reservations' ); ?></h2>
                    <p><?php echo esc_html__( 'Use the guided setup to configure the main restaurant details, booking rules, weekly availability and staff/form defaults.', 'rwexec-reservations' ); ?></p>
                    <p class="description"><?php echo esc_html__( 'Running the wizard again does not delete reservations, customers or existing booking data. It only updates the settings you save through the wizard.', 'rwexec-reservations' ); ?></p>
                </div>
                <span class="rwexec-setup-launcher__status <?php echo $setup_completed ? 'is-complete' : ''; ?>"><?php echo esc_html( $setup_completed ? __( 'Completed', 'rwexec-reservations' ) : __( 'Not completed', 'rwexec-reservations' ) ); ?></span>
            </div>
            <p><a class="button button-primary" href="<?php echo esc_url( $setup_url ); ?>"><?php echo esc_html( $setup_completed ? __( 'Run Setup Wizard Again', 'rwexec-reservations' ) : __( 'Run Setup Wizard', 'rwexec-reservations' ) ); ?></a></p>
        </div>
        <?php
    }

    private static function render_general() {
        ?>
        <form method="post" action="options.php">
            <?php settings_fields( 'rwexec_reservations_general_settings' ); ?>
            <h2>General Reservation Rules</h2>
            <table class="form-table" role="presentation">
                <tr><th><label for="rwexec_total_capacity">Total Venue Capacity</label></th><td><input type="number" min="1" id="rwexec_total_capacity" name="rwexec_total_capacity" value="<?php echo esc_attr( get_option( 'rwexec_total_capacity', 60 ) ); ?>"><p class="description">Total number of guests the venue can accommodate.</p></td></tr>
                <?php $premium_capacity = RWExec_Reservations_License::is_premium(); ?>
                <tr class="<?php echo $premium_capacity ? '' : 'rwexec-premium-locked'; ?>"><th><label for="rwexec_online_capacity">Reservation Capacity</label> <?php if ( ! $premium_capacity ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></th><td><fieldset <?php disabled( ! $premium_capacity ); ?>><input type="number" min="1" max="<?php echo esc_attr( get_option( 'rwexec_total_capacity', 60 ) ); ?>" id="rwexec_online_capacity" name="rwexec_online_capacity" value="<?php echo esc_attr( min( absint( get_option( 'rwexec_online_capacity', 45 ) ), absint( get_option( 'rwexec_total_capacity', 60 ) ) ) ); ?>"></fieldset><p class="description">Pro lets you reserve only part of the venue for online/manual bookings and hold the rest for walk-ins. Free uses Total Venue Capacity for all active bookings.</p></td></tr>
                <?php $capacity_mode = get_option( 'rwexec_capacity_mode', 'online_limit' ); ?>
                <tr class="<?php echo $premium_capacity ? '' : 'rwexec-premium-locked'; ?>"><th>Capacity Mode <?php if ( ! $premium_capacity ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></th><td>
                    <fieldset <?php disabled( ! $premium_capacity ); ?>>
                        <label><input type="radio" name="rwexec_capacity_mode" value="online_limit" <?php checked( $capacity_mode, 'online_limit' ); ?>> <strong>Online booking limit only</strong></label>
                        <p class="description" style="margin:4px 0 10px 24px;">Reservations are capped by Reservation Capacity. Quick-added walk-ins are recorded separately and do not reduce that online booking allowance.</p>
                        <label><input type="radio" name="rwexec_capacity_mode" value="combined_live" <?php checked( $capacity_mode, 'combined_live' ); ?>> <strong>Combined live capacity</strong></label>
                        <p class="description" style="margin:4px 0 0 24px;">Online/manual reservations plus quick-added walk-ins share Total Venue Capacity. Walk-ins immediately reduce the seats still available to book online.</p>
                    </fieldset>
                    <?php if ( ! $premium_capacity ) : ?><p class="rwexec-premium-help">Free uses one combined Total Venue Capacity. Upgrade to Pro for selectable capacity modes and a separate reservation allowance.</p><?php endif; ?>
                </td></tr>
                <tr><th><label for="rwexec_booking_interval">Booking Interval</label></th><td><input type="number" min="5" step="5" id="rwexec_booking_interval" name="rwexec_booking_interval" value="<?php echo esc_attr( get_option( 'rwexec_booking_interval', 15 ) ); ?>"> minutes</td></tr>
                <tr><th><label for="rwexec_reservation_duration">Default Table / Visit Duration</label></th><td><input type="number" min="15" step="5" id="rwexec_reservation_duration" name="rwexec_reservation_duration" value="<?php echo esc_attr( get_option( 'rwexec_reservation_duration', 105 ) ); ?>"> minutes<p class="description">How long each reservation occupies capacity. Example: 120 minutes means a 6:00pm booking occupies capacity until 8:00pm.</p></td></tr>
                <tr><th><label for="rwexec_restaurant_timezone">Restaurant Timezone</label></th><td><select id="rwexec_restaurant_timezone" name="rwexec_restaurant_timezone"><?php echo wp_timezone_choice( get_option( 'rwexec_restaurant_timezone', 'Europe/London' ) ); ?></select><p class="description">Used for reservation times, Late indicators and automatic No Show timing. For UK restaurants use Europe/London so daylight saving time is handled automatically.</p></td></tr>
                <tr><th><label for="rwexec_late_grace_minutes">Late Grace Period</label></th><td><input type="number" min="0" step="5" id="rwexec_late_grace_minutes" name="rwexec_late_grace_minutes" value="<?php echo esc_attr( get_option( 'rwexec_late_grace_minutes', 15 ) ); ?>"> minutes<p class="description">Confirmed bookings are highlighted as late after this many minutes.</p></td></tr>
                <tr><th><label for="rwexec_no_show_after_minutes">Automatic No Show</label></th><td><input type="number" min="15" step="5" id="rwexec_no_show_after_minutes" name="rwexec_no_show_after_minutes" value="<?php echo esc_attr( get_option( 'rwexec_no_show_after_minutes', 120 ) ); ?>"> minutes<p class="description">Confirmed bookings are automatically marked No Show after this many minutes past their reservation time.</p></td></tr>
                <?php $premium = RWExec_Reservations_License::is_premium(); ?>
                <tr class="<?php echo $premium ? '' : 'rwexec-premium-locked'; ?>"><th><label for="rwexec_auto_complete_checked_in">Automatic Completion</label> <?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></th><td><div class="rwexec-premium-control" <?php if ( ! $premium ) : ?>data-premium-tooltip="Upgrade to Pro to automatically complete Checked In bookings."<?php endif; ?>><fieldset <?php disabled( ! $premium ); ?>><input type="hidden" name="rwexec_auto_complete_checked_in" value="0" <?php disabled( ! $premium ); ?>><label class="rwexec-toggle-row"><input type="checkbox" id="rwexec_auto_complete_checked_in" name="rwexec_auto_complete_checked_in" value="1" <?php if ( $premium ) checked( get_option( 'rwexec_auto_complete_checked_in', '0' ), '1' ); ?> <?php disabled( ! $premium ); ?>> Automatically complete Checked In bookings</label><p><label for="rwexec_auto_complete_hours"><strong>Complete after</strong></label><br><input type="number" min="1" max="24" step="1" id="rwexec_auto_complete_hours" name="rwexec_auto_complete_hours" value="<?php echo esc_attr( get_option( 'rwexec_auto_complete_hours', 3 ) ); ?>"> hours after the scheduled booking end time</p></fieldset></div><p class="description">Only reservations still marked Checked In are changed. Completed, Cancelled, No Show and future reservations are never affected.</p></td></tr>
                <tr><th>Access Roles & Redirects</th><td>
                    <p><strong>Reservations Staff</strong><br><span class="description">Day-to-day access to reservations and customer records through the front-end management page. Staff cannot change plugin settings, export marketing contacts or permanently delete reservations, and are kept out of the WordPress dashboard.</span></p>
                    <p><strong>Reservations Admin</strong><br><span class="description">Full RWExec Reservations access including settings, special dates, email templates, marketing export and permanent delete. This role does not need full WordPress Administrator access.</span></p>
                    <p><label for="rwexec_staff_login_redirect"><strong>Staff redirect after login</strong></label><br><input type="text" class="regular-text" id="rwexec_staff_login_redirect" name="rwexec_staff_login_redirect" value="<?php echo esc_attr( get_option( 'rwexec_staff_login_redirect', '' ) ); ?>" placeholder="/restaurant-management/"><br><span class="description">Use a site path such as <code>/restaurant-management/</code>. Leave blank to send staff to the website home page.</span></p>
                    <p><label for="rwexec_admin_login_redirect"><strong>Reservations Admin redirect after login</strong></label><br><input type="text" class="regular-text" id="rwexec_admin_login_redirect" name="rwexec_admin_login_redirect" value="<?php echo esc_attr( get_option( 'rwexec_admin_login_redirect', '' ) ); ?>" placeholder="/wp-admin/admin.php?page=rwexec-reservations"><br><span class="description">Leave blank to open the RWExec Reservations admin screen automatically.</span></p>
                </td></tr>
                <tr><th>Staff Logout</th><td><label class="rwexec-toggle-row"><input type="hidden" name="rwexec_staff_show_logout" value="0"><input type="checkbox" name="rwexec_staff_show_logout" value="1" <?php checked( get_option( 'rwexec_staff_show_logout', '1' ), '1' ); ?>> Show Log Out button below the staff reservation list</label><p><label for="rwexec_staff_logout_redirect"><strong>Redirect after logout</strong></label><br><input type="text" class="regular-text" id="rwexec_staff_logout_redirect" name="rwexec_staff_logout_redirect" value="<?php echo esc_attr( get_option( 'rwexec_staff_logout_redirect', '' ) ); ?>" placeholder="/adminteamlogin/"></p><p><label for="rwexec_staff_logout_text"><strong>Button text</strong></label><br><input type="text" id="rwexec_staff_logout_text" name="rwexec_staff_logout_text" value="<?php echo esc_attr( get_option( 'rwexec_staff_logout_text', 'Log Out' ) ); ?>"></p><p class="description">The standalone shortcode <code>[rwexec_logout_button]</code> uses the same redirect. You can override its text with <code>[rwexec_logout_button text=&quot;Sign Out&quot;]</code>.</p></td></tr>
                <tr><th>Plugin Data on Uninstall</th><td>
                    <input type="hidden" name="rwexec_delete_data_on_uninstall" value="0">
                    <label class="rwexec-toggle-row"><input type="checkbox" name="rwexec_delete_data_on_uninstall" value="1" <?php checked( get_option( 'rwexec_delete_data_on_uninstall', '0' ), '1' ); ?>> Permanently delete all RWExec Reservations data when the plugin is deleted</label>
                    <p class="description"><strong>Leave this unchecked for normal use.</strong> Deactivating the plugin never deletes reservation data. If this option is enabled and the plugin is then deleted from WordPress, reservations, customers, special dates, plugin settings, stored email/template settings and RWExec reservation roles will be permanently removed.</p>
                </td></tr>
            </table>
                <script>
                document.addEventListener('DOMContentLoaded', function () {
                    const total = document.getElementById('rwexec_total_capacity');
                    const reservations = document.getElementById('rwexec_online_capacity');

                    if (!total || !reservations) {
                        return;
                    }

                    const syncReservationCapacity = function () {
                        const totalValue = Math.max(1, parseInt(total.value || '1', 10));
                        reservations.max = String(totalValue);

                        if (parseInt(reservations.value || '1', 10) > totalValue) {
                            reservations.value = String(totalValue);
                        }
                    };

                    total.addEventListener('input', syncReservationCapacity);
                    syncReservationCapacity();
                });
                </script>

            <?php submit_button( 'Save General Settings' ); ?>
        </form>
        <?php
    }

    private static function render_availability() {
        ?>
        <form method="post" action="options.php">
            <?php settings_fields( 'rwexec_reservations_availability_settings' ); ?>
            <h2>Bookable Hours</h2>
            <p>Set the normal weekly hours customers can choose on the booking form. Special Dates override these hours.</p>
            <table class="form-table" role="presentation">
                <tr><th>Weekly Schedule</th><td>
                    <?php foreach ( RWExec_Reservations_Settings::get_days() as $day => $label ) :
                        $status = get_option( 'rwexec_' . $day . '_booking_status', 'open' );
                        $start = get_option( 'rwexec_' . $day . '_booking_start', '12:00' );
                        $end = get_option( 'rwexec_' . $day . '_booking_end', '22:00' );
                        ?>
                        <div class="rwexec-weekly-row">
                            <strong class="rwexec-weekly-day"><?php echo esc_html( $label ); ?></strong>
                            <select class="rwexec-weekly-status" name="<?php echo esc_attr( 'rwexec_' . $day . '_booking_status' ); ?>">
                                <option value="open" <?php selected( $status, 'open' ); ?>>Open for bookings</option>
                                <option value="walk_ins_only" <?php selected( $status, 'walk_ins_only' ); ?>>Walk-ins only</option>
                                <option value="closed" <?php selected( $status, 'closed' ); ?>>Closed</option>
                            </select>
                            <input class="rwexec-weekly-time" type="time" name="<?php echo esc_attr( 'rwexec_' . $day . '_booking_start' ); ?>" value="<?php echo esc_attr( $start ); ?>">
                            <span>to</span>
                            <input class="rwexec-weekly-time" type="time" name="<?php echo esc_attr( 'rwexec_' . $day . '_booking_end' ); ?>" value="<?php echo esc_attr( $end ); ?>">
                        </div>
                    <?php endforeach; ?>
                    <p class="description">These are first and last booking times. Capacity is calculated separately for every time slot using the configured visit duration.</p>
                </td></tr>
            </table>
            <?php submit_button( 'Save Availability' ); ?>
        </form>
        <?php
    }

    private static function render_booking_form() {
        $core = RWExec_Reservations_Form_Builder::get_core_fields();
        $order = RWExec_Reservations_Form_Builder::get_field_order();
        $premium = RWExec_Reservations_License::is_premium();
        $booking_section = sanitize_key( wp_unslash( $_GET['booking-section'] ?? 'form' ) );
        if ( ! in_array( $booking_section, array( 'form', 'styling' ), true ) ) {
            $booking_section = 'form';
        }
        $section_url = function ( string $section ): string {
            return add_query_arg(
                array(
                    'page' => 'rwexec-reservations-settings',
                    'tab' => 'booking-form',
                    'booking-section' => $section,
                ),
                admin_url( 'admin.php' )
            );
        };
        ?>
        <nav class="nav-tab-wrapper rwexec-booking-form-tabs">
            <a class="nav-tab <?php echo 'form' === $booking_section ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $section_url( 'form' ) ); ?>">Form</a>
            <a class="nav-tab <?php echo 'styling' === $booking_section ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $section_url( 'styling' ) ); ?>">Styling</a>
        </nav>

        <form method="post" action="options.php" id="rwexec-booking-form-settings">
            <?php if ( 'styling' === $booking_section ) : ?>
                <?php settings_fields( 'rwexec_reservations_booking_form_styling_settings' ); ?>
            <?php else : ?>
                <?php settings_fields( 'rwexec_reservations_booking_form_settings' ); ?>
                <?php settings_errors( 'rwexec_public_core_fields' ); ?>
            <?php endif; ?>

            <?php if ( 'form' === $booking_section ) : ?>
                <h2>Online Booking Form</h2>
                <table class="form-table" role="presentation">
                    <tr><th><label for="rwexec_form_heading">Form Heading</label></th><td><input type="text" class="regular-text" id="rwexec_form_heading" name="rwexec_form_heading" value="<?php echo esc_attr( get_option( 'rwexec_form_heading', '' ) ); ?>" placeholder="Book a Table"><p class="description">Optional. Leave blank to show no heading, for example when Elementor provides the page heading.</p></td></tr>
                    <tr><th><label for="rwexec_form_subheading">Form Subheading</label></th><td><textarea class="large-text" rows="2" id="rwexec_form_subheading" name="rwexec_form_subheading" placeholder="Reserve your table online."><?php echo esc_textarea( get_option( 'rwexec_form_subheading', '' ) ); ?></textarea><p class="description">Optional supporting text displayed directly below the form heading.</p></td></tr>
                    <tr><th><label for="rwexec_public_max_party_size">Maximum Online Party Size</label></th><td><input type="number" min="1" id="rwexec_public_max_party_size" name="rwexec_public_max_party_size" value="<?php echo esc_attr( get_option( 'rwexec_public_max_party_size', 12 ) ); ?>"><p class="description">Largest party customers can book through the public form. Larger groups can still be added manually by staff.</p></td></tr>
                    <tr><th><label for="rwexec_public_advance_days">Booking Window</label></th><td><input type="number" min="1" id="rwexec_public_advance_days" name="rwexec_public_advance_days" value="<?php echo esc_attr( get_option( 'rwexec_public_advance_days', 90 ) ); ?>"> days ahead</td></tr>
                    <tr><th><label for="rwexec_public_min_notice_minutes">Minimum Booking Notice</label></th><td><input type="number" min="0" step="15" id="rwexec_public_min_notice_minutes" name="rwexec_public_min_notice_minutes" value="<?php echo esc_attr( get_option( 'rwexec_public_min_notice_minutes', 60 ) ); ?>"> minutes</td></tr>
                    <tr><th>Booking Form Shortcode</th><td><code>[rwexec_reservations]</code><p class="description">Add this shortcode to any WordPress page or Elementor Shortcode widget.</p></td></tr>
                </table>

                <div class="rwexec-settings-card">
                    <h2>Booking & Marketing Communications</h2>
                    <p class="description">Booking messages are service communications. Marketing consent is a separate optional email opt-in and is never required to make a reservation.</p>
                    <table class="form-table" role="presentation">
                        <tr><th><label for="rwexec_booking_communications_text">Booking communications text</label></th><td><textarea class="large-text" rows="3" id="rwexec_booking_communications_text" name="rwexec_booking_communications_text"><?php echo esc_textarea( get_option( 'rwexec_booking_communications_text', 'We’ll use your contact details to send information about this reservation, such as your confirmation, updates and reminders.' ) ); ?></textarea><p class="description">Displayed above the marketing preference on the public booking form.</p></td></tr>
                        <?php $premium = RWExec_Reservations_License::is_premium(); ?>
                        <tr class="<?php echo $premium ? '' : 'rwexec-premium-locked'; ?>"><th><label for="rwexec_marketing_consent_label">Marketing heading</label> <?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></th><td><fieldset <?php disabled( ! $premium ); ?>><input type="text" class="regular-text" id="rwexec_marketing_consent_label" name="rwexec_marketing_consent_label" value="<?php echo esc_attr( get_option( 'rwexec_marketing_consent_label', 'Keep me updated' ) ); ?>"></fieldset></td></tr>
                        <tr class="<?php echo $premium ? '' : 'rwexec-premium-locked'; ?>"><th><label for="rwexec_marketing_consent_text">Marketing consent wording</label> <?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></th><td><fieldset <?php disabled( ! $premium ); ?>><textarea class="large-text" rows="3" id="rwexec_marketing_consent_text" name="rwexec_marketing_consent_text"><?php echo esc_textarea( get_option( 'rwexec_marketing_consent_text', 'I’d like to receive occasional news, offers and updates from {restaurant_name} by email.' ) ); ?></textarea></fieldset><p class="description">Premium adds the optional marketing opt-in and stores the exact consent wording and acceptance time.</p></td></tr>
                    </table>
                </div>

            <h2 class="rwexec-section-heading">Booking Form Fields</h2>
            <p>Date, Guests, Time and Name are required by the booking system. Customer-detail fields can be reordered with the arrows.</p>
            <p><strong>Contact rule:</strong> at least one of Email or Phone must be visible and required.</p>

            <div class="rwexec-field-builder">
                <h3 class="rwexec-field-builder__section-title">Booking selection</h3>
                <div class="rwexec-builder-system-row">
                    <div><strong>Date</strong><div class="rwexec-row-type">Calendar</div></div>
                    <span class="rwexec-builder-locked">Visible</span><span class="rwexec-builder-locked">Required</span><span class="rwexec-builder-locked">Locked</span>
                </div>
                <?php self::render_core_builder_row( 'guests', $core['guests'], 'Number of guests', true, false ); ?>
                <?php self::render_core_builder_row( 'time', $core['time'], 'Available time', true, false ); ?>

                <h3 class="rwexec-field-builder__section-title">Customer details</h3>
                <div id="rwexec-form-builder-rows">
                    <?php foreach ( $order as $token ) :
                        if ( 0 === strpos( $token, 'core:' ) ) {
                            $key = substr( $token, 5 );
                            if ( isset( $core[ $key ] ) ) {
                                $types = array(
                                    'name' => 'Text field',
                                    'phone' => 'Telephone',
                                    'email' => 'Email',
                                    'allergies' => 'Textarea',
                                    'additional_information' => 'Textarea',
                                );
                                self::render_core_builder_row( $key, $core[ $key ], $types[ $key ] ?? 'Field', 'name' === $key, true );
                            }
                        } elseif ( 0 === strpos( $token, 'custom:' ) ) {
                            $field = RWExec_Reservations_Form_Builder::get_custom_field( substr( $token, 7 ) );
                            if ( $field ) {
                                self::render_builder_row( $field );
                            }
                        }
                    endforeach; ?>
                </div>
                <div class="rwexec-custom-fields-action <?php echo $premium ? '' : 'rwexec-premium-locked-inline'; ?>">
                    <?php if ( $premium ) : ?>
                        <button type="button" class="button" id="rwexec-add-form-field">Add Field / Note</button>
                    <?php else : ?>
                        <button type="button" class="button" disabled aria-disabled="true" title="Custom booking fields are available with Premium.">Add Field / Note</button>
                        <?php echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?>
                    <?php endif; ?>
                </div>
                <p class="description">Information notes can use {max_guests}, {restaurant_phone}, {restaurant_email} and {restaurant_name}. Custom fields and notes are a Premium feature.</p>
            </div>

                <?php submit_button( 'Save Booking Form' ); ?>
            <?php else : ?>
                <h2>Booking Form Styling <?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></h2>
                <?php if ( ! $premium ) : ?>
                    <div class="rwexec-premium-gate"><div class="rwexec-premium-gate__icon"><?php echo wp_kses_post( RWExec_Reservations_License::premium_icon() ); ?></div><div><h3>Advanced booking-form styling is a Pro feature</h3><p>Free uses the clean built-in form styling and can still set the form heading, booking rules and core fields. Pro unlocks typography, colours, borders, buttons and detailed visual customisation.</p><?php echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></div></div>
                <?php else : ?>
                <p class="description">Style the shortcode without custom CSS. Inherit website font is the default so the form can match WordPress, your theme or Elementor typography.</p>

                <div class="rwexec-settings-card">
                    <h3>Typography</h3>
                    <table class="form-table rwexec-styling-grid-table" role="presentation">
                        <tr><th><label for="rwexec_form_font_family">Font Family</label></th><td>
                            <select id="rwexec_form_font_family" name="rwexec_form_font_family">
                                <?php
                                $font_value = get_option( 'rwexec_form_font_family', 'inherit' );
                                $font_choices = array(
                                    'inherit' => 'Inherit website font',
                                    'system' => 'System / UI Sans Serif',
                                    'arial' => 'Arial',
                                    'helvetica' => 'Helvetica',
                                    'georgia' => 'Georgia',
                                    'verdana' => 'Verdana',
                                    'trebuchet' => 'Trebuchet MS',
                                );
                                foreach ( $font_choices as $value => $label ) :
                                ?>
                                    <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $font_value, $value ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td></tr>
                        <tr><th><label for="rwexec_form_heading_font_size">Heading Size</label></th><td><input type="number" min="16" max="48" id="rwexec_form_heading_font_size" name="rwexec_form_heading_font_size" value="<?php echo esc_attr( get_option( 'rwexec_form_heading_font_size', 28 ) ); ?>"> px</td></tr>
                        <tr><th><label for="rwexec_form_heading_font_weight">Heading Weight</label></th><td><select id="rwexec_form_heading_font_weight" name="rwexec_form_heading_font_weight"><?php foreach ( array( 400, 500, 600, 700, 800 ) as $weight ) : ?><option value="<?php echo esc_attr( $weight ); ?>" <?php selected( absint( get_option( 'rwexec_form_heading_font_weight', 700 ) ), $weight ); ?>><?php echo esc_html( $weight ); ?></option><?php endforeach; ?></select></td></tr>
                        <tr><th><label for="rwexec_form_subheading_font_size">Subheading Size</label></th><td><input type="number" min="11" max="24" id="rwexec_form_subheading_font_size" name="rwexec_form_subheading_font_size" value="<?php echo esc_attr( get_option( 'rwexec_form_subheading_font_size', 14 ) ); ?>"> px</td></tr>
                        <tr><th><label for="rwexec_form_font_size">Field Font Size</label></th><td><input type="number" min="12" max="20" id="rwexec_form_font_size" name="rwexec_form_font_size" value="<?php echo esc_attr( get_option( 'rwexec_form_font_size', 14 ) ); ?>"> px</td></tr>
                        <tr><th><label for="rwexec_form_label_font_size">Label Font Size</label></th><td><input type="number" min="11" max="18" id="rwexec_form_label_font_size" name="rwexec_form_label_font_size" value="<?php echo esc_attr( get_option( 'rwexec_form_label_font_size', 13 ) ); ?>"> px</td></tr>
                        <tr><th><label for="rwexec_form_border_radius">Field / Button Radius</label></th><td><input type="number" min="0" max="24" id="rwexec_form_border_radius" name="rwexec_form_border_radius" value="<?php echo esc_attr( get_option( 'rwexec_form_border_radius', 7 ) ); ?>"> px</td></tr>
                    </table>
                </div>

                <div class="rwexec-settings-card">
                    <h3>Colours</h3>
                    <table class="form-table rwexec-styling-grid-table rwexec-styling-grid-table--colours" role="presentation">
                        <tr><th><label for="rwexec_form_heading_color">Heading Colour</label></th><td><input type="color" id="rwexec_form_heading_color" name="rwexec_form_heading_color" value="<?php echo esc_attr( get_option( 'rwexec_form_heading_color', '#1e293b' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_subheading_color">Subheading Colour</label></th><td><input type="color" id="rwexec_form_subheading_color" name="rwexec_form_subheading_color" value="<?php echo esc_attr( get_option( 'rwexec_form_subheading_color', '#64748b' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_background_color">Form Background</label></th><td><input type="color" id="rwexec_form_background_color" name="rwexec_form_background_color" value="<?php echo esc_attr( get_option( 'rwexec_form_background_color', '#ffffff' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_border_color">Form Border</label></th><td><input type="color" id="rwexec_form_border_color" name="rwexec_form_border_color" value="<?php echo esc_attr( get_option( 'rwexec_form_border_color', '#e2e8f0' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_label_color">Label Colour</label></th><td><input type="color" id="rwexec_form_label_color" name="rwexec_form_label_color" value="<?php echo esc_attr( get_option( 'rwexec_form_label_color', '#1e293b' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_required_color">Required Asterisk</label></th><td><input type="color" id="rwexec_form_required_color" name="rwexec_form_required_color" value="<?php echo esc_attr( get_option( 'rwexec_form_required_color', '#dc2626' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_field_background_color">Field Background</label></th><td><input type="color" id="rwexec_form_field_background_color" name="rwexec_form_field_background_color" value="<?php echo esc_attr( get_option( 'rwexec_form_field_background_color', '#ffffff' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_field_border_color">Field Border</label></th><td><input type="color" id="rwexec_form_field_border_color" name="rwexec_form_field_border_color" value="<?php echo esc_attr( get_option( 'rwexec_form_field_border_color', '#cbd5e1' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_field_text_color">Field Text</label></th><td><input type="color" id="rwexec_form_field_text_color" name="rwexec_form_field_text_color" value="<?php echo esc_attr( get_option( 'rwexec_form_field_text_color', '#1e293b' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_placeholder_color">Placeholder Text</label></th><td><input type="color" id="rwexec_form_placeholder_color" name="rwexec_form_placeholder_color" value="<?php echo esc_attr( get_option( 'rwexec_form_placeholder_color', '#94a3b8' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_focus_color">Focused Field Border</label></th><td><input type="color" id="rwexec_form_focus_color" name="rwexec_form_focus_color" value="<?php echo esc_attr( get_option( 'rwexec_form_focus_color', '#1e293b' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_button_background_color">Button Background</label></th><td><input type="color" id="rwexec_form_button_background_color" name="rwexec_form_button_background_color" value="<?php echo esc_attr( get_option( 'rwexec_form_button_background_color', '#1e293b' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_button_text_color">Button Text</label></th><td><input type="color" id="rwexec_form_button_text_color" name="rwexec_form_button_text_color" value="<?php echo esc_attr( get_option( 'rwexec_form_button_text_color', '#ffffff' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_button_hover_background_color">Button Hover Background</label></th><td><input type="color" id="rwexec_form_button_hover_background_color" name="rwexec_form_button_hover_background_color" value="<?php echo esc_attr( get_option( 'rwexec_form_button_hover_background_color', '#334155' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_button_hover_text_color">Button Hover Text</label></th><td><input type="color" id="rwexec_form_button_hover_text_color" name="rwexec_form_button_hover_text_color" value="<?php echo esc_attr( get_option( 'rwexec_form_button_hover_text_color', '#ffffff' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_consent_background_color">Consent Box Background</label></th><td><input type="color" id="rwexec_form_consent_background_color" name="rwexec_form_consent_background_color" value="<?php echo esc_attr( get_option( 'rwexec_form_consent_background_color', '#f8fafc' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_consent_border_color">Consent Box Border</label></th><td><input type="color" id="rwexec_form_consent_border_color" name="rwexec_form_consent_border_color" value="<?php echo esc_attr( get_option( 'rwexec_form_consent_border_color', '#e2e8f0' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_consent_text_color">Consent Heading Text</label></th><td><input type="color" id="rwexec_form_consent_text_color" name="rwexec_form_consent_text_color" value="<?php echo esc_attr( get_option( 'rwexec_form_consent_text_color', '#1e293b' ) ); ?>"></td></tr>
                        <tr><th><label for="rwexec_form_consent_muted_color">Consent Supporting Text</label></th><td><input type="color" id="rwexec_form_consent_muted_color" name="rwexec_form_consent_muted_color" value="<?php echo esc_attr( get_option( 'rwexec_form_consent_muted_color', '#64748b' ) ); ?>"></td></tr>
                    </table>
                </div>
                <?php submit_button( 'Save Styling' ); ?>
                <?php endif; ?>
            <?php endif; ?>
        </form>
        <?php if ( 'form' === $booking_section ) : self::builder_script(); endif; ?>
        <?php
    }

    private static function render_core_builder_row( string $key, array $cfg, string $type, bool $locked, bool $ordered ) {
        $token = 'core:' . $key;
        ?>
        <div class="rwexec-builder-row rwexec-builder-row--core" <?php if ( $ordered ) : ?>data-order-token="<?php echo esc_attr( $token ); ?>"<?php endif; ?>>
            <?php if ( $ordered ) : ?><input type="hidden" class="rwexec-order-input" name="rwexec_public_field_order[]" value="<?php echo esc_attr( $token ); ?>"><?php endif; ?>
            <div class="rwexec-builder-row__summary">
                <div class="rwexec-builder-row__name"><strong class="rwexec-core-title-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $cfg['label'] ); ?></strong><div class="rwexec-row-type"><?php echo esc_html( $type ); ?></div></div>
                <label><input type="checkbox" <?php checked( ! empty( $cfg['visible'] ) ); ?> <?php disabled( $locked ); ?> <?php if ( ! $locked ) : ?>name="rwexec_public_core_fields[<?php echo esc_attr( $key ); ?>][visible]" value="1"<?php endif; ?>> Visible</label>
                <label><input type="checkbox" <?php checked( ! empty( $cfg['required'] ) ); ?> <?php disabled( $locked ); ?> <?php if ( ! $locked ) : ?>name="rwexec_public_core_fields[<?php echo esc_attr( $key ); ?>][required]" value="1"<?php endif; ?>> Required</label>
                <div class="rwexec-builder-row__actions">
                    <?php if ( $ordered ) : ?><button type="button" class="button rwexec-move-up" title="Move up">↑</button><button type="button" class="button rwexec-move-down" title="Move down">↓</button><?php endif; ?>
                    <button type="button" class="button rwexec-edit-core" data-target="rwexec-core-<?php echo esc_attr( $key ); ?>">Edit</button>
                </div>
            </div>
            <?php if ( $locked ) : ?>
                <input type="hidden" name="rwexec_public_core_fields[<?php echo esc_attr( $key ); ?>][visible]" value="1">
                <input type="hidden" name="rwexec_public_core_fields[<?php echo esc_attr( $key ); ?>][required]" value="1">
            <?php endif; ?>
            <input type="hidden" name="rwexec_public_core_fields[<?php echo esc_attr( $key ); ?>][label]" value="<?php echo esc_attr( $cfg['label'] ); ?>">
            <input type="hidden" name="rwexec_public_core_fields[<?php echo esc_attr( $key ); ?>][placeholder]" value="<?php echo esc_attr( $cfg['placeholder'] ); ?>">
            <div id="rwexec-core-<?php echo esc_attr( $key ); ?>" class="rwexec-field-editor" style="display:none">
                <div class="rwexec-editor-grid">
                    <label>Field Label<input class="regular-text rwexec-core-label" type="text" value="<?php echo esc_attr( $cfg['label'] ); ?>"></label>
                    <label>Placeholder Text<input class="regular-text rwexec-core-placeholder" type="text" value="<?php echo esc_attr( $cfg['placeholder'] ); ?>"></label>
                </div>
                <p><button type="button" class="button button-primary rwexec-save-core">Save Field</button> <button type="button" class="button rwexec-cancel-core">Cancel</button></p>
            </div>
        </div>
        <?php
    }

    private static function render_emails() {
        $color = static function ( string $option, string $default ): string {
            return esc_attr( get_option( $option, $default ) );
        };
        ?>
        <form method="post" action="options.php" class="rwexec-email-settings-form">
            <?php settings_fields( 'rwexec_reservations_email_settings' ); ?>

            <div class="rwexec-settings-card rwexec-email-delivery-guidance">
                <h2><?php echo esc_html__( 'Email Delivery', 'rwexec-reservations' ); ?></h2>
                <p><?php echo esc_html__( 'RWExec Reservations sends mail through WordPress wp_mail(). WordPress accepting an email does not guarantee that it reaches the recipient.', 'rwexec-reservations' ); ?></p>
                <ul class="rwexec-guidance-list">
                    <li><?php echo esc_html__( 'For production sites, configure authenticated SMTP or a transactional email provider.', 'rwexec-reservations' ); ?></li>
                    <li><?php echo esc_html__( 'Use a From Email address on the restaurant website’s own domain where possible.', 'rwexec-reservations' ); ?></li>
                    <li><?php echo esc_html__( 'Configure SPF and DKIM with the chosen mail provider to improve deliverability.', 'rwexec-reservations' ); ?></li>
                    <li><?php echo esc_html__( 'Send test messages from Email Templates after configuring delivery and check both inbox and spam folders.', 'rwexec-reservations' ); ?></li>
                </ul>
                <p class="description"><?php echo esc_html__( 'SMTP credentials are intentionally not stored by RWExec Reservations. Use a dedicated WordPress SMTP/mail-delivery plugin or hosting mail service.', 'rwexec-reservations' ); ?></p>
            </div>

            <div class="rwexec-settings-card">
                <h2>Restaurant & Delivery</h2>
                <p class="description">These details are used for sending and in the branded email footer.</p>
                <table class="form-table" role="presentation">
                    <tr><th><label for="rwexec_email_restaurant_name">Restaurant Name</label></th><td><input type="text" class="regular-text" id="rwexec_email_restaurant_name" name="rwexec_email_restaurant_name" value="<?php echo esc_attr( get_option( 'rwexec_email_restaurant_name', get_bloginfo( 'name' ) ) ); ?>"></td></tr>
                    <tr><th><label for="rwexec_email_from_name">From Name</label></th><td><input type="text" class="regular-text" id="rwexec_email_from_name" name="rwexec_email_from_name" value="<?php echo esc_attr( get_option( 'rwexec_email_from_name', get_bloginfo( 'name' ) ) ); ?>"></td></tr>
                    <tr><th><label for="rwexec_email_from_email">From Email</label></th><td><input type="email" class="regular-text" id="rwexec_email_from_email" name="rwexec_email_from_email" value="<?php echo esc_attr( get_option( 'rwexec_email_from_email', get_option( 'admin_email' ) ) ); ?>"><p class="description">Use an address on this website's domain and configure SMTP/mail delivery for reliable sending.</p></td></tr>
                    <tr><th><label for="rwexec_email_contact_email">Contact Email</label></th><td><input type="email" class="regular-text" id="rwexec_email_contact_email" name="rwexec_email_contact_email" value="<?php echo esc_attr( get_option( 'rwexec_email_contact_email', get_option( 'admin_email' ) ) ); ?>"></td></tr>
                    <tr><th><label for="rwexec_email_restaurant_phone">Restaurant Phone</label></th><td><input type="text" class="regular-text" id="rwexec_email_restaurant_phone" name="rwexec_email_restaurant_phone" value="<?php echo esc_attr( get_option( 'rwexec_email_restaurant_phone', '' ) ); ?>"></td></tr>
                    <tr><th><label for="rwexec_email_restaurant_address">Restaurant Address</label></th><td><textarea class="large-text" rows="3" id="rwexec_email_restaurant_address" name="rwexec_email_restaurant_address"><?php echo esc_textarea( get_option( 'rwexec_email_restaurant_address', '' ) ); ?></textarea></td></tr>
                    <tr><th><label for="rwexec_email_website_url">Website</label></th><td><input type="url" class="regular-text" id="rwexec_email_website_url" name="rwexec_email_website_url" value="<?php echo esc_attr( get_option( 'rwexec_email_website_url', home_url( '/' ) ) ); ?>"></td></tr>
                    <tr><th><label for="rwexec_email_admin_recipient">Restaurant Notification Email</label></th><td><input type="email" class="regular-text" id="rwexec_email_admin_recipient" name="rwexec_email_admin_recipient" value="<?php echo esc_attr( get_option( 'rwexec_email_admin_recipient', get_option( 'admin_email' ) ) ); ?>"></td></tr>
                    <tr><th><label for="rwexec_email_test_recipient">Test Email Recipient</label></th><td><input type="email" class="regular-text" id="rwexec_email_test_recipient" name="rwexec_email_test_recipient" value="<?php echo esc_attr( get_option( 'rwexec_email_test_recipient', get_option( 'admin_email' ) ) ); ?>"></td></tr>
                </table>
            </div>

            <div class="rwexec-settings-card">
                <h2>Header & Email Design</h2>
                <table class="form-table" role="presentation">
                    <tr><th><label for="rwexec_email_logo_url">Header Logo URL</label></th><td><input type="url" class="large-text" id="rwexec_email_logo_url" name="rwexec_email_logo_url" value="<?php echo esc_attr( get_option( 'rwexec_email_logo_url', '' ) ); ?>"><p class="description">Full URL to the restaurant logo. Leave blank to show the restaurant name instead.</p></td></tr>
                    <tr><th><label for="rwexec_email_logo_width">Logo Width</label></th><td><input type="number" min="60" max="260" id="rwexec_email_logo_width" name="rwexec_email_logo_width" value="<?php echo esc_attr( get_option( 'rwexec_email_logo_width', 115 ) ); ?>"> px</td></tr>
                    <tr><th>Heading Style</th><td><select name="rwexec_email_heading_font"><option value="serif" <?php selected( get_option( 'rwexec_email_heading_font', 'serif' ), 'serif' ); ?>>Classic serif</option><option value="sans" <?php selected( get_option( 'rwexec_email_heading_font', 'serif' ), 'sans' ); ?>>Modern sans-serif</option></select> &nbsp; <input type="number" min="20" max="42" name="rwexec_email_heading_size" value="<?php echo esc_attr( get_option( 'rwexec_email_heading_size', 32 ) ); ?>"> px<br><label><input type="hidden" name="rwexec_email_heading_divider" value="0"><input type="checkbox" name="rwexec_email_heading_divider" value="1" <?php checked( get_option( 'rwexec_email_heading_divider', '1' ), '1' ); ?>> Show accent divider below heading</label></td></tr>
                    <tr><th>Brand Colours</th><td><div class="rwexec-email-colour-grid">
                        <label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Primary</span><input type="color" name="rwexec_email_accent_color" value="<?php echo $color( 'rwexec_email_accent_color', '#1e293b' ); ?>"></label>
                        <label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Accent</span><input type="color" name="rwexec_email_secondary_color" value="<?php echo $color( 'rwexec_email_secondary_color', '#c79a2b' ); ?>"></label>
                        <label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Outer background</span><input type="color" name="rwexec_email_background_color" value="<?php echo $color( 'rwexec_email_background_color', '#f3f4f6' ); ?>"></label>
                        <label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Content background</span><input type="color" name="rwexec_email_content_background_color" value="<?php echo $color( 'rwexec_email_content_background_color', '#ffffff' ); ?>"></label>
                        <label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Body text</span><input type="color" name="rwexec_email_text_color" value="<?php echo $color( 'rwexec_email_text_color', '#334155' ); ?>"></label>
                    </div></td></tr>
                    <tr><th>Reservation Details Box</th><td><div class="rwexec-email-colour-grid"><label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Background</span><input type="color" name="rwexec_email_details_background_color" value="<?php echo $color( 'rwexec_email_details_background_color', '#f8fafc' ); ?>"></label><label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Border</span><input type="color" name="rwexec_email_details_border_color" value="<?php echo $color( 'rwexec_email_details_border_color', '#e2e8f0' ); ?>"></label></div></td></tr>
                    <tr><th>Button Style</th><td><div class="rwexec-email-colour-grid"><label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Button</span><input type="color" name="rwexec_email_button_color" value="<?php echo $color( 'rwexec_email_button_color', '#1e293b' ); ?>"></label><label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Text</span><input type="color" name="rwexec_email_button_text_color" value="<?php echo $color( 'rwexec_email_button_text_color', '#ffffff' ); ?>"></label><label class="rwexec-email-colour-control rwexec-email-number-control"><span class="rwexec-email-colour-label">Corner radius</span><span class="rwexec-email-number-with-unit"><input type="number" min="0" max="20" name="rwexec_email_button_radius" value="<?php echo esc_attr( get_option( 'rwexec_email_button_radius', 6 ) ); ?>"><span>px</span></span></label></div></td></tr>
                </table>
            </div>

            <div class="rwexec-settings-card">
                <h2>Footer Design</h2>
                <table class="form-table" role="presentation">
                    <tr><th><label for="rwexec_email_footer_logo_url">Footer Logo URL</label></th><td><input type="url" class="large-text" id="rwexec_email_footer_logo_url" name="rwexec_email_footer_logo_url" value="<?php echo esc_attr( get_option( 'rwexec_email_footer_logo_url', '' ) ); ?>"><p class="description">Optional. Leave blank to reuse the header logo.</p></td></tr>
                    <tr><th>Footer Colours</th><td><div class="rwexec-email-colour-grid"><label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Background</span><input type="color" name="rwexec_email_footer_background_color" value="<?php echo $color( 'rwexec_email_footer_background_color', '#1e293b' ); ?>"></label><label class="rwexec-email-colour-control"><span class="rwexec-email-colour-label">Text</span><input type="color" name="rwexec_email_footer_text_color" value="<?php echo $color( 'rwexec_email_footer_text_color', '#ffffff' ); ?>"></label></div></td></tr>
                    <tr><th>Footer Content</th><td><label class="rwexec-toggle-row"><input type="hidden" name="rwexec_email_footer_contact" value="0"><input type="checkbox" name="rwexec_email_footer_contact" value="1" <?php checked( get_option( 'rwexec_email_footer_contact', '1' ), '1' ); ?>> Show address, phone, email and website</label><label class="rwexec-toggle-row"><input type="hidden" name="rwexec_email_footer_copyright" value="0"><input type="checkbox" name="rwexec_email_footer_copyright" value="1" <?php checked( get_option( 'rwexec_email_footer_copyright', '1' ), '1' ); ?>> Show copyright line</label></td></tr>
                    <tr><th><label for="rwexec_email_footer_text">Additional Footer Text</label></th><td><textarea class="large-text" rows="3" id="rwexec_email_footer_text" name="rwexec_email_footer_text"><?php echo esc_textarea( get_option( 'rwexec_email_footer_text', '' ) ); ?></textarea></td></tr>
                </table>
            </div>

            <div class="rwexec-settings-card">
                <h2>Automation</h2>
                <table class="form-table" role="presentation">
                    <?php $premium = RWExec_Reservations_License::is_premium(); ?>
                    <tr><th>Email Types</th><td><?php $email_types = array( 'confirmation'=>'Booking confirmation', 'update'=>'Booking changed', 'cancellation'=>'Cancellation', 'reminder'=>'Reservation reminder', 'feedback'=>'Feedback request', 'admin_new_booking'=>'New booking notification to restaurant', 'admin_update'=>'Booking updated notification to restaurant', 'admin_cancellation'=>'Cancellation notification to restaurant', 'admin_status'=>'Status change notification to restaurant' ); foreach ( $email_types as $key => $label ) : $locked = ( in_array( $key, array( 'reminder', 'feedback' ), true ) && ! $premium ); ?><label class="rwexec-toggle-row <?php echo $locked ? 'rwexec-premium-locked-inline' : ''; ?>"><input type="hidden" name="<?php echo esc_attr( 'rwexec_email_' . $key . '_enabled' ); ?>" value="0" <?php disabled( $locked ); ?>><input type="checkbox" name="<?php echo esc_attr( 'rwexec_email_' . $key . '_enabled' ); ?>" value="1" <?php if ( ! $locked ) checked( get_option( 'rwexec_email_' . $key . '_enabled', '1' ), '1' ); ?> <?php disabled( $locked ); ?>> <?php echo esc_html( $label ); ?><?php if ( $locked ) : ?> <?php echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?><?php endif; ?></label><?php endforeach; ?></td></tr>
                    <tr class="<?php echo $premium ? '' : 'rwexec-premium-locked'; ?>"><th><label for="rwexec_email_reminder_hours">Reminder Timing</label> <?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></th><td><?php if ( $premium ) : ?><input type="number" min="1" max="168" id="rwexec_email_reminder_hours" name="rwexec_email_reminder_hours" value="<?php echo esc_attr( get_option( 'rwexec_email_reminder_hours', 24 ) ); ?>"> hours before reservation<?php else : ?><input type="number" value="24" disabled aria-disabled="true"> hours before reservation<p class="description">Automatic reservation reminders are available with Pro.</p><?php endif; ?></td></tr>
                    <tr class="<?php echo $premium ? '' : 'rwexec-premium-locked'; ?>"><th><label for="rwexec_email_feedback_delay_hours">Feedback Timing</label> <?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></th><td><fieldset <?php disabled( ! $premium ); ?>><input type="number" min="0" id="rwexec_email_feedback_delay_hours" name="rwexec_email_feedback_delay_hours" value="<?php echo esc_attr( get_option( 'rwexec_email_feedback_delay_hours', 2 ) ); ?>"> hours after reservation is marked Completed</fieldset></td></tr>
                    <tr class="<?php echo $premium ? '' : 'rwexec-premium-locked'; ?>"><th><label for="rwexec_email_feedback_url">Feedback URL</label> <?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></th><td><fieldset <?php disabled( ! $premium ); ?>><input type="url" class="large-text" id="rwexec_email_feedback_url" name="rwexec_email_feedback_url" value="<?php echo esc_attr( get_option( 'rwexec_email_feedback_url', '' ) ); ?>"></fieldset><?php if ( ! $premium ) : ?><p class="rwexec-premium-help">Premium sends automatic post-visit feedback requests. <?php echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></p><?php endif; ?></td></tr>
                </table>
            </div>
            <?php submit_button( 'Save Email Settings' ); ?>
        </form>
        <?php
    }

    private static function render_builder_row( array $field ) {
        $defaults = array( 'id'=>'', 'type'=>'text', 'label'=>'New field', 'content'=>'', 'placeholder'=>'', 'required'=>0, 'show_admin'=>1, 'show_email'=>1, 'record_consent'=>0, 'options'=>array() );
        $field = wp_parse_args( $field, $defaults );
        $type_labels = array( 'text'=>'Text field', 'textarea'=>'Textarea', 'checkbox'=>'Checkbox', 'select'=>'Dropdown', 'info'=>'Information note' );
        $token = 'custom:' . sanitize_key( $field['id'] );
        $premium = RWExec_Reservations_License::is_premium();
        ?>
        <div class="rwexec-builder-row rwexec-builder-row--custom <?php echo $premium ? '' : 'rwexec-custom-field-locked'; ?>" data-order-token="<?php echo esc_attr( $token ); ?>" data-custom-field="1">
            <input type="hidden" class="rwexec-order-input" name="rwexec_public_field_order[]" value="<?php echo esc_attr( $token ); ?>">
            <input type="hidden" data-key="id" value="<?php echo esc_attr( $field['id'] ); ?>">
            <div class="rwexec-builder-row__summary">
                <div class="rwexec-builder-row__name"><strong class="rwexec-row-title"><?php echo esc_html( 'info' === $field['type'] ? 'Information note' : $field['label'] ); ?></strong><?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?><div class="rwexec-row-type"><?php echo esc_html( $type_labels[ $field['type'] ] ?? 'Field' ); ?></div></div>
                <span></span><span></span>
                <div class="rwexec-builder-row__actions"><button type="button" class="button rwexec-move-up" title="Move up">↑</button><button type="button" class="button rwexec-move-down" title="Move down">↓</button><button type="button" class="button rwexec-edit-field">Edit</button><button type="button" class="button-link-delete rwexec-remove-field">Delete</button></div>
            </div>
            <div class="rwexec-field-editor" style="display:none">
                <div class="rwexec-editor-grid">
                    <label>Field Type<select data-key="type" class="rwexec-custom-type"><option value="text" <?php selected($field['type'],'text'); ?>>Text field</option><option value="textarea" <?php selected($field['type'],'textarea'); ?>>Textarea</option><option value="checkbox" <?php selected($field['type'],'checkbox'); ?>>Checkbox</option><option value="select" <?php selected($field['type'],'select'); ?>>Dropdown</option><option value="info" <?php selected($field['type'],'info'); ?>>Information note</option></select></label>
                    <label data-for-types="text,textarea,checkbox,select">Field Label<input data-key="label" type="text" value="<?php echo esc_attr($field['label']); ?>"></label>
                    <label data-for-types="text,textarea,select">Placeholder Text<input data-key="placeholder" type="text" value="<?php echo esc_attr($field['placeholder']); ?>"></label>
                    <label class="rwexec-editor-wide" data-for-types="info">Information Content<textarea data-key="content" rows="4"><?php echo esc_textarea($field['content']); ?></textarea></label>
                    <label class="rwexec-editor-wide" data-for-types="select">Dropdown Options <span class="description">(one option per line)</span><textarea data-key="options" rows="4"><?php echo esc_textarea(implode("\n",(array)$field['options'])); ?></textarea></label>
                </div>
                <div class="rwexec-editor-options">
                    <label data-for-types="text,textarea,checkbox,select"><input data-key="required" type="checkbox" value="1" <?php checked(!empty($field['required'])); ?>> Required</label>
                    <label data-for-types="text,textarea,checkbox,select"><input data-key="show_admin" type="checkbox" value="1" <?php checked(!empty($field['show_admin'])); ?>> Show answer in reservation details</label>
                    <label data-for-types="text,textarea,checkbox,select"><input data-key="show_email" type="checkbox" value="1" <?php checked(!empty($field['show_email'])); ?>> Include answer in restaurant email</label>
                    <label data-for-types="checkbox"><input data-key="record_consent" type="checkbox" value="1" <?php checked(!empty($field['record_consent'])); ?>> This checkbox records consent</label>
                </div>
                <p class="description rwexec-consent-help" data-for-types="checkbox">When enabled, RWExec stores the exact checkbox wording and the date/time it was accepted.</p>
                <p><button type="button" class="button button-primary rwexec-done-field">Done</button></p>
            </div>
        </div>
        <?php
    }

    private static function builder_script() { ?>
        <script>
        (function(){
            const form=document.getElementById('rwexec-booking-form-settings');
            if(!form)return;

            document.querySelectorAll('.rwexec-edit-core').forEach(btn=>btn.onclick=()=>{document.getElementById(btn.dataset.target).style.display='block';});
            document.querySelectorAll('[id^="rwexec-core-"]').forEach(panel=>{
                const key=panel.id.replace('rwexec-core-','');
                const labelHidden=form.querySelector('input[name="rwexec_public_core_fields['+key+'][label]"]');
                const placeholderHidden=form.querySelector('input[name="rwexec_public_core_fields['+key+'][placeholder]"]');
                const title=form.querySelector('.rwexec-core-title-'+key);
                panel.querySelector('.rwexec-save-core').onclick=()=>{
                    labelHidden.value=panel.querySelector('.rwexec-core-label').value;
                    placeholderHidden.value=panel.querySelector('.rwexec-core-placeholder').value;
                    if(title) title.textContent=labelHidden.value || title.textContent;
                    panel.style.display='none';
                };
                panel.querySelector('.rwexec-cancel-core').onclick=()=>{
                    panel.querySelector('.rwexec-core-label').value=labelHidden.value;
                    panel.querySelector('.rwexec-core-placeholder').value=placeholderHidden.value;
                    panel.style.display='none';
                };
            });

            const wrap=document.getElementById('rwexec-form-builder-rows');
            if(!wrap)return;
            const typeNames={text:'Text field',textarea:'Textarea',checkbox:'Checkbox',select:'Dropdown',info:'Information note'};

            function updateConditional(row){
                const type=row.querySelector('[data-key="type"]')?.value || 'text';
                row.querySelectorAll('[data-for-types]').forEach(el=>{
                    const allowed=el.dataset.forTypes.split(',');
                    el.style.display=allowed.includes(type)?'':'none';
                });
            }
            function refresh(row){
                const type=row.querySelector('[data-key="type"]').value;
                const label=row.querySelector('[data-key="label"]')?.value || '';
                row.querySelector('.rwexec-row-title').textContent=type==='info'?'Information note':(label||'New field');
                row.querySelector('.rwexec-row-type').textContent=typeNames[type]||'Field';
                updateConditional(row);
            }
            function renumber(){
                let i=0;
                [...wrap.children].forEach(row=>{
                    if(row.dataset.customField==='1'){
                        row.querySelectorAll('[data-key]').forEach(el=>el.name='rwexec_public_custom_fields['+i+']['+el.dataset.key+']');
                        i++;
                    }
                });
            }
            function wireMove(row){
                row.querySelector('.rwexec-move-up')?.addEventListener('click',()=>{if(row.previousElementSibling){wrap.insertBefore(row,row.previousElementSibling);renumber();}});
                row.querySelector('.rwexec-move-down')?.addEventListener('click',()=>{if(row.nextElementSibling){wrap.insertBefore(row.nextElementSibling,row);renumber();}});
            }
            function wireCustom(row){
                wireMove(row);
                row.querySelector('.rwexec-remove-field').onclick=()=>{row.remove();renumber();};
                row.querySelector('.rwexec-edit-field').onclick=()=>{row.querySelector('.rwexec-field-editor').style.display='block';updateConditional(row);};
                row.querySelector('.rwexec-done-field').onclick=()=>{refresh(row);row.querySelector('.rwexec-field-editor').style.display='none';};
                row.querySelector('[data-key="type"]').addEventListener('change',()=>updateConditional(row));
                updateConditional(row);
            }
            [...wrap.children].forEach(row=>row.dataset.customField==='1'?wireCustom(row):wireMove(row));

            const addFieldButton=document.getElementById('rwexec-add-form-field');
            if(addFieldButton) addFieldButton.onclick=()=>{
                const id='field_'+Date.now();
                const row=document.createElement('div');
                row.className='rwexec-builder-row rwexec-builder-row--custom';
                row.dataset.orderToken='custom:'+id;
                row.dataset.customField='1';
                row.innerHTML=`
                    <input type="hidden" class="rwexec-order-input" name="rwexec_public_field_order[]" value="custom:${id}">
                    <input type="hidden" data-key="id" value="${id}">
                    <div class="rwexec-builder-row__summary">
                        <div class="rwexec-builder-row__name"><strong class="rwexec-row-title">New field</strong><div class="rwexec-row-type">Text field</div></div><span></span><span></span>
                        <div class="rwexec-builder-row__actions"><button type="button" class="button rwexec-move-up">↑</button><button type="button" class="button rwexec-move-down">↓</button><button type="button" class="button rwexec-edit-field">Edit</button><button type="button" class="button-link-delete rwexec-remove-field">Delete</button></div>
                    </div>
                    <div class="rwexec-field-editor" style="display:block">
                        <div class="rwexec-editor-grid">
                            <label>Field Type<select data-key="type" class="rwexec-custom-type"><option value="text">Text field</option><option value="textarea">Textarea</option><option value="checkbox">Checkbox</option><option value="select">Dropdown</option><option value="info">Information note</option></select></label>
                            <label data-for-types="text,textarea,checkbox,select">Field Label<input data-key="label" type="text" value=""></label>
                            <label data-for-types="text,textarea,select">Placeholder Text<input data-key="placeholder" type="text" value=""></label>
                            <label class="rwexec-editor-wide" data-for-types="info">Information Content<textarea data-key="content" rows="4"></textarea></label>
                            <label class="rwexec-editor-wide" data-for-types="select">Dropdown Options <span class="description">(one option per line)</span><textarea data-key="options" rows="4"></textarea></label>
                        </div>
                        <div class="rwexec-editor-options">
                            <label data-for-types="text,textarea,checkbox,select"><input data-key="required" type="checkbox" value="1"> Required</label>
                            <label data-for-types="text,textarea,checkbox,select"><input data-key="show_admin" type="checkbox" value="1" checked> Show answer in reservation details</label>
                            <label data-for-types="text,textarea,checkbox,select"><input data-key="show_email" type="checkbox" value="1" checked> Include answer in restaurant email</label>
                            <label data-for-types="checkbox"><input data-key="record_consent" type="checkbox" value="1"> This checkbox records consent</label>
                        </div>
                        <p class="description rwexec-consent-help" data-for-types="checkbox">When enabled, RWExec stores the exact checkbox wording and the date/time it was accepted.</p>
                        <p><button type="button" class="button button-primary rwexec-done-field">Done</button></p>
                    </div>`;
                wrap.appendChild(row);
                wireCustom(row);
                renumber();
            };
            renumber();
        })();
        </script>
    <?php }

}
