=== RWExec Reservations ===
Contributors: rwexec
Tags: reservations, restaurant, bookings, tables, availability
Requires at least: 6.0
Requires PHP: 8.0
Stable tag: 1.0.0
License: Proprietary
Text Domain: rwexec-reservations

Restaurant reservation, capacity, customer, attendance and email management for WordPress.

== Description ==

RWExec Reservations includes secure licence activation against the RWExec licensing service. Licensing governs updates, support and commercial entitlement only; reservation data and core booking functionality are never disabled because a licence expires or the licensing service is temporarily unavailable.

RWExec Reservations provides a public restaurant booking form and separate staff/admin reservation management.

Core features include:
* Public booking shortcode: [rwexec_reservations]
* Staff management shortcode: [rwexec_reservations_admin]
* Staff logout shortcode: [rwexec_logout_button]
* Date/time availability using weekly hours, visit duration and overlapping capacity
* Special-date availability overrides
* Manual staff reservations and returning-customer lookup
* Confirmed, Checked In, Completed, Cancelled and No Show workflows
* Late indicators and automatic No Show processing
* Customer records, notes, preferences and reservation history
* Table/reference allocation
* Customer and restaurant email notifications
* Reminder and feedback automation
* No-code email templates and branding
* Booking-form field builder and visual styling controls
* Separate service communications and optional email-marketing consent
* Marketing-contact CSV export
* Reservations Staff and Reservations Admin roles
* First-run setup wizard
* Configurable data retention on uninstall

== Installation ==

1. Upload the plugin ZIP under WordPress > Plugins > Add New > Upload Plugin.
2. Activate RWExec Reservations.
3. New installations are redirected to the full-screen setup wizard.
4. Configure restaurant details, booking rules, weekly availability and staff/form defaults.
5. Add [rwexec_reservations] to the customer booking page.
6. If using the front-end staff interface, add [rwexec_reservations_admin] to the staff management page and configure redirects under Reservations > Settings > General.

The setup wizard can be rerun later from Reservations > Settings > Setup Wizard. It is intentionally not kept in the main Reservations submenu after installation.

== Email Delivery ==

RWExec Reservations sends email through WordPress wp_mail().

For production websites:
* Configure authenticated SMTP or a transactional mail provider.
* Prefer a From Email address on the website's own domain.
* Configure SPF and DKIM with the mail provider.
* Use the email-template test function and verify delivery to both inbox and spam folders.

RWExec Reservations does not store SMTP credentials. Configure delivery through a dedicated WordPress SMTP/mail plugin or hosting mail service.

== Booking Form ==

Use [rwexec_reservations] on a WordPress page or Elementor Shortcode widget.

Reservations > Settings > Booking Form contains two internal tabs:
* Form — heading/subheading, public booking rules, communications and field builder.
* Styling — font, typography, colours, fields, button and consent-box styling.

The optional form heading/subheading can be left blank when the page builder supplies its own heading.

== Roles ==

Reservations Staff:
* Day-to-day reservation and customer management
* Add/edit reservations
* Check in guests and change operational status
* Update table references
* Manage customer notes/preferences
* Record or withdraw explicit marketing consent
* No access to plugin settings, marketing export or permanent delete

Reservations Admin:
* All Reservations Staff functionality
* Full plugin settings
* Availability and special dates
* Email settings/templates
* Marketing export
* Permanent delete
* Does not require the full WordPress Administrator role

WordPress Administrators receive both RWExec reservation capabilities.

== Data Retention ==

Deactivating the plugin never deletes reservation data.

By default, deleting the plugin also preserves RWExec data. An administrator can opt into permanent cleanup under Reservations > Settings > General > Plugin Data on Uninstall.

When enabled, deleting the plugin removes RWExec reservation/customer/special-date tables, plugin options, relevant transients, reservation roles and administrator reservation capabilities.

== Timezone ==

Set the restaurant timezone under Reservations > Settings > General. Reservation timing, Late indicators, automatic No Show processing, public minimum notice and automation use the restaurant timezone.

For UK restaurants, Europe/London handles daylight-saving changes automatically.

== Translation ==

Text domain: rwexec-reservations

The plugin includes a languages directory and initializes its text domain on WordPress init. Translation coverage is being standardized across the user interface before commercial release.

== Updates and Licensing ==

RWExec Reservations includes secure activation, validation and deactivation against the RWExec licensing service. Licence status governs commercial entitlement, updates and support; core reservation functionality remains available if a licence expires or a subscription becomes inactive. If the licensing service is temporarily unreachable, the last successful validation is honoured for up to seven days. Subscription and billing management is available through the RWExec customer account. Automatic update delivery may be added in a future release.

== Changelog ==

= 1.0.0 =
* First production release of RWExec Reservations.
* Includes secure RWExec licence activation, validation and deactivation.
* Includes restaurant reservations, availability/capacity controls, customer management, staff workflows, configurable booking forms, email automation, special dates, table allocation and setup wizard.


== Free and Pro ==

Free includes core online reservations, weekly availability, total venue capacity, walk-in quick add, current occupancy, reservation management, check-in/status tools, allergies/additional information and built-in transactional booking emails.

Pro adds advanced capacity modes and separate reservation capacity, special-date overrides, automatic reminder and feedback emails, editable email templates, customer history/notes/preferences, marketing consent and export, custom booking fields/notes and advanced booking-form styling.


== Free / Pro architecture ==
The public plugin contains the Free core. Premium features require the separate RWExec Reservations Pro add-on as well as a valid RWExec entitlement.
