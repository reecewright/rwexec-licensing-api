<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Admin {

    public static function init() {
        RWExec_Reservations_Actions::init();
        RWExec_Reservations_Settings::init();
        RWExec_Reservations_Setup_Page::init();
        add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
    }

    public static function register_admin_menu() {
        add_menu_page(
            __( 'RWExec Reservations', 'rwexec-reservations' ),
            __( 'Reservations', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations',
            array( 'RWExec_Reservations_List_Page', 'render' ),
            'dashicons-calendar-alt',
            30
        );

        add_submenu_page(
            'rwexec-reservations',
            __( 'Reservations', 'rwexec-reservations' ),
            __( 'Reservations', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations',
            array( 'RWExec_Reservations_List_Page', 'render' )
        );

        add_submenu_page(
            'rwexec-reservations',
            __( 'Add Reservation', 'rwexec-reservations' ),
            __( 'Add Reservation', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-add',
            array( 'RWExec_Reservation_Add_Page', 'render' )
        );

        add_submenu_page(
            'rwexec-reservations',
            __( 'Customers', 'rwexec-reservations' ),
            __( 'Customers', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-customers',
            array( __CLASS__, 'render_customers_page' )
        );

        add_submenu_page(
            'rwexec-reservations',
            __( 'Reservation Settings', 'rwexec-reservations' ),
            __( 'Settings', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-settings',
            array( 'RWExec_Reservations_Settings_Page', 'render' )
        );

        add_submenu_page(
            null,
            __( 'Setup Wizard', 'rwexec-reservations' ),
            __( 'Setup Wizard', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-setup',
            array( 'RWExec_Reservations_Setup_Page', 'render' )
        );

        add_submenu_page(
            null,
            'Customer Details',
            'Customer Details',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-customer',
            array( __CLASS__, 'render_customer_details_page' )
        );

        add_submenu_page(
            null,
            'Special Dates',
            'Special Dates',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-special-dates',
            array( __CLASS__, 'render_special_dates_page' )
        );

        add_submenu_page(
            null,
            'Email Templates',
            'Email Templates',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-emails',
            array( __CLASS__, 'render_email_templates_page' )
        );

        add_submenu_page(
            null,
            'Reservation Details',
            'Reservation Details',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservation-details',
            array( 'RWExec_Reservation_Details_Page', 'render' )
        );

        add_submenu_page(
            null,
            'Edit Reservation',
            'Edit Reservation',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservation-edit',
            array( 'RWExec_Reservation_Edit_Page', 'render' )
        );
    }

    public static function enqueue_assets( string $hook_suffix ) {
        if ( false === strpos( $hook_suffix, 'rwexec' ) && empty( $_GET['page'] ) ) {
            return;
        }

        $page = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
        if ( 0 !== strpos( $page, 'rwexec-' ) ) {
            return;
        }

        $css_file = RWEXEC_RESERVATIONS_PATH . 'assets/css/admin.css';
        $css_version = file_exists( $css_file ) ? (string) filemtime( $css_file ) : RWEXEC_RESERVATIONS_VERSION;

        wp_enqueue_style(
            'rwexec-reservations-admin',
            RWEXEC_RESERVATIONS_URL . 'assets/css/admin.css',
            array(),
            $css_version
        );
    }
    public static function render_pro_gate( string $title, string $message ) {
        $state = RWExec_Reservations_License::pro_requirement_state();

        if ( 'addon_missing' === $state ) {
            $heading = sprintf( __( '%s requires the Pro add-on', 'rwexec-reservations' ), $title );
        } elseif ( 'licence_required' === $state ) {
            $heading = sprintf( __( '%s requires an active Pro licence', 'rwexec-reservations' ), $title );
        } else {
            $heading = sprintf( __( '%s is available in Pro', 'rwexec-reservations' ), $title );
        }

        echo '<div class="wrap rwexec-admin"><h1>' . esc_html( $title ) . '</h1>';
        echo '<div class="rwexec-premium-gate rwexec-premium-gate--' . esc_attr( $state ) . '"><div class="rwexec-premium-gate__icon">' . wp_kses_post( RWExec_Reservations_License::premium_icon() ) . '</div><div>';
        echo '<h3>' . esc_html( $heading ) . '</h3><p>' . esc_html( $message ) . '</p>';
        echo '<p class="rwexec-premium-requirement">' . esc_html( RWExec_Reservations_License::pro_requirement_message() ) . '</p>';
        echo wp_kses_post( RWExec_Reservations_License::premium_badge( 'Get RWExec Reservations Pro' ) );
        echo '</div></div></div>';
    }

    public static function render_customers_page() {
        if ( class_exists( 'RWExec_Reservations_Customers_Page' ) && RWExec_Reservations_License::is_premium() ) {
            RWExec_Reservations_Customers_Page::render();
            return;
        }
        self::render_pro_gate( 'Customers', 'Customer history, notes, preferences and marketing tools are included with RWExec Reservations Pro.' );
    }

    public static function render_customer_details_page() {
        if ( class_exists( 'RWExec_Reservations_Customer_Details_Page' ) && RWExec_Reservations_License::is_premium() ) {
            RWExec_Reservations_Customer_Details_Page::render();
            return;
        }
        self::render_customers_page();
    }

    public static function render_special_dates_page() {
        if ( class_exists( 'RWExec_Reservations_Special_Dates_Page' ) && RWExec_Reservations_License::is_premium() ) {
            RWExec_Reservations_Special_Dates_Page::render();
            return;
        }
        self::render_pro_gate( 'Special Dates', 'One-off closures, bank holidays, special opening hours and date overrides are included with RWExec Reservations Pro.' );
    }

    public static function render_email_templates_page() {
        if ( class_exists( 'RWExec_Reservations_Email_Templates_Page' ) && RWExec_Reservations_License::is_premium() ) {
            RWExec_Reservations_Email_Templates_Page::render();
            return;
        }
        self::render_pro_gate( 'Email Templates', 'Editable email templates and advanced automated communications are included with RWExec Reservations Pro.' );
    }

}
