<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Availability {

    public static function get_rules_for_date( string $reservation_date ): array {
        $special = RWExec_Reservations_License::is_premium()
            ? RWExec_Reservations_Special_Dates::get_for_date( $reservation_date )
            : null;

        if ( $special ) {
            return array(
                'source' => 'special_date',
                'status' => $special->booking_status,
                'start' => $special->booking_start ? substr( $special->booking_start, 0, 5 ) : '',
                'end' => $special->booking_end ? substr( $special->booking_end, 0, 5 ) : '',
                'label' => $special->label ?: '',
            );
        }

        $date_object = DateTimeImmutable::createFromFormat( '!Y-m-d', $reservation_date, RWExec_Reservations_Service::restaurant_timezone() );
        $day_key = $date_object ? strtolower( $date_object->format( 'l' ) ) : strtolower( wp_date( 'l' ) );

        return array(
            'source' => 'weekly',
            'status' => get_option( 'rwexec_' . $day_key . '_booking_status', 'open' ),
            'start' => get_option( 'rwexec_' . $day_key . '_booking_start', '12:00' ),
            'end' => get_option( 'rwexec_' . $day_key . '_booking_end', '22:00' ),
            'label' => '',
        );
    }

    public static function check( string $reservation_date, string $start_time ) {
        $start_datetime = DateTimeImmutable::createFromFormat(
            '!Y-m-d H:i',
            $reservation_date . ' ' . substr( $start_time, 0, 5 ),
            RWExec_Reservations_Service::restaurant_timezone()
        );

        if ( false === $start_datetime ) {
            return new WP_Error(
                'rwexec_invalid_reservation_time',
                'The reservation date or time is invalid.'
            );
        }

        $rules = self::get_rules_for_date( $reservation_date );
        $suffix = $rules['label'] ? ' (' . $rules['label'] . ')' : '';

        if ( 'closed' === $rules['status'] ) {
            return new WP_Error(
                'rwexec_override_closed',
                'This date is currently set to Closed' . $suffix . '.'
            );
        }

        if ( 'walk_ins_only' === $rules['status'] ) {
            return new WP_Error(
                'rwexec_override_walk_ins',
                'This date is currently set to Walk-ins only' . $suffix . '.'
            );
        }

        $booking_start = $rules['start'];
        $booking_end = $rules['end'];

        if ( empty( $booking_start ) || empty( $booking_end ) ) {
            return new WP_Error(
                'rwexec_override_hours',
                'No bookable hours are configured for this date.'
            );
        }

        $requested_minutes = self::time_to_minutes( $start_datetime->format( 'H:i' ) );
        $opening_minutes = self::time_to_minutes( $booking_start );
        $closing_minutes = self::time_to_minutes( $booking_end );

        if ( $requested_minutes < $opening_minutes || $requested_minutes > $closing_minutes ) {
            return new WP_Error(
                'rwexec_override_hours',
                'The selected time is outside the configured booking hours.'
            );
        }

        $booking_interval = absint( get_option( 'rwexec_booking_interval', 15 ) );

        if (
            $booking_interval > 0 &&
            ( ( $requested_minutes - $opening_minutes ) % $booking_interval ) !== 0
        ) {
            return new WP_Error(
                'rwexec_override_interval',
                'The selected time does not match the configured booking interval.'
            );
        }

        return true;
    }

    private static function time_to_minutes( string $time ): int {
        $parts = array_map( 'intval', explode( ':', $time ) );
        return ( $parts[0] ?? 0 ) * 60 + ( $parts[1] ?? 0 );
    }
}
