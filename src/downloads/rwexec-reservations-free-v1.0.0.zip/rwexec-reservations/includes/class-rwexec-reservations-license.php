<?php

defined( 'ABSPATH' ) || exit;

/**
 * Handles RWExec licence activation and validation.
 *
 * Licensing controls commercial entitlement only. Reservation functionality is
 * deliberately never disabled when a licence expires or the licensing service
 * cannot be reached.
 */
class RWExec_Reservations_License {

    public const API_BASE = 'https://licensing.rwexec.com/v1/licenses';
    public const PRODUCT = 'rwexec-reservations';
    public const CRON_HOOK = 'rwexec_reservations_validate_license';
    public const VALIDATION_INTERVAL = 21600; // Six hours.
    public const GRACE_PERIOD = 604800; // Seven-day outage grace period.

    private const OPTION_KEY = 'rwexec_license_key';
    private const OPTION_INSTANCE = 'rwexec_license_instance_id';
    private const OPTION_STATE = 'rwexec_license_state';

    public static function init() {
        add_action( 'admin_post_rwexec_license_activate', array( __CLASS__, 'handle_activate' ) );
        add_action( 'admin_post_rwexec_license_deactivate', array( __CLASS__, 'handle_deactivate' ) );
        add_action( 'admin_post_rwexec_license_validate', array( __CLASS__, 'handle_validate' ) );
        add_action( self::CRON_HOOK, array( __CLASS__, 'scheduled_validate' ) );
        add_action( 'init', array( __CLASS__, 'ensure_schedule' ) );
        add_action( 'admin_init', array( __CLASS__, 'maybe_validate_in_admin' ) );
    }

    public static function ensure_schedule() {
        $event = wp_get_scheduled_event( self::CRON_HOOK );

        // Older releases scheduled validation daily. Move existing installs to an
        // hourly runner; scheduled_validate() only contacts RWExec when the
        // six-hour validation interval has elapsed.
        if ( $event && 'hourly' !== $event->schedule ) {
            wp_clear_scheduled_hook( self::CRON_HOOK );
            $event = false;
        }

        if ( ! $event ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::CRON_HOOK );
        }
    }

    public static function clear_schedule() {
        wp_clear_scheduled_hook( self::CRON_HOOK );
    }

    public static function get_instance_id(): string {
        $instance_id = (string) get_option( self::OPTION_INSTANCE, '' );

        if ( ! wp_is_uuid( $instance_id ) ) {
            $instance_id = wp_generate_uuid4();
            update_option( self::OPTION_INSTANCE, $instance_id, false );
        }

        return $instance_id;
    }

    public static function get_license_key(): string {
        return trim( (string) get_option( self::OPTION_KEY, '' ) );
    }

    public static function get_state(): array {
        $defaults = array(
            'valid'              => false,
            'status'             => 'inactive',
            'expires_at'         => '',
            'activation_limit'   => null,
            'activations'        => null,
            'activation_id'      => '',
            'last_checked_at'    => 0,
            'last_success_at'    => 0,
            'grace_until'        => 0,
            'last_error'         => '',
            'transport_degraded' => false,
        );

        $stored = get_option( self::OPTION_STATE, array() );
        return wp_parse_args( is_array( $stored ) ? $stored : array(), $defaults );
    }

    public static function entitlement_status(): string {
        $key = self::get_license_key();
        if ( '' === $key ) {
            return 'inactive';
        }

        $state = self::get_state();
        if ( ! empty( $state['valid'] ) && 'active' === $state['status'] ) {
            return 'active';
        }

        if (
            ! empty( $state['transport_degraded'] ) &&
            ! empty( $state['last_success_at'] ) &&
            ! empty( $state['grace_until'] ) &&
            time() <= (int) $state['grace_until']
        ) {
            return 'grace';
        }

        return (string) $state['status'];
    }

    public static function is_entitled(): bool {
        return in_array( self::entitlement_status(), array( 'active', 'grace' ), true );
    }

    /**
     * Premium feature entitlement. The free edition remains fully usable for
     * core reservations; an active/grace licence unlocks premium features.
     */
    public static function is_premium(): bool {
        // A valid RWExec entitlement alone does not expose Pro code. The separate
        // RWExec Reservations Pro add-on must also be installed and loaded.
        return self::is_pro_addon_active() && self::is_entitled();
    }

    public static function is_pro_addon_active(): bool {
        return defined( 'RWEXEC_RESERVATIONS_PRO_VERSION' );
    }

    /**
     * Describes why a Pro feature is currently unavailable.
     *
     * - upgrade: no active entitlement and no loaded Pro add-on
     * - addon_missing: entitlement is valid, but the Pro add-on is not loaded
     * - licence_required: Pro add-on is loaded, but entitlement is not valid
     * - active: both requirements are satisfied
     */
    public static function pro_requirement_state(): string {
        $entitled = self::is_entitled();
        $addon    = self::is_pro_addon_active();

        if ( $entitled && $addon ) {
            return 'active';
        }

        if ( $entitled ) {
            return 'addon_missing';
        }

        if ( $addon ) {
            return 'licence_required';
        }

        return 'upgrade';
    }

    public static function pro_requirement_message(): string {
        switch ( self::pro_requirement_state() ) {
            case 'addon_missing':
                return __( 'Your Pro licence is active. Install and activate the RWExec Reservations Pro add-on to use this feature.', 'rwexec-reservations' );
            case 'licence_required':
                return __( 'RWExec Reservations Pro is installed. Activate a valid Pro licence to use this feature.', 'rwexec-reservations' );
            case 'active':
                return __( 'RWExec Reservations Pro is active.', 'rwexec-reservations' );
            case 'upgrade':
            default:
                return __( 'Upgrade to RWExec Reservations Pro to use this feature.', 'rwexec-reservations' );
        }
    }

    public static function premium_icon(): string {
        return '<img class="rwexec-premium-icon" src="' . esc_url( RWEXEC_RESERVATIONS_URL . 'assets/images/premium-crown.png' ) . '" alt="" aria-hidden="true">';
    }

    public static function purchase_url(): string {
        return (string) apply_filters( 'rwexec_reservations_purchase_url', 'https://rwexec.com/plugins.html#rwexec-reservations' );
    }

    public static function account_url(): string {
        return (string) apply_filters( 'rwexec_reservations_account_url', 'https://account.rwexec.com/' );
    }

    public static function premium_badge( string $label = 'Upgrade to Pro' ): string {
        $state = self::pro_requirement_state();
        $url   = self::purchase_url();

        if ( 'addon_missing' === $state ) {
            $label = __( 'Install Pro add-on', 'rwexec-reservations' );
            $url   = self::account_url();
        } elseif ( 'licence_required' === $state ) {
            $label = __( 'Activate Pro licence', 'rwexec-reservations' );
            $url   = self::premium_settings_url();
        }

        $target = 0 === strpos( $url, admin_url() ) ? '' : ' target="_blank" rel="noopener noreferrer"';
        return '<a class="rwexec-premium-upgrade" href="' . esc_url( $url ) . '"' . $target . '>' . self::premium_icon() . '<span>' . esc_html( $label ) . '</span></a>';
    }

    public static function premium_lock( string $tooltip = '' ): string {
        if ( '' === $tooltip || 'Upgrade to Pro to use this feature.' === $tooltip ) {
            $tooltip = self::pro_requirement_message();
        }

        return '<span class="rwexec-premium-lock" tabindex="0" data-premium-tooltip="' . esc_attr( $tooltip ) . '">' . self::premium_icon() . '<span class="screen-reader-text">Premium feature</span></span>';
    }

    public static function premium_settings_url(): string {
        return add_query_arg(
            array( 'page' => 'rwexec-reservations-settings', 'tab' => 'licence' ),
            admin_url( 'admin.php' )
        );
    }

    public static function handle_activate() {
        self::require_admin();
        check_admin_referer( 'rwexec_license_activate' );

        $license_key = strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['license_key'] ?? '' ) ) ) );
        if ( '' === $license_key ) {
            self::redirect_with_notice( 'missing_key' );
        }

        update_option( self::OPTION_KEY, $license_key, false );
        $result = self::request( 'activate', $license_key );
        self::store_result( $result );

        if ( ! is_wp_error( $result ) && ! empty( $result['valid'] ) ) {
            $validated = self::request( 'validate', $license_key );
            if ( ! is_wp_error( $validated ) ) {
                self::store_result( $validated );
            }
        }

        self::redirect_with_notice( is_wp_error( $result ) ? 'connection_error' : ( ! empty( $result['valid'] ) ? 'activated' : 'activation_failed' ) );
    }

    public static function handle_validate() {
        self::require_admin();
        check_admin_referer( 'rwexec_license_validate' );

        $key = self::get_license_key();
        if ( '' === $key ) {
            self::redirect_with_notice( 'missing_key' );
        }

        $result = self::request( 'validate', $key );
        self::store_result( $result );
        self::redirect_with_notice( is_wp_error( $result ) ? 'connection_error' : ( ! empty( $result['valid'] ) ? 'validated' : 'validation_failed' ) );
    }

    public static function handle_deactivate() {
        self::require_admin();
        check_admin_referer( 'rwexec_license_deactivate' );

        $key = self::get_license_key();
        if ( '' === $key ) {
            self::redirect_with_notice( 'missing_key' );
        }

        $result = self::request( 'deactivate', $key );

        if ( is_wp_error( $result ) ) {
            self::store_transport_error( $result );
            self::redirect_with_notice( 'connection_error' );
        }

        if ( ! empty( $result['success'] ) ) {
            delete_option( self::OPTION_KEY );
            update_option(
                self::OPTION_STATE,
                array(
                    'valid'              => false,
                    'status'             => 'inactive',
                    'expires_at'         => '',
                    'activation_limit'   => null,
                    'activations'        => null,
                    'activation_id'      => '',
                    'last_checked_at'    => time(),
                    'last_success_at'    => 0,
                    'grace_until'        => 0,
                    'last_error'         => '',
                    'transport_degraded' => false,
                ),
                false
            );
            self::redirect_with_notice( 'deactivated' );
        }

        self::redirect_with_notice( 'deactivation_failed' );
    }

    public static function scheduled_validate() {
        if ( ! self::validation_due() ) {
            return;
        }

        $key = self::get_license_key();
        if ( '' === $key ) {
            return;
        }

        $result = self::request( 'validate', $key );
        self::store_result( $result );
    }

    /**
     * If an administrator opens an RWExec Reservations screen after the local
     * validation result has become stale, refresh it immediately instead of
     * waiting for WP-Cron. This keeps remote site deactivations responsive
     * without adding a licensing request to every normal page load.
     */
    public static function maybe_validate_in_admin() {
        if ( ! is_admin() || ! self::validation_due() ) {
            return;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 0 !== strpos( $page, 'rwexec-reservations' ) ) {
            return;
        }

        // Avoid duplicate requests if more than one admin request is generated
        // at the same time. The lock is deliberately short-lived.
        if ( get_transient( 'rwexec_reservations_license_validation_lock' ) ) {
            return;
        }

        set_transient( 'rwexec_reservations_license_validation_lock', 1, 5 * MINUTE_IN_SECONDS );

        $key = self::get_license_key();
        if ( '' !== $key ) {
            $result = self::request( 'validate', $key );
            self::store_result( $result );
        }

        delete_transient( 'rwexec_reservations_license_validation_lock' );
    }

    private static function validation_due(): bool {
        $key = self::get_license_key();
        if ( '' === $key ) {
            return false;
        }

        $state = self::get_state();
        $last_checked_at = (int) ( $state['last_checked_at'] ?? 0 );

        if ( $last_checked_at <= 0 ) {
            return true;
        }

        return ( time() - $last_checked_at ) >= self::VALIDATION_INTERVAL;
    }

    private static function request( string $action, string $license_key ) {
        $body = array(
            'license_key' => $license_key,
            'product'     => self::PRODUCT,
            'site_url'    => home_url( '/' ),
            'instance_id' => self::get_instance_id(),
            'version'     => RWEXEC_RESERVATIONS_VERSION,
        );

        $response = wp_remote_post(
            trailingslashit( self::API_BASE ) . $action,
            array(
                'timeout'     => 15,
                'redirection' => 2,
                'headers'     => array(
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',
                ),
                'body'        => wp_json_encode( $body ),
                'user-agent'  => 'RWExec Reservations/' . RWEXEC_RESERVATIONS_VERSION . '; ' . home_url( '/' ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $decoded = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! is_array( $decoded ) ) {
            return new WP_Error( 'rwexec_license_invalid_response', __( 'The licensing server returned an invalid response.', 'rwexec-reservations' ) );
        }

        // Expected licensing responses may use 4xx for invalid/expired keys. Return
        // their JSON so the authoritative status can be stored instead of treating
        // them as a temporary network outage.
        if ( $code >= 500 || 0 === $code ) {
            return new WP_Error( 'rwexec_license_server_error', __( 'The licensing server is temporarily unavailable.', 'rwexec-reservations' ) );
        }

        return $decoded;
    }

    private static function store_result( $result ) {
        if ( is_wp_error( $result ) ) {
            self::store_transport_error( $result );
            return;
        }

        $state = self::get_state();
        $now = time();

        // Licensing responses have evolved over time. Keep the entitlement
        // status authoritative at the top level, but also read useful display
        // metadata from common nested payload shapes so older/newer server
        // responses still populate the Licence Details card.
        $sources = array( $result );
        foreach ( array( 'license', 'licence', 'data', 'entitlement', 'subscription', 'activation' ) as $key ) {
            if ( isset( $result[ $key ] ) && is_array( $result[ $key ] ) ) {
                $sources[] = $result[ $key ];
            }
        }

        $pick = static function ( array $keys, $default = null ) use ( $sources ) {
            foreach ( $sources as $source ) {
                foreach ( $keys as $key ) {
                    if ( array_key_exists( $key, $source ) && null !== $source[ $key ] && '' !== $source[ $key ] ) {
                        return $source[ $key ];
                    }
                }
            }
            return $default;
        };

        $valid_raw = $pick( array( 'valid', 'is_valid', 'active' ), false );
        $valid = filter_var( $valid_raw, FILTER_VALIDATE_BOOLEAN );
        $status = sanitize_key( (string) $pick( array( 'status', 'license_status', 'licence_status' ), $valid ? 'active' : 'invalid' ) );

        $state['valid'] = $valid;
        $state['status'] = $status ?: 'invalid';
        $state['expires_at'] = sanitize_text_field( (string) $pick( array( 'expires_at', 'expiresAt', 'expiry', 'expiry_date', 'expiration_date' ), '' ) );

        $limit = $pick( array( 'activation_limit', 'activationLimit', 'max_activations', 'site_limit', 'sites_allowed' ), null );
        $used = $pick( array( 'activations', 'activation_count', 'activations_used', 'used_activations', 'sites_used' ), null );
        $state['activation_limit'] = null === $limit ? null : absint( $limit );
        $state['activations'] = null === $used ? null : absint( $used );
        $state['activation_id'] = sanitize_text_field( (string) $pick( array( 'activation_id', 'activationId', 'id' ), $state['activation_id'] ) );
        $state['last_checked_at'] = $now;
        $state['last_error'] = '';
        $state['transport_degraded'] = false;

        if ( $valid && 'active' === $state['status'] ) {
            $state['last_success_at'] = $now;
            $state['grace_until'] = $now + self::GRACE_PERIOD;
        } else {
            $state['grace_until'] = 0;
        }

        update_option( self::OPTION_STATE, $state, false );
    }

    private static function store_transport_error( WP_Error $error ) {
        $state = self::get_state();
        $state['last_checked_at'] = time();
        $state['last_error'] = sanitize_text_field( $error->get_error_message() );
        $state['transport_degraded'] = true;

        if ( ! empty( $state['last_success_at'] ) ) {
            $state['grace_until'] = (int) $state['last_success_at'] + self::GRACE_PERIOD;
        }

        update_option( self::OPTION_STATE, $state, false );
    }

    private static function require_admin() {
        if ( ! current_user_can( RWExec_Reservations_Staff::ADMIN_CAPABILITY ) ) {
            wp_die( esc_html__( 'You do not have permission to manage the licence.', 'rwexec-reservations' ) );
        }
    }

    private static function redirect_with_notice( string $notice ) {
        $url = add_query_arg(
            array(
                'page'           => 'rwexec-reservations-settings',
                'tab'            => 'licence',
                'license_notice' => sanitize_key( $notice ),
            ),
            admin_url( 'admin.php' )
        );
        wp_safe_redirect( $url );
        exit;
    }
}
