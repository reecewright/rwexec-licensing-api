<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Staff {
    const CAPABILITY = 'rwexec_manage_reservations';
    const ADMIN_CAPABILITY = 'rwexec_admin_reservations';

    public static function init() {
        add_action( 'init', array( __CLASS__, 'ensure_role' ) );
        add_shortcode( 'rwexec_reservations_admin', array( __CLASS__, 'shortcode' ) );
        add_shortcode( 'rwexec_logout_button', array( __CLASS__, 'logout_shortcode' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 20, 3 );
        add_filter( 'show_admin_bar', array( __CLASS__, 'show_admin_bar' ) );
        add_action( 'admin_init', array( __CLASS__, 'redirect_staff_from_wp_admin' ), 1 );
        add_action( 'template_redirect', array( __CLASS__, 'disable_frontend_cache_for_staff' ), 0 );
    }

    /**
     * Front-end reservation management must never be served from a page cache.
     *
     * Staff users are viewing live operational data, so cached HTML can hide
     * newly-created reservations or show stale statuses. Mark all front-end
     * requests made by authorised reservation users as non-cacheable.
     */
    public static function disable_frontend_cache_for_staff(): void {
        if ( is_admin() || ! is_user_logged_in() || ! self::can_manage() ) {
            return;
        }

        if ( ! defined( 'DONOTCACHEPAGE' ) ) {
            define( 'DONOTCACHEPAGE', true );
        }
        if ( ! defined( 'DONOTCACHEDB' ) ) {
            define( 'DONOTCACHEDB', true );
        }

        nocache_headers();
    }

    public static function ensure_role() {
        $wp_admin = get_role( 'administrator' );
        if ( $wp_admin ) {
            if ( ! $wp_admin->has_cap( self::CAPABILITY ) ) {
                $wp_admin->add_cap( self::CAPABILITY );
            }
            if ( ! $wp_admin->has_cap( self::ADMIN_CAPABILITY ) ) {
                $wp_admin->add_cap( self::ADMIN_CAPABILITY );
            }
        }

        $staff = get_role( 'rwexec_reservations_staff' );
        if ( ! $staff ) {
            $staff = add_role( 'rwexec_reservations_staff', 'Reservations Staff', array(
                'read' => true,
                self::CAPABILITY => true,
            ) );
        } else {
            $staff->add_cap( 'read' );
            $staff->add_cap( self::CAPABILITY );
            $staff->remove_cap( self::ADMIN_CAPABILITY );
        }

        $reservation_admin = get_role( 'rwexec_reservations_admin' );
        if ( ! $reservation_admin ) {
            $reservation_admin = add_role( 'rwexec_reservations_admin', 'Reservations Admin', array(
                'read' => true,
                self::CAPABILITY => true,
                self::ADMIN_CAPABILITY => true,
            ) );
        } else {
            $reservation_admin->add_cap( 'read' );
            $reservation_admin->add_cap( self::CAPABILITY );
            $reservation_admin->add_cap( self::ADMIN_CAPABILITY );
        }
    }

    public static function can_manage(): bool {
        return current_user_can( self::CAPABILITY ) || self::can_admin();
    }

    public static function can_admin(): bool {
        return current_user_can( self::ADMIN_CAPABILITY ) || current_user_can( 'manage_options' );
    }

    public static function is_staff_only( $user = null ): bool {
        $user = $user instanceof WP_User ? $user : wp_get_current_user();
        if ( ! $user || ! $user->exists() ) {
            return false;
        }
        return in_array( 'rwexec_reservations_staff', (array) $user->roles, true )
            && ! user_can( $user, self::ADMIN_CAPABILITY )
            && ! user_can( $user, 'manage_options' );
    }

    public static function resolve_redirect_option( string $option, string $fallback ): string {
        $redirect = trim( (string) get_option( $option, '' ) );
        if ( '' === $redirect ) {
            return $fallback;
        }
        if ( 0 === strpos( $redirect, '/' ) ) {
            $redirect = home_url( $redirect );
        }
        return wp_validate_redirect( $redirect, $fallback );
    }

    public static function login_redirect( $redirect_to, $requested_redirect_to, $user ) {
        if ( ! $user instanceof WP_User || is_wp_error( $user ) ) {
            return $redirect_to;
        }

        if ( user_can( $user, self::ADMIN_CAPABILITY ) || user_can( $user, 'manage_options' ) ) {
            return self::resolve_redirect_option(
                'rwexec_admin_login_redirect',
                admin_url( 'admin.php?page=rwexec-reservations' )
            );
        }

        if ( in_array( 'rwexec_reservations_staff', (array) $user->roles, true ) ) {
            return self::resolve_redirect_option(
                'rwexec_staff_login_redirect',
                home_url( '/' )
            );
        }

        return $redirect_to;
    }

    public static function show_admin_bar( $show ) {
        return self::is_staff_only() ? false : $show;
    }

    public static function redirect_staff_from_wp_admin() {
        if ( ! self::is_staff_only() || wp_doing_ajax() ) {
            return;
        }

        global $pagenow;
        if ( 'admin-post.php' === $pagenow ) {
            return;
        }

        wp_safe_redirect(
            self::resolve_redirect_option( 'rwexec_staff_login_redirect', home_url( '/' ) )
        );
        exit;
    }

    public static function enqueue_assets() {
        /*
         * Load the scoped staff stylesheet on the front end unconditionally.
         * The stylesheet only targets RWExec classes, so this is safe and avoids
         * shortcode-detection failures in Elementor, templates and page builders.
         * Enqueuing here also guarantees the stylesheet is printed in wp_head;
         * enqueueing for the first time from the shortcode callback can be too late.
         */
        if ( is_admin() ) { return; }
        self::enqueue_staff_styles();
    }

    private static function enqueue_staff_styles() {
        wp_enqueue_style( 'dashicons' );
        $css_file = RWEXEC_RESERVATIONS_PATH . 'assets/css/admin.css';
        $css_version = file_exists( $css_file ) ? (string) filemtime( $css_file ) : RWEXEC_RESERVATIONS_VERSION;
        wp_enqueue_style( 'rwexec-reservations-admin', RWEXEC_RESERVATIONS_URL . 'assets/css/admin.css', array(), $css_version );
    }

    public static function shortcode(): string {
        if ( ! defined( 'DONOTCACHEPAGE' ) ) {
            define( 'DONOTCACHEPAGE', true );
        }
        nocache_headers();
        self::enqueue_staff_styles();
        if ( ! is_user_logged_in() ) {
            return '<div class="rwexec-staff-access">You must be logged in to manage reservations.</div>';
        }
        if ( ! self::can_manage() ) {
            return '<div class="rwexec-staff-access">You do not have permission to manage reservations.</div>';
        }

        $request_path = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
        $request_path = strtok( $request_path, '?' );
        $base_url = home_url( $request_path ?: '/' );
        $action = sanitize_key( wp_unslash( $_GET['rwexec_action'] ?? 'list' ) );
        $context = array( 'frontend' => true, 'base_url' => $base_url );

        ob_start();
        if ( 'customers' === $action ) {
            if ( class_exists( 'RWExec_Reservations_Customers_Page' ) && RWExec_Reservations_License::is_premium() ) { RWExec_Reservations_Customers_Page::render( $context ); } else { RWExec_Reservations_Admin::render_pro_gate( 'Customers', 'Customer history, notes and preferences are included with RWExec Reservations Pro.' ); }
        } elseif ( 'customer' === $action ) {
            if ( class_exists( 'RWExec_Reservations_Customer_Details_Page' ) && RWExec_Reservations_License::is_premium() ) { RWExec_Reservations_Customer_Details_Page::render( $context ); } else { RWExec_Reservations_Admin::render_pro_gate( 'Customers', 'Customer history, notes and preferences are included with RWExec Reservations Pro.' ); }
        } elseif ( 'add' === $action ) {
            RWExec_Reservation_Add_Page::render( $context );
        } elseif ( 'view' === $action ) {
            RWExec_Reservation_Details_Page::render( $context );
        } elseif ( 'edit' === $action ) {
            RWExec_Reservation_Edit_Page::render( $context );
        } else {
            RWExec_Reservations_List_Page::render( $context );
        }
        return (string) ob_get_clean();
    }

    public static function logout_url(): string {
        return wp_logout_url(
            self::resolve_redirect_option( 'rwexec_staff_logout_redirect', home_url( '/' ) )
        );
    }

    public static function logout_shortcode( $atts = array() ): string {
        self::enqueue_staff_styles();
        if ( ! is_user_logged_in() ) { return ''; }
        $atts = shortcode_atts( array( 'text' => 'Log Out' ), $atts, 'rwexec_logout_button' );
        return '<a class="rwexec-logout-button" href="' . esc_url( self::logout_url() ) . '">' . esc_html( $atts['text'] ) . '</a>';
    }

    public static function logout_section(): string {
        if ( ! is_user_logged_in() || '1' !== (string) get_option( 'rwexec_staff_show_logout', '1' ) ) { return ''; }
        return '<div class="rwexec-staff-logout"><a class="rwexec-logout-button" href="' . esc_url( self::logout_url() ) . '">' . esc_html( get_option( 'rwexec_staff_logout_text', 'Log Out' ) ) . '</a></div>';
    }

}
