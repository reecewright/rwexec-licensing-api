<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Capacity {

    public static function mode(): string {
        // Free always uses one combined physical venue capacity. The Pro add-on
        // can supply an alternative capacity mode through this filter.
        $mode = sanitize_key( (string) apply_filters( 'rwexec_reservations_capacity_mode', 'combined_live' ) );
        return in_array( $mode, array( 'online_limit', 'combined_live' ), true ) ? $mode : 'combined_live';
    }

    public static function get_existing_guests(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $exclude_reservation_id = 0,
        bool $include_walk_ins = true
    ): int {
        global $wpdb;

        $table_name = $wpdb->prefix . 'rwexec_reservations';
        $active_statuses = "'confirmed','checked_in','arrived'";
        $walk_in_clause = $include_walk_ins ? '' : " AND COALESCE(source, '') != 'walk_in'";

        if ( $exclude_reservation_id > 0 ) {
            $sql = $wpdb->prepare(
                "SELECT COALESCE(SUM(guest_count),0)
                 FROM {$table_name}
                 WHERE reservation_date = %s
                 AND id != %d
                 AND status IN ({$active_statuses})
                 {$walk_in_clause}
                 AND start_time < %s
                 AND end_time > %s",
                $reservation_date,
                $exclude_reservation_id,
                $end_time,
                $start_time
            );
        } else {
            $sql = $wpdb->prepare(
                "SELECT COALESCE(SUM(guest_count),0)
                 FROM {$table_name}
                 WHERE reservation_date = %s
                 AND status IN ({$active_statuses})
                 {$walk_in_clause}
                 AND start_time < %s
                 AND end_time > %s",
                $reservation_date,
                $end_time,
                $start_time
            );
        }

        return absint( $wpdb->get_var( $sql ) );
    }

    public static function get_remaining_capacity(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $exclude_reservation_id = 0,
        string $source = 'online'
    ): int {
        $source = sanitize_key( $source );

        // The Free policy is deliberately simple: all active reservations and
        // walk-ins share the physical venue capacity.
        $policy = array(
            'capacity'         => max( 1, absint( get_option( 'rwexec_total_capacity', 60 ) ) ),
            'include_walk_ins' => true,
        );

        // Pro owns selective reservation-capacity behaviour. The filter is a
        // shared extension point; the Free package does not contain that policy.
        if ( 'walk_in' !== $source ) {
            $policy = apply_filters(
                'rwexec_reservations_capacity_policy',
                $policy,
                $source,
                $reservation_date,
                $start_time,
                $end_time,
                $exclude_reservation_id
            );
        }

        $capacity = max( 1, absint( $policy['capacity'] ?? get_option( 'rwexec_total_capacity', 60 ) ) );
        $include_walk_ins = ! empty( $policy['include_walk_ins'] );

        $existing_guests = self::get_existing_guests(
            $reservation_date,
            $start_time,
            $end_time,
            $exclude_reservation_id,
            $include_walk_ins
        );

        return max( 0, $capacity - $existing_guests );
    }

    public static function check(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $guest_count,
        int $exclude_reservation_id = 0,
        string $source = 'online'
    ) {
        $remaining_capacity = self::get_remaining_capacity(
            $reservation_date,
            $start_time,
            $end_time,
            $exclude_reservation_id,
            $source
        );

        if ( $guest_count > $remaining_capacity ) {
            $limit_label = ( 'walk_in' === $source || 'combined_live' === self::mode() )
                ? 'total venue capacity'
                : 'configured reservation capacity';

            return new WP_Error(
                'rwexec_capacity_exceeded',
                sprintf(
                    'This reservation would exceed the %s by %d guest(s).',
                    $limit_label,
                    $guest_count - $remaining_capacity
                )
            );
        }

        return true;
    }
}
