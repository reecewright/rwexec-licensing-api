<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Email {

    public static function template_types(): array {
        return array(
            'confirmation' => array(
                'label' => 'Booking Confirmation',
                'default_subject' => 'Reservation confirmed – {restaurant_name}',
                'default_heading' => 'Reservation Confirmed',
                'default_body' => '<p>Hi {customer_name},</p><p>Your reservation at {restaurant_name} is confirmed.</p>{reservation_details}<p>We look forward to seeing you.</p>',
                'default_button_text' => '',
                'default_button_url' => '',
            ),
            'update' => array(
                'label' => 'Booking Updated',
                'default_subject' => 'Reservation updated – {restaurant_name}',
                'default_heading' => 'Reservation Updated',
                'default_body' => '<p>Hi {customer_name},</p><p>Your reservation details have been updated.</p>{reservation_details}<p>If you did not request this change, please contact us.</p>',
                'default_button_text' => '',
                'default_button_url' => '',
            ),
            'cancellation' => array(
                'label' => 'Cancellation',
                'default_subject' => 'Reservation cancelled – {restaurant_name}',
                'default_heading' => 'Reservation Cancelled',
                'default_body' => '<p>Hi {customer_name},</p><p>Your reservation has been cancelled.</p>{reservation_details}<p>If this was unexpected, please contact us.</p>',
                'default_button_text' => '',
                'default_button_url' => '',
            ),
            'reminder' => array(
                'label' => 'Reservation Reminder',
                'default_subject' => 'Reservation reminder – {restaurant_name}',
                'default_heading' => 'Reservation Reminder',
                'default_body' => '<p>Hi {customer_name},</p><p>This is a reminder about your upcoming reservation at {restaurant_name}.</p>{reservation_details}<p>We look forward to seeing you.</p>',
                'default_button_text' => '',
                'default_button_url' => '',
            ),
            'feedback' => array(
                'label' => 'Feedback Request',
                'default_subject' => 'How was your visit? – {restaurant_name}',
                'default_heading' => 'Thank You for Visiting',
                'default_body' => '<p>Hi {customer_name},</p><p>Thank you for visiting {restaurant_name}. We hope you enjoyed your visit.</p><p>We would love to hear your feedback.</p>',
                'default_button_text' => 'Leave Feedback',
                'default_button_url' => '{feedback_url}',
            ),
            'admin_new_booking' => array(
                'label' => 'New Booking Notification to Restaurant',
                'default_subject' => 'New reservation – {customer_name}',
                'default_heading' => 'New Reservation',
                'default_body' => '<p>A new reservation has been created.</p>{reservation_details}',
                'default_button_text' => '',
                'default_button_url' => '',
            ),
            'admin_update' => array(
                'label' => 'Booking Updated Notification to Restaurant',
                'default_subject' => 'Reservation updated – {customer_name}',
                'default_heading' => 'Reservation Updated',
                'default_body' => '<p>A reservation has been updated.</p>{reservation_details}',
                'default_button_text' => '',
                'default_button_url' => '',
            ),
            'admin_cancellation' => array(
                'label' => 'Cancellation Notification to Restaurant',
                'default_subject' => 'Reservation cancelled – {customer_name}',
                'default_heading' => 'Reservation Cancelled',
                'default_body' => '<p>A reservation has been cancelled.</p>{reservation_details}',
                'default_button_text' => '',
                'default_button_url' => '',
            ),
            'admin_status' => array(
                'label' => 'Status Change Notification to Restaurant',
                'default_subject' => 'Reservation status changed – {customer_name}',
                'default_heading' => 'Reservation Status Changed',
                'default_body' => '<p>The reservation status is now <strong>{status}</strong>.</p>{reservation_details}',
                'default_button_text' => '',
                'default_button_url' => '',
            ),
        );
    }

    public static function detail_field_choices(): array {
        return array(
            'customer_name' => 'Name',
            'customer_email' => 'Email',
            'customer_phone' => 'Phone',
            'reservation_date' => 'Date',
            'reservation_time' => 'Time',
            'guest_count' => 'Guests',
            'allergies' => 'Allergies',
            'additional_information' => 'Additional Information',
            'custom_fields' => 'Custom Booking Fields',
        );
    }

    public static function default_detail_fields( string $type ): array {
        $defaults = array(
            'confirmation' => array( 'customer_name', 'customer_email', 'customer_phone', 'reservation_date', 'reservation_time', 'guest_count', 'allergies', 'additional_information' ),
            'update' => array( 'reservation_date', 'reservation_time', 'guest_count' ),
            'cancellation' => array( 'reservation_date', 'reservation_time', 'guest_count' ),
            'reminder' => array( 'reservation_date', 'reservation_time', 'guest_count' ),
            'feedback' => array( 'reservation_date', 'reservation_time' ),
            'admin_new_booking' => array( 'customer_name', 'customer_email', 'customer_phone', 'reservation_date', 'reservation_time', 'guest_count', 'allergies', 'additional_information', 'custom_fields' ),
            'admin_update' => array( 'customer_name', 'customer_email', 'customer_phone', 'reservation_date', 'reservation_time', 'guest_count' ),
            'admin_cancellation' => array( 'customer_name', 'customer_email', 'customer_phone', 'reservation_date', 'reservation_time', 'guest_count' ),
            'admin_status' => array( 'customer_name', 'reservation_date', 'reservation_time', 'guest_count' ),
        );
        return $defaults[ $type ] ?? array( 'reservation_date', 'reservation_time', 'guest_count' );
    }

    public static function template_detail_fields( string $type ): array {
        if ( ! RWExec_Reservations_License::is_premium() ) {
            return self::default_detail_fields( $type );
        }
        $saved = get_option( 'rwexec_email_template_' . $type . '_detail_fields', null );
        if ( ! is_array( $saved ) ) {
            return self::default_detail_fields( $type );
        }
        return array_values( array_intersect( array_keys( self::detail_field_choices() ), $saved ) );
    }

    public static function is_enabled( string $type ): bool {
        // Automated reminders and feedback requests are Pro features. Core
        // transactional messages such as confirmation/update/cancellation remain Free.
        if ( in_array( $type, array( 'reminder', 'feedback' ), true ) && ! RWExec_Reservations_License::is_premium() ) {
            return false;
        }
        return '1' === (string) get_option( 'rwexec_email_' . $type . '_enabled', '1' );
    }

    private static function restaurant_name(): string {
        return sanitize_text_field( get_option( 'rwexec_email_restaurant_name', get_bloginfo( 'name' ) ) );
    }

    private static function customer_email_valid( $reservation ): bool {
        return $reservation && empty( $reservation->is_historic ) && is_email( $reservation->customer_email ?? '' );
    }

    private static function format_date( string $date ): string {
        return RWExec_Reservations_Service::format_date( $date );
    }

    private static function format_time( string $time ): string {
        $timestamp = strtotime( '2000-01-01 ' . $time );
        return $timestamp ? wp_date( get_option( 'time_format' ), $timestamp ) : substr( $time, 0, 5 );
    }

    private static function details_html( $reservation, string $type = 'confirmation' ): string {
        $selected = self::template_detail_fields( $type );
        if ( empty( $selected ) ) {
            return '';
        }

        $allergies = trim( (string) ( $reservation->allergies ?? '' ) );
        $additional = trim( (string) ( $reservation->additional_information ?? '' ) );
        $values = array(
            'customer_name' => array( 'Name', esc_html( (string) ( $reservation->customer_name ?? '' ) ) ),
            'customer_email' => array( 'Email', esc_html( (string) ( $reservation->customer_email ?? '' ) ) ),
            'customer_phone' => array( 'Phone', esc_html( (string) ( $reservation->customer_phone ?? '' ) ) ),
            'reservation_date' => array( 'Date', esc_html( self::format_date( (string) ( $reservation->reservation_date ?? '' ) ) ) ),
            'reservation_time' => array( 'Time', esc_html( self::format_time( (string) ( $reservation->start_time ?? '' ) ) ) ),
            'guest_count' => array( 'Guests', (string) absint( $reservation->guest_count ?? 0 ) ),
            'allergies' => array( 'Allergies', $allergies ? nl2br( esc_html( $allergies ) ) : 'None provided' ),
            'additional_information' => array( 'Additional Information', $additional ? nl2br( esc_html( $additional ) ) : 'None provided' ),
        );

        $details_bg = sanitize_hex_color( get_option( 'rwexec_email_details_background_color', '#f8fafc' ) ) ?: '#f8fafc';
        $details_border = sanitize_hex_color( get_option( 'rwexec_email_details_border_color', '#e2e8f0' ) ) ?: '#e2e8f0';
        $accent = sanitize_hex_color( get_option( 'rwexec_email_secondary_color', '#c79a2b' ) ) ?: '#c79a2b';

        $html = '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="' . esc_attr( $details_bg ) . '" style="width:100%;border:1px solid ' . esc_attr( $details_border ) . ';border-radius:8px;border-collapse:separate;background:' . esc_attr( $details_bg ) . ';margin:24px 0 30px">';
        $html .= '<tr><td colspan="2" style="padding:16px 20px;border-bottom:1px solid ' . esc_attr( $details_border ) . ';color:' . esc_attr( $accent ) . ';font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.8px">Reservation Details</td></tr>';

        foreach ( $selected as $key ) {
            if ( 'custom_fields' === $key ) {
                foreach ( RWExec_Reservations_Form_Builder::decode_responses( $reservation ) as $entry ) {
                    if ( empty( $entry['show_email'] ) ) {
                        continue;
                    }
                    $html .= '<tr><td style="width:34%;padding:12px 20px;border-bottom:1px solid ' . esc_attr( $details_border ) . ';font-weight:700;vertical-align:top">' . esc_html( $entry['label'] ?? '' ) . '</td><td style="padding:12px 20px;border-bottom:1px solid ' . esc_attr( $details_border ) . ';vertical-align:top">' . nl2br( esc_html( $entry['value'] ?? '' ) ) . '</td></tr>';
                }
                continue;
            }
            if ( ! isset( $values[ $key ] ) ) {
                continue;
            }
            [ $label, $value ] = $values[ $key ];
            $html .= '<tr><td style="width:34%;padding:12px 20px;border-bottom:1px solid ' . esc_attr( $details_border ) . ';font-weight:700;vertical-align:top">' . esc_html( $label ) . '</td><td style="padding:12px 20px;border-bottom:1px solid ' . esc_attr( $details_border ) . ';vertical-align:top">' . $value . '</td></tr>';
        }
        $html .= '</table>';
        return $html;
    }

    public static function placeholders(): array {
        return array(
            '{customer_name}', '{customer_email}', '{customer_phone}', '{reservation_date}',
            '{reservation_time}', '{reservation_end_time}', '{guest_count}', '{status}', '{allergies}',
            '{additional_information}', '{restaurant_name}', '{restaurant_phone}', '{restaurant_email}',
            '{feedback_url}', '{reservation_details}', '{custom_fields}',
        );
    }

    private static function replacement_map( $reservation, string $type = 'confirmation' ): array {
        $allergies = trim( (string) ( $reservation->allergies ?? '' ) );
        $additional = trim( (string) ( $reservation->additional_information ?? '' ) );
        return array(
            '{customer_name}' => esc_html( (string) ( $reservation->customer_name ?? '' ) ),
            '{customer_email}' => esc_html( (string) ( $reservation->customer_email ?? '' ) ),
            '{customer_phone}' => esc_html( (string) ( $reservation->customer_phone ?? '' ) ),
            '{reservation_date}' => esc_html( self::format_date( (string) ( $reservation->reservation_date ?? '' ) ) ),
            '{reservation_time}' => esc_html( self::format_time( (string) ( $reservation->start_time ?? '' ) ) ),
            '{reservation_end_time}' => esc_html( self::format_time( (string) ( $reservation->end_time ?? '' ) ) ),
            '{guest_count}' => (string) absint( $reservation->guest_count ?? 0 ),
            '{status}' => esc_html( ucwords( str_replace( '_', ' ', (string) ( $reservation->status ?? '' ) ) ) ),
            '{allergies}' => $allergies ? nl2br( esc_html( $allergies ) ) : 'None provided',
            '{additional_information}' => $additional ? nl2br( esc_html( $additional ) ) : 'None provided',
            '{restaurant_name}' => esc_html( self::restaurant_name() ),
            '{restaurant_phone}' => esc_html( (string) get_option( 'rwexec_email_restaurant_phone', '' ) ),
            '{restaurant_email}' => esc_html( (string) get_option( 'rwexec_email_contact_email', get_option( 'admin_email' ) ) ),
            '{feedback_url}' => esc_url( (string) get_option( 'rwexec_email_feedback_url', '' ) ),
            '{reservation_details}' => self::details_html( $reservation, $type ),
            '{custom_fields}' => RWExec_Reservations_Form_Builder::email_html( $reservation ),
        );
    }

    public static function render_placeholders( string $content, $reservation, string $type = 'confirmation' ): string {
        return strtr( $content, self::replacement_map( $reservation, $type ) );
    }

    public static function template_value( string $type, string $field ): string {
        $types = self::template_types();
        if ( ! isset( $types[ $type ] ) ) {
            return '';
        }

        // Premium email template customisation degrades safely to the built-in
        // templates when a licence is not active. Saved Premium content is kept.
        if ( ! RWExec_Reservations_License::is_premium() ) {
            $default_key = 'default_' . $field;
            return isset( $types[ $type ][ $default_key ] ) ? (string) $types[ $type ][ $default_key ] : '';
        }

        $option = 'rwexec_email_template_' . $type . '_' . $field;
        $default_key = 'default_' . $field;
        $default = isset( $types[ $type ][ $default_key ] ) ? (string) $types[ $type ][ $default_key ] : '';
        return (string) get_option( $option, $default );
    }

    private static function layout( string $heading, string $body, string $button_text = '', string $button_url = '' ): string {
        $restaurant = self::restaurant_name();
        $logo = esc_url( get_option( 'rwexec_email_logo_url', '' ) );
        $footer_logo = esc_url( get_option( 'rwexec_email_footer_logo_url', '' ) );
        if ( ! $footer_logo ) {
            $footer_logo = $logo;
        }
        $website = esc_url( get_option( 'rwexec_email_website_url', home_url( '/' ) ) );
        $address = sanitize_textarea_field( get_option( 'rwexec_email_restaurant_address', '' ) );
        $phone = sanitize_text_field( get_option( 'rwexec_email_restaurant_phone', '' ) );
        $contact_email = sanitize_email( get_option( 'rwexec_email_contact_email', get_option( 'admin_email' ) ) );

        $primary = sanitize_hex_color( get_option( 'rwexec_email_accent_color', '#1e293b' ) ) ?: '#1e293b';
        $secondary = sanitize_hex_color( get_option( 'rwexec_email_secondary_color', '#c79a2b' ) ) ?: '#c79a2b';
        $background = sanitize_hex_color( get_option( 'rwexec_email_background_color', '#f3f4f6' ) ) ?: '#f3f4f6';
        $content_bg = sanitize_hex_color( get_option( 'rwexec_email_content_background_color', '#ffffff' ) ) ?: '#ffffff';
        $text_color = sanitize_hex_color( get_option( 'rwexec_email_text_color', '#334155' ) ) ?: '#334155';
        $footer_bg = sanitize_hex_color( get_option( 'rwexec_email_footer_background_color', '#1e293b' ) ) ?: '#1e293b';
        $footer_color = sanitize_hex_color( get_option( 'rwexec_email_footer_text_color', '#ffffff' ) ) ?: '#ffffff';
        $button_color = sanitize_hex_color( get_option( 'rwexec_email_button_color', $primary ) ) ?: $primary;
        $button_text_color = sanitize_hex_color( get_option( 'rwexec_email_button_text_color', '#ffffff' ) ) ?: '#ffffff';
        $logo_width = max( 60, min( 260, absint( get_option( 'rwexec_email_logo_width', 115 ) ) ) );
        $heading_size = max( 20, min( 42, absint( get_option( 'rwexec_email_heading_size', 32 ) ) ) );
        $radius = max( 0, min( 20, absint( get_option( 'rwexec_email_button_radius', 6 ) ) ) );
        $heading_font = sanitize_key( get_option( 'rwexec_email_heading_font', 'serif' ) );
        $heading_family = 'serif' === $heading_font ? "Georgia, 'Times New Roman', serif" : 'Arial, Helvetica, sans-serif';
        $show_divider = '1' === (string) get_option( 'rwexec_email_heading_divider', '1' );
        $show_footer_contact = '1' === (string) get_option( 'rwexec_email_footer_contact', '1' );
        $show_copyright = '1' === (string) get_option( 'rwexec_email_footer_copyright', '1' );
        $footer_text = wp_kses_post( get_option( 'rwexec_email_footer_text', '' ) );

        // Email template bodies are edited through WordPress' visual/text editor.
        // Convert intentional blank lines and line breaks into email-safe HTML so
        // plain text entered in the editor does not collapse onto a single line.
        $body = wpautop( $body );

        $brand = $logo
            ? '<a href="' . esc_url( $website ?: home_url( '/' ) ) . '" style="text-decoration:none"><img src="' . $logo . '" alt="' . esc_attr( $restaurant ) . '" width="' . esc_attr( $logo_width ) . '" style="display:block;width:' . esc_attr( $logo_width ) . 'px;max-width:100%;height:auto;margin:0 auto;border:0"></a>'
            : '<div style="font-size:22px;font-weight:700;text-align:center;color:' . esc_attr( $primary ) . '">' . esc_html( $restaurant ) . '</div>';

        $divider = $show_divider ? '<div style="width:90px;height:1px;background:' . esc_attr( $secondary ) . ';margin:16px auto 0"></div>' : '';
        $button = '';
        if ( $button_text && $button_url ) {
            $button = '<div style="text-align:center;margin:26px 0 30px"><a href="' . esc_url( $button_url ) . '" style="display:inline-block;padding:13px 24px;background:' . esc_attr( $button_color ) . ';color:' . esc_attr( $button_text_color ) . ';text-decoration:none;border-radius:' . esc_attr( $radius ) . 'px;font-size:14px;font-weight:700">' . esc_html( $button_text ) . '</a></div>';
        }

        $footer_logo_html = $footer_logo ? '<div style="margin:0 0 12px"><img src="' . $footer_logo . '" alt="' . esc_attr( $restaurant ) . '" width="80" style="display:block;width:80px;max-width:80px;height:auto;margin:0 auto;border:0"></div>' : '';
        $footer_contact = '';
        if ( $show_footer_contact ) {
            if ( $address ) {
                $footer_contact .= '<div style="margin:5px 0 0">' . nl2br( esc_html( $address ) ) . '</div>';
            }
            $links = array();
            if ( $phone ) {
                $links[] = '<a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ) . '" style="color:' . esc_attr( $footer_color ) . ';text-decoration:none">' . esc_html( $phone ) . '</a>';
            }
            if ( $contact_email ) {
                $links[] = '<a href="mailto:' . esc_attr( $contact_email ) . '" style="color:' . esc_attr( $footer_color ) . ';text-decoration:none">' . esc_html( $contact_email ) . '</a>';
            }
            if ( $website ) {
                $host = wp_parse_url( $website, PHP_URL_HOST );
                $links[] = '<a href="' . esc_url( $website ) . '" style="color:' . esc_attr( $footer_color ) . ';text-decoration:none">' . esc_html( $host ?: $website ) . '</a>';
            }
            if ( $links ) {
                $footer_contact .= '<div style="margin-top:14px">' . implode( ' <span style="color:' . esc_attr( $secondary ) . '">&nbsp;|&nbsp;</span> ', $links ) . '</div>';
            }
        }
        $copyright = $show_copyright ? '<div style="margin-top:22px;padding-top:15px;border-top:1px solid ' . esc_attr( $secondary ) . ';color:' . esc_attr( $secondary ) . '">© ' . esc_html( wp_date( 'Y' ) ) . ' ' . esc_html( $restaurant ) . '</div>' : '';

        return '<!doctype html><html><body style="margin:0;padding:0;background:' . esc_attr( $background ) . ';font-family:Arial,Helvetica,sans-serif;color:' . esc_attr( $text_color ) . '">'
            . '<div style="max-width:660px;margin:0 auto;padding:28px 14px">'
            . '<div style="background:' . esc_attr( $content_bg ) . ';border-radius:10px;overflow:hidden;border:1px solid #e2e8f0">'
            . '<div style="padding:26px 30px 10px;text-align:center">' . $brand . '</div>'
            . '<div style="padding:8px 30px 28px;text-align:center"><h1 style="margin:0;color:' . esc_attr( $primary ) . ';font-family:' . esc_attr( $heading_family ) . ';font-size:' . esc_attr( $heading_size ) . 'px;line-height:1.25;font-weight:400">' . wp_kses_post( $heading ) . '</h1>' . $divider . '</div>'
            . '<div style="padding:0 30px 30px;font-size:15px;line-height:1.7;color:' . esc_attr( $text_color ) . '">' . wp_kses_post( $body ) . $button . '</div>'
            . '<div bgcolor="' . esc_attr( $footer_bg ) . '" style="padding:30px 24px 24px;background:' . esc_attr( $footer_bg ) . ';color:' . esc_attr( $footer_color ) . ';text-align:center;font-size:12px;line-height:1.7">'
            . $footer_logo_html . '<div style="font-size:14px;font-weight:700">' . esc_html( $restaurant ) . '</div>' . $footer_contact
            . ( $footer_text ? '<div style="margin-top:14px">' . $footer_text . '</div>' : '' ) . $copyright
            . '</div></div></div></body></html>';
    }

    private static function send( string $to, string $subject, string $heading, string $body, string $button_text = '', string $button_url = '' ): bool {
        if ( ! is_email( $to ) ) {
            return false;
        }

        $from_name = sanitize_text_field( get_option( 'rwexec_email_from_name', self::restaurant_name() ) );
        $from_email = sanitize_email( get_option( 'rwexec_email_from_email', get_option( 'admin_email' ) ) );
        $reply_to = sanitize_email( get_option( 'rwexec_email_contact_email', get_option( 'admin_email' ) ) );
        $headers = array( 'Content-Type: text/html; charset=UTF-8' );

        if ( $from_email ) {
            $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
        }
        if ( $reply_to ) {
            $headers[] = 'Reply-To: ' . $reply_to;
        }

        return (bool) wp_mail( $to, wp_strip_all_tags( $subject ), self::layout( $heading, $body, $button_text, $button_url ), $headers );
    }

    private static function send_template( string $type, string $to, $reservation ): bool {
        $subject = self::render_placeholders( self::template_value( $type, 'subject' ), $reservation, $type );
        $heading = self::render_placeholders( self::template_value( $type, 'heading' ), $reservation, $type );
        $body = self::render_placeholders( self::template_value( $type, 'body' ), $reservation, $type );
        $button_text = self::render_placeholders( self::template_value( $type, 'button_text' ), $reservation, $type );
        $button_url = self::render_placeholders( self::template_value( $type, 'button_url' ), $reservation, $type );

        return self::send( $to, $subject, $heading, $body, wp_strip_all_tags( $button_text ), $button_url );
    }

    private static function mark_sent( int $reservation_id, string $column ): void {
        global $wpdb;
        $allowed = array( 'confirmation_sent_at', 'update_email_sent_at', 'cancellation_sent_at', 'reminder_sent_at', 'feedback_sent_at' );
        if ( ! in_array( $column, $allowed, true ) ) {
            return;
        }
        $wpdb->update(
            $wpdb->prefix . 'rwexec_reservations',
            array( $column => current_time( 'mysql' ) ),
            array( 'id' => $reservation_id )
        );
    }

    public static function send_confirmation( int $reservation_id ): bool {
        if ( ! self::is_enabled( 'confirmation' ) ) {
            return false;
        }
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        if ( ! self::customer_email_valid( $r ) || ! empty( $r->confirmation_sent_at ) ) {
            return false;
        }
        $sent = self::send_template( 'confirmation', $r->customer_email, $r );
        if ( $sent ) {
            self::mark_sent( $reservation_id, 'confirmation_sent_at' );
        }
        return $sent;
    }

    public static function send_update( int $reservation_id ): bool {
        if ( ! self::is_enabled( 'update' ) ) {
            return false;
        }
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        if ( ! self::customer_email_valid( $r ) || 'cancelled' === $r->status ) {
            return false;
        }
        $sent = self::send_template( 'update', $r->customer_email, $r );
        if ( $sent ) {
            self::mark_sent( $reservation_id, 'update_email_sent_at' );
        }
        return $sent;
    }

    public static function send_cancellation( int $reservation_id ): bool {
        if ( ! self::is_enabled( 'cancellation' ) ) {
            return false;
        }
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        if ( ! self::customer_email_valid( $r ) ) {
            return false;
        }
        $sent = self::send_template( 'cancellation', $r->customer_email, $r );
        if ( $sent ) {
            self::mark_sent( $reservation_id, 'cancellation_sent_at' );
        }
        return $sent;
    }

    public static function send_reminder( int $reservation_id ): bool {
        if ( ! self::is_enabled( 'reminder' ) ) {
            return false;
        }
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        if ( ! self::customer_email_valid( $r ) || 'confirmed' !== $r->status || ! empty( $r->reminder_sent_at ) ) {
            return false;
        }
        $sent = self::send_template( 'reminder', $r->customer_email, $r );
        if ( $sent ) {
            self::mark_sent( $reservation_id, 'reminder_sent_at' );
        }
        return $sent;
    }

    public static function send_feedback( int $reservation_id ): bool {
        if ( ! self::is_enabled( 'feedback' ) ) {
            return false;
        }
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        if ( ! self::customer_email_valid( $r ) || 'completed' !== $r->status || ! empty( $r->feedback_sent_at ) ) {
            return false;
        }
        $sent = self::send_template( 'feedback', $r->customer_email, $r );
        if ( $sent ) {
            self::mark_sent( $reservation_id, 'feedback_sent_at' );
        }
        return $sent;
    }

    public static function send_admin_new_booking( int $reservation_id ): bool {
        if ( ! self::is_enabled( 'admin_new_booking' ) ) {
            return false;
        }
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        if ( ! $r || ! empty( $r->is_historic ) ) {
            return false;
        }
        $to = sanitize_email( get_option( 'rwexec_email_admin_recipient', get_option( 'admin_email' ) ) );
        if ( ! $to ) {
            return false;
        }
        return self::send_template( 'admin_new_booking', $to, $r );
    }

    private static function restaurant_recipient(): string {
        return sanitize_email( get_option( 'rwexec_email_admin_recipient', get_option( 'admin_email' ) ) );
    }

    public static function send_admin_update( int $reservation_id ): bool {
        if ( ! self::is_enabled( 'admin_update' ) ) { return false; }
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        $to = self::restaurant_recipient();
        return ( $r && empty( $r->is_historic ) && $to ) ? self::send_template( 'admin_update', $to, $r ) : false;
    }

    public static function send_admin_status_change( int $reservation_id, string $old_status, string $new_status ): bool {
        if ( $old_status === $new_status ) { return false; }
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        $to = self::restaurant_recipient();
        if ( ! $r || ! empty( $r->is_historic ) || ! $to ) { return false; }
        if ( 'cancelled' === $new_status ) {
            return self::is_enabled( 'admin_cancellation' ) ? self::send_template( 'admin_cancellation', $to, $r ) : false;
        }
        return self::is_enabled( 'admin_status' ) ? self::send_template( 'admin_status', $to, $r ) : false;
    }

    public static function sample_reservation() {
        $start = '19:00:00';
        $duration = max( 15, absint( get_option( 'rwexec_reservation_duration', 105 ) ) );
        $start_ts = strtotime( '2026-09-12 ' . $start );
        $end = $start_ts ? date( 'H:i:s', $start_ts + ( $duration * MINUTE_IN_SECONDS ) ) : '20:45:00';

        return (object) array(
            'id' => 123,
            'customer_name' => 'Alex Taylor',
            'customer_email' => 'alex@example.com',
            'customer_phone' => '07123 456789',
            'reservation_date' => '2026-09-12',
            'start_time' => $start,
            'end_time' => $end,
            'guest_count' => 4,
            'status' => 'confirmed',
            'allergies' => 'Peanut allergy',
            'additional_information' => 'Please seat us somewhere quieter if possible.',
        );
    }

    public static function preview_template( string $type ): string {
        if ( ! isset( self::template_types()[ $type ] ) ) {
            return '';
        }
        $r = self::sample_reservation();
        $heading = self::render_placeholders( self::template_value( $type, 'heading' ), $r, $type );
        $body = self::render_placeholders( self::template_value( $type, 'body' ), $r, $type );
        $button_text = self::render_placeholders( self::template_value( $type, 'button_text' ), $r, $type );
        $button_url = self::render_placeholders( self::template_value( $type, 'button_url' ), $r, $type );
        return self::layout( $heading, $body, wp_strip_all_tags( $button_text ), $button_url );
    }

    public static function send_test( string $type, string $to ): bool {
        if ( ! isset( self::template_types()[ $type ] ) || ! is_email( $to ) ) {
            return false;
        }
        return self::send_template( $type, $to, self::sample_reservation() );
    }

    public static function process_scheduled(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'rwexec_reservations';
        $processed = 0;
        $now = RWExec_Reservations_Service::restaurant_now();

        if ( self::is_enabled( 'reminder' ) ) {
            $hours = min( 168, max( 1, absint( get_option( 'rwexec_email_reminder_hours', 24 ) ) ) );
            $remind_by = $now->modify( '+' . $hours . ' hours' );
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE status='confirmed' AND is_historic=0 AND reminder_sent_at IS NULL AND CONCAT(reservation_date,' ',start_time) > %s AND CONCAT(reservation_date,' ',start_time) <= %s",
                $now->format( 'Y-m-d H:i:s' ),
                $remind_by->format( 'Y-m-d H:i:s' )
            ) );
            foreach ( $rows as $row ) {
                if ( self::send_reminder( (int) $row->id ) ) {
                    $processed++;
                }
            }
        }

        if ( RWExec_Reservations_License::is_premium() && self::is_enabled( 'feedback' ) ) {
            $delay = absint( get_option( 'rwexec_email_feedback_delay_hours', 2 ) );
            $cutoff = $now->modify( '-' . $delay . ' hours' )->format( 'Y-m-d H:i:s' );
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE status='completed' AND is_historic=0 AND feedback_sent_at IS NULL AND completed_at IS NOT NULL AND completed_at <= %s",
                $cutoff
            ) );
            foreach ( $rows as $row ) {
                if ( self::send_feedback( (int) $row->id ) ) {
                    $processed++;
                }
            }
        }

        return $processed;
    }
}
