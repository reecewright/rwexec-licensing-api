=== RWExec Reservations ===
Contributors: rwexec
Tags: reservations, restaurant, bookings, tables, availability
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Restaurant reservations, availability, walk-ins and live venue capacity management for WordPress.

== Description ==

RWExec Reservations is a restaurant reservation plugin for WordPress with a public booking form and day-to-day reservation management for staff.

The Free/Core plugin works without a paid licence.

Free features include:

* Public booking shortcode: `[rwexec_reservations]`
* Front-end staff management shortcode: `[rwexec_reservations_admin]`
* Staff logout shortcode: `[rwexec_logout_button]`
* Weekly opening hours and availability
* Visit-duration and overlapping-capacity checks
* Total venue capacity
* Live current occupancy / seats remaining
* Walk-in Quick Add
* Manual reservations
* Reservation editing and table/reference allocation
* Confirmed, Checked In, Completed, Cancelled and No Show workflows
* Allergies and booking-specific additional information
* Late indicators and operational status tools
* Built-in transactional booking emails
* Reservations Staff and Reservations Admin roles
* First-run setup wizard
* Configurable data retention on uninstall

= RWExec Reservations Pro =

Optional premium functionality is supplied by a separate RWExec Reservations Pro add-on that is not included in this WordPress.org plugin.

Pro adds advanced capacity modes and separate reservation capacity, special-date overrides, reminder and feedback automation, editable email templates, customer history/notes/preferences, marketing consent/export, custom booking fields/notes and advanced booking-form styling.

The Free/Core plugin remains usable when no Pro add-on or licence is present.

== Installation ==

1. Install and activate RWExec Reservations.
2. Complete the first-run setup wizard.
3. Configure restaurant details, weekly opening hours, capacity and booking rules.
4. Add `[rwexec_reservations]` to the page where customers should book.
5. If you use the front-end staff interface, add `[rwexec_reservations_admin]` to the staff page.

The setup wizard can be run again from Reservations > Settings > Setup Wizard.

== External Service: RWExec Licensing ==

The Free/Core plugin does not require an RWExec account or licence for its Free features.

If you choose to activate RWExec Reservations Pro, the licence screen communicates with the RWExec licensing service at `https://licensing.rwexec.com`.

When a licence is activated, validated or deactivated, the plugin sends:

* The licence key entered by the administrator
* The product identifier
* The site's WordPress home URL
* A randomly generated installation/instance identifier
* The installed RWExec Reservations version

While a licence key remains configured, the plugin periodically validates that licence so Pro entitlement can remain current.

Reservation details, guest names, guest contact details, allergies, booking notes and other restaurant/customer booking data are not sent to the RWExec licensing service as part of licence validation.

RWExec account and subscription management is provided at `https://account.rwexec.com`.

== Email Delivery ==

RWExec Reservations sends transactional email using WordPress `wp_mail()`.

For production websites, configure authenticated SMTP or a transactional email provider using a suitable WordPress mail plugin or your hosting provider.

RWExec Reservations does not store SMTP credentials.

== Roles ==

= Reservations Staff =

Intended for day-to-day reservation operations, including viewing and updating reservations, adding bookings, checking guests in and assigning table/reference information.

= Reservations Admin =

Includes staff functionality plus plugin configuration and administration. WordPress Administrators are also granted the RWExec reservation capabilities.

== Data Retention ==

Deactivating RWExec Reservations does not delete reservation data.

By default, deleting the plugin also preserves RWExec data. An administrator can opt into permanent cleanup under Reservations > Settings > General > Plugin Data on Uninstall.

== Timezone ==

Set the restaurant timezone under Reservations > Settings > General.

Reservation timing, availability, late indicators, automatic No Show processing and booking notice calculations use the configured restaurant timezone.

== Privacy ==

Booking information entered through the reservation form is stored in the site's WordPress database.

Site owners are responsible for providing any privacy information and lawful basis required for the personal data they collect through their booking form.

The optional RWExec licensing service is described in the External Service section above.

== Frequently Asked Questions ==

= Does the Free plugin require a licence? =

No. The Free/Core reservation system works without a paid licence.

= Where are the Pro features? =

Premium functionality is provided by the separate RWExec Reservations Pro add-on. Pro code is not bundled in the WordPress.org Free/Core plugin.

= Will my bookings stop working if I do not have Pro? =

No. Free/Core reservation functionality remains available without the Pro add-on.

== Changelog ==

= 1.0.0 =
* Initial WordPress.org release.
* Public restaurant booking form and staff reservation management.
* Weekly availability, total venue capacity and live occupancy.
* Walk-in Quick Add and reservation status workflows.
* Transactional booking emails and setup wizard.
* Optional integration with the separately distributed RWExec Reservations Pro add-on.
