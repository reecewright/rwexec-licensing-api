RWExec Reservations Pro 1.0.0

Companion add-on for RWExec Reservations.

Requires:
- RWExec Reservations 1.0.0 or later
- Active RWExec Reservations Pro licence

This package contains Pro-only modules extracted from the public/free core, including special dates, customer management pages, email template management and the selectable reservation-capacity policy.
