<?php
/**
 * Plugin Name: RWExec Reservations Pro
 * Plugin URI: https://rwexec.com
 * Description: Pro features for RWExec Reservations, including advanced capacity modes, special dates, customer tools and advanced communications.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Requires Plugins: rwexec-reservations
 * Author: RWExec
 * Author URI: https://rwexec.com
 * Text Domain: rwexec-reservations-pro
 */

defined( 'ABSPATH' ) || exit;

define( 'RWEXEC_RESERVATIONS_PRO_VERSION', '1.0.0' );
define( 'RWEXEC_RESERVATIONS_PRO_FILE', __FILE__ );
define( 'RWEXEC_RESERVATIONS_PRO_PATH', plugin_dir_path( __FILE__ ) );

add_action( 'plugins_loaded', static function () {
    if ( ! defined( 'RWEXEC_RESERVATIONS_VERSION' ) || ! class_exists( 'RWExec_Reservations_License' ) ) {
        return;
    }

    require_once RWEXEC_RESERVATIONS_PRO_PATH . 'includes/class-rwexec-reservations-special-dates.php';
    require_once RWEXEC_RESERVATIONS_PRO_PATH . 'admin/pages/class-rwexec-reservations-special-dates-page.php';
    require_once RWEXEC_RESERVATIONS_PRO_PATH . 'admin/pages/class-rwexec-reservations-email-templates-page.php';
    require_once RWEXEC_RESERVATIONS_PRO_PATH . 'admin/pages/class-rwexec-reservations-customers-page.php';
    require_once RWEXEC_RESERVATIONS_PRO_PATH . 'admin/pages/class-rwexec-reservations-customer-details-page.php';

    // The selectable capacity policy lives in Pro. Free always falls back to
    // the single combined physical venue-capacity calculation.
    add_filter( 'rwexec_reservations_capacity_mode', static function ( $mode ) {
        if ( ! RWExec_Reservations_License::is_premium() ) {
            return 'combined_live';
        }
        $saved = sanitize_key( (string) get_option( 'rwexec_capacity_mode', 'online_limit' ) );
        return in_array( $saved, array( 'online_limit', 'combined_live' ), true ) ? $saved : 'online_limit';
    } );

    add_filter( 'rwexec_reservations_capacity_policy', static function ( array $policy, string $source ) {
        if ( ! RWExec_Reservations_License::is_premium() || 'walk_in' === $source ) {
            return $policy;
        }

        $mode = sanitize_key( (string) get_option( 'rwexec_capacity_mode', 'online_limit' ) );
        if ( 'online_limit' === $mode ) {
            $total = max( 1, absint( get_option( 'rwexec_total_capacity', 60 ) ) );
            $online = max( 1, min( $total, absint( get_option( 'rwexec_online_capacity', $total ) ) ) );
            return array(
                'capacity'         => $online,
                'include_walk_ins' => false,
            );
        }

        return array(
            'capacity'         => max( 1, absint( get_option( 'rwexec_total_capacity', 60 ) ) ),
            'include_walk_ins' => true,
        );
    }, 10, 2 );
}, 5 );

add_action( 'admin_notices', static function () {
    if ( defined( 'RWEXEC_RESERVATIONS_VERSION' ) ) {
        return;
    }
    if ( ! current_user_can( 'activate_plugins' ) ) {
        return;
    }
    echo '<div class="notice notice-error"><p><strong>RWExec Reservations Pro</strong> requires the free RWExec Reservations plugin to be installed and active.</p></div>';
} );
