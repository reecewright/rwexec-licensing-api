<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Capacity {

    public static function mode(): string {
        $mode = sanitize_key( (string) get_option( 'rwexec_capacity_mode', 'online_limit' ) );
        return in_array( $mode, array( 'online_limit', 'combined_live' ), true ) ? $mode : 'online_limit';
    }

    public static function get_existing_guests(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $exclude_reservation_id = 0,
        bool $include_walk_ins = true
    ): int {
        global $wpdb;

        $table_name = $wpdb->prefix . 'rwexec_reservations';
        $active_statuses = "'confirmed','checked_in','arrived'";
        $walk_in_clause = $include_walk_ins ? '' : " AND COALESCE(source, '') != 'walk_in'";

        if ( $exclude_reservation_id > 0 ) {
            $sql = $wpdb->prepare(
                "SELECT COALESCE(SUM(guest_count),0)
                 FROM {$table_name}
                 WHERE reservation_date = %s
                 AND id != %d
                 AND status IN ({$active_statuses})
                 {$walk_in_clause}
                 AND start_time < %s
                 AND end_time > %s",
                $reservation_date,
                $exclude_reservation_id,
                $end_time,
                $start_time
            );
        } else {
            $sql = $wpdb->prepare(
                "SELECT COALESCE(SUM(guest_count),0)
                 FROM {$table_name}
                 WHERE reservation_date = %s
                 AND status IN ({$active_statuses})
                 {$walk_in_clause}
                 AND start_time < %s
                 AND end_time > %s",
                $reservation_date,
                $end_time,
                $start_time
            );
        }

        return absint( $wpdb->get_var( $sql ) );
    }

    public static function get_remaining_capacity(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $exclude_reservation_id = 0,
        string $source = 'online'
    ): int {
        $source = sanitize_key( $source );

        // Walk-ins are always checked against the physical venue capacity so staff
        // cannot quick-add guests beyond the restaurant's hard seating limit.
        if ( 'walk_in' === $source ) {
            $capacity = absint( get_option( 'rwexec_total_capacity', 60 ) );
            $include_walk_ins = true;
        } elseif ( 'combined_live' === self::mode() ) {
            // Combined live capacity means every active booking and walk-in shares
            // the same physical venue limit.
            $capacity = absint( get_option( 'rwexec_total_capacity', 60 ) );
            $include_walk_ins = true;
        } else {
            // Online booking limit mode preserves a separate reservation allowance.
            // Walk-ins are recorded but do not reduce the online/manual booking pool.
            $capacity = absint( get_option( 'rwexec_online_capacity', 45 ) );
            $include_walk_ins = false;
        }

        $existing_guests = self::get_existing_guests(
            $reservation_date,
            $start_time,
            $end_time,
            $exclude_reservation_id,
            $include_walk_ins
        );

        return max( 0, $capacity - $existing_guests );
    }

    public static function check(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $guest_count,
        int $exclude_reservation_id = 0,
        string $source = 'online'
    ) {
        $remaining_capacity = self::get_remaining_capacity(
            $reservation_date,
            $start_time,
            $end_time,
            $exclude_reservation_id,
            $source
        );

        if ( $guest_count > $remaining_capacity ) {
            $limit_label = ( 'walk_in' === $source || 'combined_live' === self::mode() )
                ? 'total venue capacity'
                : 'configured reservation capacity';

            return new WP_Error(
                'rwexec_capacity_exceeded',
                sprintf(
                    'This reservation would exceed the %s by %d guest(s).',
                    $limit_label,
                    $guest_count - $remaining_capacity
                )
            );
        }

        return true;
    }
}
