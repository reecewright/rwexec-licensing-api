<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Service {

    public static function restaurant_timezone(): DateTimeZone {
        $timezone_name = get_option( 'rwexec_restaurant_timezone', 'Europe/London' );
        try {
            return new DateTimeZone( $timezone_name ?: 'Europe/London' );
        } catch ( Exception $e ) {
            return new DateTimeZone( 'Europe/London' );
        }
    }

    public static function restaurant_now(): DateTimeImmutable {
        return new DateTimeImmutable( 'now', self::restaurant_timezone() );
    }


    private static function parse_reservation_datetime( string $date, string $time ) {
        $date = trim( $date );
        $time = substr( trim( $time ), 0, 5 );
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time ) ) {
            return false;
        }

        $datetime = DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $date . ' ' . $time, self::restaurant_timezone() );
        $errors = DateTimeImmutable::getLastErrors();
        if ( false === $datetime || ( is_array( $errors ) && ( $errors['warning_count'] > 0 || $errors['error_count'] > 0 ) ) ) {
            return false;
        }

        return $datetime->format( 'Y-m-d H:i' ) === $date . ' ' . $time ? $datetime : false;
    }

    private static function capacity_lock_key( string $date ): string {
        return 'rwexec_capacity_lock_' . md5( $date );
    }

    private static function acquire_capacity_lock( string $date ): bool {
        $key = self::capacity_lock_key( $date );
        $now = time();
        for ( $attempt = 0; $attempt < 20; $attempt++ ) {
            if ( add_option( $key, $now, '', 'no' ) ) {
                return true;
            }
            $started = absint( get_option( $key, 0 ) );
            if ( $started && ( $now - $started ) > 15 ) {
                delete_option( $key );
                continue;
            }
            usleep( 50000 );
            $now = time();
        }
        return false;
    }

    private static function release_capacity_lock( string $date ): void {
        delete_option( self::capacity_lock_key( $date ) );
    }

    private static function validate_core_values( array $data ) {
        $name = sanitize_text_field( $data['customer_name'] ?? '' );
        $date = sanitize_text_field( $data['reservation_date'] ?? '' );
        $time = sanitize_text_field( $data['start_time'] ?? '' );
        $guest_count = absint( $data['guest_count'] ?? 0 );

        if ( '' === trim( $name ) ) {
            return new WP_Error( 'rwexec_customer_name_required', 'A customer name is required.' );
        }
        if ( $guest_count < 1 ) {
            return new WP_Error( 'rwexec_guest_count_required', 'The reservation must include at least one guest.' );
        }
        if ( false === self::parse_reservation_datetime( $date, $time ) ) {
            return new WP_Error( 'rwexec_invalid_reservation_time', 'The reservation date or time is invalid.' );
        }

        return true;
    }

    public static function get_reservation( int $reservation_id ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rwexec_reservations';

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE id = %d",
                $reservation_id
            )
        );
    }

    public static function create_reservation( array $data ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'rwexec_reservations';
        $now = self::restaurant_now()->format( 'Y-m-d H:i:s' );
        $duration_minutes = absint( get_option( 'rwexec_reservation_duration', 105 ) );
        $reservation_date = sanitize_text_field( $data['reservation_date'] ?? '' );
        $start_time = sanitize_text_field( $data['start_time'] ?? '' );
        $guest_count = absint( $data['guest_count'] ?? 0 );
        $status = sanitize_key( $data['status'] ?? 'confirmed' );
        $source = sanitize_key( $data['source'] ?? 'manual' );
        $is_historic = ! empty( $data['is_historic'] );
        $suppress_notifications = ! empty( $data['suppress_notifications'] ) || $is_historic;
        if ( ! in_array( $status, array( 'confirmed', 'checked_in', 'completed', 'cancelled', 'no_show' ), true ) ) {
            $status = 'confirmed';
        }
        if ( ! in_array( $source, array( 'manual', 'online', 'walk_in' ), true ) ) {
            $source = 'manual';
        }

        $core_validation = self::validate_core_values( $data );
        if ( is_wp_error( $core_validation ) ) {
            return $core_validation;
        }

        // Walk-ins represent guests already accepted by staff rather than an online
        // reservation request. They still count against capacity, but are not restricted
        // to the public booking interval or online booking-hours rules.
        $availability_check = ( $is_historic || 'walk_in' === $source )
            ? true
            : RWExec_Reservations_Availability::check( $reservation_date, $start_time );

        if ( ! $is_historic && is_wp_error( $availability_check ) ) {
            $code = $availability_check->get_error_code();

            if ( 'rwexec_override_closed' === $code ) {
                return new WP_Error( 'rwexec_day_closed', $availability_check->get_error_message() );
            }

            if ( 'rwexec_override_walk_ins' === $code ) {
                return new WP_Error( 'rwexec_walk_ins_only', $availability_check->get_error_message() );
            }

            return $availability_check;
        }

        $start_datetime = self::parse_reservation_datetime( $reservation_date, $start_time );
        if ( $is_historic && $start_datetime > self::restaurant_now() ) {
            return new WP_Error( 'rwexec_historic_future_date', 'A historic booking must use a date and time in the past.' );
        }

        $end_time = $start_datetime
            ->modify( '+' . $duration_minutes . ' minutes' )
            ->format( 'H:i:s' );

        if ( ! $is_historic && ! self::acquire_capacity_lock( $reservation_date ) ) {
            return new WP_Error( 'rwexec_capacity_busy', 'Another reservation change is being processed for this date. Please try again.' );
        }

        $capacity_check = $is_historic ? true : RWExec_Reservations_Capacity::check(
            $reservation_date,
            $start_time,
            $end_time,
            $guest_count,
            0,
            $source
        );

        if ( ! $is_historic && is_wp_error( $capacity_check ) ) {
            self::release_capacity_lock( $reservation_date );
            return $capacity_check;
        }

        $inserted = $wpdb->insert(
            $table_name,
            array(
                'customer_name' => sanitize_text_field( $data['customer_name'] ?? '' ),
                'customer_email' => sanitize_email( $data['customer_email'] ?? '' ),
                'customer_phone' => sanitize_text_field( $data['customer_phone'] ?? '' ),
                'reservation_date' => $reservation_date,
                'start_time' => $start_time,
                'end_time' => $end_time,
                'guest_count' => $guest_count,
                'table_reference' => sanitize_text_field( $data['table_reference'] ?? '' ),
                'allergies' => sanitize_textarea_field( $data['allergies'] ?? '' ),
                'additional_information' => sanitize_textarea_field( $data['additional_information'] ?? '' ),
                'custom_fields_json' => isset( $data['custom_fields_json'] ) ? wp_kses_post( (string) $data['custom_fields_json'] ) : null,
                'marketing_email_consent' => ! empty( $data['marketing_email_consent'] ) ? 1 : 0,
                'marketing_consent_text' => sanitize_textarea_field( $data['marketing_consent_text'] ?? '' ),
                'marketing_consent_at' => ! empty( $data['marketing_email_consent'] ) ? sanitize_text_field( $data['marketing_consent_at'] ?? $now ) : null,
                'status' => $status,
                'source' => $source,
                'is_historic' => $is_historic ? 1 : 0,
                'arrived_at' => 'checked_in' === $status ? $now : null,
                'completed_at' => ( $is_historic || 'completed' === $status ) ? $start_datetime->format( 'Y-m-d H:i:s' ) : null,
                'created_at' => $now,
                'updated_at' => $now,
            )
        );

        if ( false === $inserted ) {
            if ( ! $is_historic ) { self::release_capacity_lock( $reservation_date ); }
            return new WP_Error( 'rwexec_reservation_create_failed', 'The reservation could not be created.' );
        }

        if ( ! $is_historic ) { self::release_capacity_lock( $reservation_date ); }
        $reservation_id = (int) $wpdb->insert_id;
        RWExec_Reservations_Customers::sync_reservation( $reservation_id );

        if ( ! $suppress_notifications ) {
            RWExec_Reservations_Email::send_confirmation( $reservation_id );
            RWExec_Reservations_Email::send_admin_new_booking( $reservation_id );
        }

        return $reservation_id;
    }

    public static function update_reservation(
        int $reservation_id,
        array $data,
        bool $allow_override = false
    ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'rwexec_reservations';
        $duration_minutes = absint( get_option( 'rwexec_reservation_duration', 105 ) );
        $reservation_date = sanitize_text_field( $data['reservation_date'] ?? '' );
        $start_time = sanitize_text_field( $data['start_time'] ?? '' );
        $guest_count = absint( $data['guest_count'] ?? 0 );
        $core_validation = self::validate_core_values( $data );
        if ( is_wp_error( $core_validation ) ) {
            return $core_validation;
        }
        $existing_reservation = self::get_reservation( $reservation_id );
        if ( ! $existing_reservation ) {
            return new WP_Error( 'rwexec_reservation_not_found', 'Reservation not found.' );
        }
        $is_historic = ! empty( $existing_reservation->is_historic );

        $start_datetime = self::parse_reservation_datetime( $reservation_date, $start_time );

        $end_time = $start_datetime
            ->modify( '+' . $duration_minutes . ' minutes' )
            ->format( 'H:i:s' );

        $availability_check = $is_historic ? true : RWExec_Reservations_Availability::check( $reservation_date, $start_time );
        if ( ! $is_historic && ! $allow_override && is_wp_error( $availability_check ) ) {
            return $availability_check;
        }

        if ( ! $is_historic && ! self::acquire_capacity_lock( $reservation_date ) ) {
            return new WP_Error( 'rwexec_capacity_busy', 'Another reservation change is being processed for this date. Please try again.' );
        }

        $capacity_check = $is_historic ? true : RWExec_Reservations_Capacity::check(
            $reservation_date,
            $start_time,
            $end_time,
            $guest_count,
            $reservation_id,
            sanitize_key( (string) ( $existing_reservation->source ?? 'manual' ) )
        );

        if ( ! $is_historic && ! $allow_override && is_wp_error( $capacity_check ) ) {
            self::release_capacity_lock( $reservation_date );
            return new WP_Error( 'rwexec_override_capacity', $capacity_check->get_error_message() );
        }

        $update_data = array(
            'customer_name' => sanitize_text_field( $data['customer_name'] ?? '' ),
            'customer_email' => sanitize_email( $data['customer_email'] ?? '' ),
            'customer_phone' => sanitize_text_field( $data['customer_phone'] ?? '' ),
            'reservation_date' => $reservation_date,
            'start_time' => $start_time,
            'end_time' => $end_time,
            'guest_count' => $guest_count,
            'table_reference' => sanitize_text_field( $data['table_reference'] ?? '' ),
            'allergies' => sanitize_textarea_field( $data['allergies'] ?? '' ),
            'additional_information' => sanitize_textarea_field( $data['additional_information'] ?? '' ),
            'updated_at' => self::restaurant_now()->format( 'Y-m-d H:i:s' ),
        );

        // Preserve any existing override audit unless this edit itself uses an override.
        if ( $allow_override ) {
            $update_data['override_used'] = 1;
            $update_data['override_reason'] = sanitize_key( $data['override_reason'] ?? 'manual' );
            $update_data['override_by'] = get_current_user_id();
            $update_data['override_at'] = self::restaurant_now()->format( 'Y-m-d H:i:s' );
        }

        $updated = $wpdb->update(
            $table_name,
            $update_data,
            array( 'id' => $reservation_id )
        );

        if ( ! $is_historic ) { self::release_capacity_lock( $reservation_date ); }

        if ( false === $updated ) {
            return new WP_Error( 'rwexec_reservation_update_failed', 'The reservation could not be updated.' );
        }

        if ( $existing_reservation && $updated > 0 ) {
            RWExec_Reservations_Customers::sync_reservation( $reservation_id );
            $schedule_changed =
                (string) $existing_reservation->reservation_date !== (string) $update_data['reservation_date'] ||
                substr( (string) $existing_reservation->start_time, 0, 5 ) !== substr( (string) $update_data['start_time'], 0, 5 );

            if ( $schedule_changed ) {
                $wpdb->update(
                    $table_name,
                    array( 'reminder_sent_at' => null ),
                    array( 'id' => $reservation_id )
                );
            }

            $changed =
                (string) $existing_reservation->customer_name !== (string) $update_data['customer_name'] ||
                (string) $existing_reservation->customer_email !== (string) $update_data['customer_email'] ||
                (string) $existing_reservation->customer_phone !== (string) $update_data['customer_phone'] ||
                (string) $existing_reservation->reservation_date !== (string) $update_data['reservation_date'] ||
                substr( (string) $existing_reservation->start_time, 0, 5 ) !== substr( (string) $update_data['start_time'], 0, 5 ) ||
                (int) $existing_reservation->guest_count !== (int) $update_data['guest_count'];

            if ( $changed && ! $is_historic ) {
                RWExec_Reservations_Email::send_update( $reservation_id );
                RWExec_Reservations_Email::send_admin_update( $reservation_id );
            }
        }

        return true;
    }


    public static function update_table_reference( int $reservation_id, string $table_reference ) {
        global $wpdb;

        if ( ! self::get_reservation( $reservation_id ) ) {
            return new WP_Error( 'rwexec_reservation_not_found', 'Reservation not found.' );
        }

        $updated = $wpdb->update(
            $wpdb->prefix . 'rwexec_reservations',
            array(
                'table_reference' => sanitize_text_field( $table_reference ),
                'updated_at' => self::restaurant_now()->format( 'Y-m-d H:i:s' ),
            ),
            array( 'id' => $reservation_id )
        );

        if ( false === $updated ) {
            return new WP_Error( 'rwexec_table_update_failed', 'The table assignment could not be saved.' );
        }

        return true;
    }

    public static function set_status( int $reservation_id, string $status ) {
        global $wpdb;

        $allowed = array( 'confirmed', 'checked_in', 'completed', 'cancelled', 'no_show' );
        $status = sanitize_key( $status );

        if ( ! in_array( $status, $allowed, true ) ) {
            return new WP_Error( 'rwexec_invalid_status', 'Invalid reservation status.' );
        }

        $reservation = self::get_reservation( $reservation_id );
        if ( ! $reservation ) {
            return new WP_Error( 'rwexec_reservation_not_found', 'Reservation not found.' );
        }
        if ( $status === (string) $reservation->status ) {
            return true;
        }

        $now_datetime = self::restaurant_now();
        $now = $now_datetime->format( 'Y-m-d H:i:s' );
        $data = array(
            'status' => $status,
            'updated_at' => $now,
        );

        if ( 'checked_in' === $status ) {
            $data['arrived_at'] = $now;
            $data['late_minutes'] = self::calculate_late_minutes_at( $reservation, $now_datetime );
            $data['cancelled_at'] = null;
            $data['no_show_at'] = null;
        } elseif ( 'completed' === $status ) {
            $data['completed_at'] = $now;
            $data['completion_source'] = 'manual';
        } elseif ( 'cancelled' === $status ) {
            $data['cancelled_at'] = $now;
        } elseif ( 'no_show' === $status ) {
            $data['no_show_at'] = $now;
            $data['late_minutes'] = self::calculate_late_minutes_at( $reservation, $now_datetime );
        } elseif ( 'confirmed' === $status ) {
            $data['arrived_at'] = null;
            $data['completed_at'] = null;
            $data['completion_source'] = null;
            $data['cancelled_at'] = null;
            $data['no_show_at'] = null;
            $data['late_minutes'] = null;
            $data['cancellation_sent_at'] = null;
            $data['feedback_sent_at'] = null;
        }

        $updated = $wpdb->update(
            $wpdb->prefix . 'rwexec_reservations',
            $data,
            array( 'id' => $reservation_id )
        );

        if ( false === $updated ) {
            return new WP_Error( 'rwexec_status_update_failed', 'The reservation status could not be updated.' );
        }

        RWExec_Reservations_Email::send_admin_status_change( $reservation_id, (string) $reservation->status, $status );

        if ( 'cancelled' === $status && 'cancelled' !== $reservation->status ) {
            RWExec_Reservations_Email::send_cancellation( $reservation_id );
        }

        return true;
    }

    public static function delete_reservation( int $reservation_id ): bool {
        global $wpdb;
        return false !== $wpdb->delete(
            $wpdb->prefix . 'rwexec_reservations',
            array( 'id' => $reservation_id ),
            array( '%d' )
        );
    }


    public static function process_automatic_no_shows(): int {
        global $wpdb;

        $threshold_minutes = absint(
            get_option( 'rwexec_no_show_after_minutes', 120 )
        );

        if ( $threshold_minutes < 1 ) {
            return 0;
        }

        $cutoff = ( self::restaurant_now() )
            ->modify( '-' . $threshold_minutes . ' minutes' )
            ->format( 'Y-m-d H:i:s' );

        $now = self::restaurant_now()->format( 'Y-m-d H:i:s' );
        $table_name = $wpdb->prefix . 'rwexec_reservations';

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table_name}
                 SET status = 'no_show',
                     no_show_at = %s,
                     late_minutes = %d,
                     updated_at = %s
                 WHERE status = 'confirmed'
                   AND CONCAT(reservation_date, ' ', start_time) <= %s",
                $now,
                $threshold_minutes,
                $now,
                $cutoff
            )
        );

        return false === $updated ? 0 : (int) $updated;
    }

    public static function process_automatic_completions(): int {
        global $wpdb;

        if ( ! RWExec_Reservations_License::is_premium() ) {
            return 0;
        }

        if ( '1' !== (string) get_option( 'rwexec_auto_complete_checked_in', '1' ) ) {
            return 0;
        }

        $hours = absint( get_option( 'rwexec_auto_complete_hours', 3 ) );
        $hours = min( 24, max( 1, $hours ) );

        $now = self::restaurant_now();
        $cutoff = $now->modify( '-' . $hours . ' hours' );
        $table_name = $wpdb->prefix . 'rwexec_reservations';

        $reservations = $wpdb->get_results(
            "SELECT id, reservation_date, start_time, end_time
             FROM {$table_name}
             WHERE status = 'checked_in'"
        );

        if ( empty( $reservations ) ) {
            return 0;
        }

        $completed = 0;
        $completed_at = $now->format( 'Y-m-d H:i:s' );
        $timezone = self::restaurant_timezone();

        foreach ( $reservations as $reservation ) {
            $start = DateTimeImmutable::createFromFormat(
                '!Y-m-d H:i:s',
                (string) $reservation->reservation_date . ' ' . (string) $reservation->start_time,
                $timezone
            );
            $end = DateTimeImmutable::createFromFormat(
                '!Y-m-d H:i:s',
                (string) $reservation->reservation_date . ' ' . (string) $reservation->end_time,
                $timezone
            );

            if ( false === $start || false === $end ) {
                continue;
            }

            // Reservations can run past midnight. An end time at or before the
            // start time belongs to the following calendar day.
            if ( $end <= $start ) {
                $end = $end->modify( '+1 day' );
            }

            if ( $end > $cutoff ) {
                continue;
            }

            $updated = $wpdb->update(
                $table_name,
                array(
                    'status'       => 'completed',
                    'completed_at'     => $completed_at,
                    'completion_source' => 'automatic',
                    'updated_at'       => $completed_at,
                ),
                array(
                    'id'     => (int) $reservation->id,
                    'status' => 'checked_in',
                )
            );

            if ( false !== $updated && $updated > 0 ) {
                $completed++;
            }
        }

        return $completed;
    }

    public static function format_date( string $date ): string {
        $date_object = DateTimeImmutable::createFromFormat( '!Y-m-d', $date, self::restaurant_timezone() );
        return $date_object ? $date_object->format( 'd-m-Y' ) : $date;
    }

    public static function calculate_late_minutes_at( $reservation, ?DateTimeImmutable $at = null ): int {
        if ( ! $reservation ) {
            return 0;
        }

        $booking = DateTimeImmutable::createFromFormat(
            '!Y-m-d H:i:s',
            $reservation->reservation_date . ' ' . $reservation->start_time,
            self::restaurant_timezone()
        );
        if ( false === $booking ) {
            return 0;
        }

        $at = $at ?: self::restaurant_now();
        $minutes = (int) floor( ( $at->getTimestamp() - $booking->getTimestamp() ) / MINUTE_IN_SECONDS );
        $grace = absint( get_option( 'rwexec_late_grace_minutes', 15 ) );

        return $minutes > $grace ? max( 1, $minutes ) : 0;
    }

    public static function get_late_minutes( $reservation ): int {
        if ( ! $reservation || 'confirmed' !== $reservation->status ) {
            return 0;
        }
        return self::calculate_late_minutes_at( $reservation, self::restaurant_now() );
    }

    public static function get_history_late_minutes( $reservation ): int {
        if ( ! $reservation ) {
            return 0;
        }

        if ( isset( $reservation->late_minutes ) && null !== $reservation->late_minutes && '' !== (string) $reservation->late_minutes ) {
            return max( 0, (int) $reservation->late_minutes );
        }

        if ( ! empty( $reservation->arrived_at ) ) {
            $arrived = DateTimeImmutable::createFromFormat(
                '!Y-m-d H:i:s',
                (string) $reservation->arrived_at,
                self::restaurant_timezone()
            );
            if ( $arrived ) {
                return self::calculate_late_minutes_at( $reservation, $arrived );
            }
        }

        // Legacy No Shows pre-date the frozen late_minutes field. Use the configured
        // threshold as a sensible historical fallback; new No Shows store the value.
        if ( 'no_show' === (string) $reservation->status ) {
            return absint( get_option( 'rwexec_no_show_after_minutes', 120 ) );
        }

        return 0;
    }

    public static function get_status_label( string $status ): string {
        $labels = array(
            'confirmed' => 'Confirmed',
            'checked_in' => 'Checked In',
            'completed' => 'Completed',
            'cancelled' => 'Cancelled',
            'no_show' => 'No Show',
            'arrived' => 'Checked In',
        );

        return $labels[ $status ] ?? ucwords( str_replace( '_', ' ', $status ) );
    }
}
