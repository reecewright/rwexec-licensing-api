<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservation_Details_Page {

    public static function render( $context = array() ) {
        $context = is_array( $context ) ? $context : array();
        $frontend = ! empty( $context['frontend'] );
        $base_url = $frontend ? esc_url_raw( $context['base_url'] ?? '' ) : '';
        RWExec_Reservations_Automation::run();

        $reservation_id = absint( $_GET['reservation_id'] ?? 0 );
        $reservation = RWExec_Reservations_Service::get_reservation( $reservation_id );

        if ( ! $reservation ) {
            wp_die( 'Reservation not found.' );
        }

        $late = RWExec_Reservations_Service::get_late_minutes( $reservation );
        $return_to = $frontend
            ? add_query_arg( array( 'rwexec_action'=>'view', 'reservation_id'=>$reservation->id ), $base_url )
            : add_query_arg( array( 'page'=>'rwexec-reservation-details', 'reservation_id'=>$reservation->id ), admin_url( 'admin.php' ) );
        ?>
        <div class="<?php echo $frontend ? 'rwexec-admin rwexec-staff-frontend' : 'wrap rwexec-admin'; ?>">
            <div class="rwexec-page-header">
                <div><h1><?php echo esc_html( $reservation->customer_name ); ?></h1><p class="rwexec-page-subtitle">Reservation details and attendance controls.</p></div>
                <a class="button" href="<?php echo esc_url( $frontend ? $base_url : admin_url( 'admin.php?page=rwexec-reservations' ) ); ?>">← Reservations</a>
            </div>

            <?php if ( isset( $_GET['updated'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Reservation updated.</p></div><?php endif; ?>
            <?php if ( isset( $_GET['status_updated'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Reservation status updated.</p></div><?php endif; ?>
            <?php if ( isset( $_GET['action_error'] ) ) : ?><div class="notice notice-error"><p><?php echo esc_html( rawurldecode( wp_unslash( $_GET['action_error'] ) ) ); ?></p></div><?php endif; ?>

            <div class="rwexec-status-summary">
                <span class="rwexec-badge rwexec-badge--<?php echo esc_attr( $reservation->status ); ?>"><?php echo esc_html( RWExec_Reservations_Service::get_status_label( $reservation->status ) ); ?></span>
                <?php if ( ! empty( $reservation->is_historic ) ) : ?><span class="rwexec-badge rwexec-badge--historic">Historic</span><?php endif; ?>
                <?php if ( $late > 0 ) : ?><span class="rwexec-badge rwexec-badge--late">Late <?php echo esc_html( $late ); ?> minutes</span><?php endif; ?>
            </div>

            <?php if ( ! empty( trim( (string) $reservation->allergies ) ) ) : ?>
                <div id="allergy-information" class="rwexec-allergy-warning"><strong>⚠ ALLERGY INFORMATION</strong><br><?php echo nl2br( esc_html( $reservation->allergies ) ); ?></div>
            <?php endif; ?>

            <div class="rwexec-actions">
                <a class="button button-primary" href="<?php echo esc_url( $frontend ? add_query_arg( array( 'rwexec_action'=>'edit','reservation_id'=>$reservation->id ), $base_url ) : add_query_arg( array( 'page'=>'rwexec-reservation-edit','reservation_id'=>$reservation->id ), admin_url( 'admin.php' ) ) ); ?>">Edit Reservation</a>

                <?php if ( 'confirmed' === $reservation->status ) : ?>
                    <?php self::status_form( $reservation->id, 'checked_in', 'Check In', 'button-primary', $return_to ); ?>
                <?php elseif ( 'checked_in' === $reservation->status ) : ?>
                    <?php self::status_form( $reservation->id, 'completed', 'Mark Completed', 'button-primary', $return_to ); ?>
                <?php endif; ?>

                <?php self::status_dropdown( $reservation->id, $reservation->status, $return_to ); ?>
            </div>

            <div class="rwexec-detail-card">
            <table class="form-table rwexec-detail-table" role="presentation">
                <tr><th>Customer Name</th><td><?php echo esc_html( $reservation->customer_name ); ?><?php if ( ! empty( $reservation->customer_id ) ) : $customer_url = $frontend ? add_query_arg( array( 'rwexec_action'=>'customer', 'customer_id'=>$reservation->customer_id ), $base_url ) : add_query_arg( array( 'page'=>'rwexec-reservations-customer', 'customer_id'=>$reservation->customer_id ), admin_url('admin.php') ); ?><br><a href="<?php echo esc_url( $customer_url ); ?>">View customer history</a><?php endif; ?></td></tr>
                <tr><th>Email</th><td><?php echo esc_html( $reservation->customer_email ?: 'No email provided' ); ?></td></tr>
                <tr><th>Phone</th><td><?php echo esc_html( $reservation->customer_phone ?: 'No telephone number provided' ); ?></td></tr>
                <tr><th>Reservation Date</th><td><?php echo esc_html( RWExec_Reservations_Service::format_date( (string) $reservation->reservation_date ) ); ?></td></tr>
                <tr><th>Start Time</th><td><?php echo esc_html( substr( $reservation->start_time, 0, 5 ) ); ?></td></tr>
                <tr><th>End Time</th><td><?php echo esc_html( substr( $reservation->end_time, 0, 5 ) ); ?></td></tr>
                <tr><th>Guests</th><td><?php echo esc_html( $reservation->guest_count ); ?></td></tr>
                <tr><th>Table</th><td><?php echo ! empty( $reservation->table_reference ) ? esc_html( $reservation->table_reference ) : 'Not assigned'; ?></td></tr>
                <tr><th>Status</th><td><?php echo esc_html( RWExec_Reservations_Service::get_status_label( $reservation->status ) ); ?></td></tr>
                <?php if ( ! empty( $reservation->arrived_at ) ) : ?><tr><th>Checked In At</th><td><?php echo esc_html( $reservation->arrived_at ); ?></td></tr><?php endif; ?>
                <?php if ( ! empty( $reservation->completed_at ) ) : ?><tr><th>Completed At</th><td><?php echo esc_html( $reservation->completed_at ); ?><?php if ( isset( $reservation->completion_source ) && 'automatic' === $reservation->completion_source ) : ?><br><span class="rwexec-auto-completed-note"><strong>Completed automatically</strong> by the system after the configured grace period.</span><?php endif; ?></td></tr><?php endif; ?>
                <?php if ( ! empty( $reservation->cancelled_at ) ) : ?><tr><th>Cancelled At</th><td><?php echo esc_html( $reservation->cancelled_at ); ?></td></tr><?php endif; ?>
                <?php if ( ! empty( $reservation->no_show_at ) ) : ?><tr><th>No Show Marked At</th><td><?php echo esc_html( $reservation->no_show_at ); ?></td></tr><?php endif; ?>
                <tr><th>Allergies</th><td><?php echo $reservation->allergies ? nl2br( esc_html( $reservation->allergies ) ) : 'None recorded'; ?></td></tr>
                <tr id="additional-information"><th>Additional Information</th><td><?php echo $reservation->additional_information ? nl2br( esc_html( $reservation->additional_information ) ) : 'None'; ?></td></tr>
                <?php foreach ( RWExec_Reservations_Form_Builder::decode_responses( $reservation ) as $custom_entry ) : if ( empty( $custom_entry['show_admin'] ) ) { continue; } ?>
                    <tr><th><?php echo esc_html( $custom_entry['label'] ?? 'Custom field' ); ?></th><td><?php echo nl2br( esc_html( (string) ( $custom_entry['value'] ?? '' ) ) ); ?><?php if ( ! empty( $custom_entry['consent_at'] ) ) : ?><br><small>Consent recorded: <?php echo esc_html( $custom_entry['consent_at'] ); ?></small><?php endif; ?></td></tr>
                <?php endforeach; ?>
                <tr><th>Booking Source</th><td><?php echo ! empty( $reservation->is_historic ) ? 'Historic import' : esc_html( ucfirst( $reservation->source ) ); ?></td></tr>
                <?php if ( ! empty( $reservation->is_historic ) ) : ?><tr><th>Historic Record</th><td>Yes — customer booking emails are suppressed for this reservation.</td></tr><?php endif; ?>
                <?php if ( ! empty( $reservation->override_used ) ) : ?>
                    <tr><th>Manual Override</th><td><strong>Yes</strong><br>Reason: <?php echo esc_html( str_replace( 'rwexec_override_', '', $reservation->override_reason ) ); ?><?php
                        if ( $reservation->override_by ) {
                            $user = get_user_by( 'id', $reservation->override_by );
                            if ( $user ) { echo '<br>Override by: ' . esc_html( $user->display_name ); }
                        }
                        if ( $reservation->override_at ) { echo '<br>Override at: ' . esc_html( $reservation->override_at ); }
                    ?></td></tr>
                <?php endif; ?>
            </table>
            </div>

            <?php if ( RWExec_Reservations_Staff::can_admin() ) : ?>
            <div class="rwexec-danger-zone">
            <h2>Permanent Delete</h2>
            <p>Use only for test bookings or records created by mistake. Normal cancellations should use the status control above.</p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Permanently delete this reservation? This cannot be undone.');">
                <input type="hidden" name="action" value="rwexec_delete_reservation">
                <?php if ( $frontend ) : ?><input type="hidden" name="rwexec_frontend_base" value="<?php echo esc_url( $base_url ); ?>"><?php endif; ?>
                <input type="hidden" name="reservation_id" value="<?php echo esc_attr( $reservation->id ); ?>">
                <?php wp_nonce_field( 'rwexec_delete_reservation', 'rwexec_delete_nonce' ); ?>
                <button type="submit" class="button rwexec-danger">Delete Reservation Permanently</button>
            </form>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function statuses(): array {
        return array(
            'confirmed' => 'Confirmed',
            'checked_in' => 'Checked In',
            'completed' => 'Completed',
            'cancelled' => 'Cancelled',
            'no_show' => 'No Show',
        );
    }

    private static function status_form( int $id, string $status, string $label, string $class, string $return_to ) {
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="rwexec_set_reservation_status">
            <input type="hidden" name="reservation_id" value="<?php echo esc_attr( $id ); ?>">
            <input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>">
            <input type="hidden" name="return_to" value="<?php echo esc_url( $return_to ); ?>">
            <?php wp_nonce_field( 'rwexec_set_reservation_status', 'rwexec_status_nonce' ); ?>
            <button type="submit" class="button <?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
        </form>
        <?php
    }

    private static function status_dropdown( int $id, string $current_status, string $return_to ) {
        ?>
        <form class="rwexec-quick-status-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="rwexec_set_reservation_status">
            <input type="hidden" name="reservation_id" value="<?php echo esc_attr( $id ); ?>">
            <input type="hidden" name="return_to" value="<?php echo esc_url( $return_to ); ?>">
            <?php wp_nonce_field( 'rwexec_set_reservation_status', 'rwexec_status_nonce' ); ?>
            <label for="rwexec-detail-status"><strong>Status:</strong></label>
            <select id="rwexec-detail-status" name="status" onchange="this.form.submit()">
                <?php foreach ( self::statuses() as $key => $label ) : ?>
                    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current_status, $key ); ?>><?php echo esc_html( $label ); ?></option>
                <?php endforeach; ?>
            </select>
            <noscript><button type="submit" class="button">Update Status</button></noscript>
        </form>
        <?php
    }
}
