(function () {
    'use strict';

    function initBooking(root) {
        const form = root.querySelector('[data-rwexec-form]');
        if (!form || typeof RWExecReservations === 'undefined') return;

        const dateInput = form.querySelector('[data-rwexec-date-input]');
        const guests = form.querySelector('[name="guest_count"]');
        const timeSelect = form.querySelector('[data-rwexec-time-select]');
        const timesMessage = form.querySelector('[data-rwexec-times-message]');
        const submit = form.querySelector('[data-rwexec-submit]');
        const notice = root.querySelector('[data-rwexec-notice]');
        let minDate = root.dataset.minDate || '';
        let maxDate = root.dataset.maxDate || '';
        let requestId = 0;
        let dateTouched = false;

        function showNotice(message, type) {
            notice.textContent = message;
            notice.className = 'rwexec-booking__notice rwexec-booking__notice--' + type;
            notice.hidden = false;
            notice.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        function clearNotice() {
            notice.hidden = true;
            notice.textContent = '';
        }

        function clearTimes(message) {
            timeSelect.innerHTML = '';
            const option = document.createElement('option');
            option.value = '';
            option.textContent = message || RWExecReservations.messages.chooseTime;
            timeSelect.appendChild(option);
            timeSelect.disabled = true;
            timesMessage.textContent = '';
        }

        function renderTimes(items) {
            timeSelect.innerHTML = '';
            const placeholder = document.createElement('option');
            placeholder.value = '';
            placeholder.textContent = RWExecReservations.messages.chooseTime;
            timeSelect.appendChild(placeholder);

            if (!items || !items.length) {
                timeSelect.disabled = true;
                timesMessage.textContent = RWExecReservations.messages.noTimes;
                return;
            }

            items.forEach(function (item) {
                const option = document.createElement('option');
                option.value = item.value;
                option.textContent = item.label;
                timeSelect.appendChild(option);
            });
            timeSelect.disabled = false;
            timesMessage.textContent = RWExecReservations.messages.limitedTimes || '';
        }

        async function refreshTimes() {
            clearNotice();
            if (!dateInput.value || !guests.value) {
                clearTimes(RWExecReservations.messages.chooseTime);
                return;
            }

            const thisRequest = ++requestId;
            clearTimes(RWExecReservations.messages.loading);

            const body = new URLSearchParams({
                action: 'rwexec_get_booking_times',
                nonce: RWExecReservations.nonce,
                reservation_date: dateInput.value,
                guest_count: guests.value
            });

            try {
                const response = await fetch(RWExecReservations.ajaxUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString(),
                    credentials: 'same-origin'
                });
                const payload = await response.json();
                if (thisRequest !== requestId) return;

                if (!payload.success) {
                    clearTimes('No available times');
                    timesMessage.textContent = payload.data && payload.data.message ? payload.data.message : RWExecReservations.messages.noTimes;
                    return;
                }

                renderTimes(payload.data.times);
            } catch (error) {
                if (thisRequest === requestId) {
                    clearTimes('Unable to load times');
                    timesMessage.textContent = RWExecReservations.messages.error;
                }
            }
        }

        dateInput.addEventListener('change', function () {
            dateTouched = true;
            refreshTimes();
        });
        guests.addEventListener('change', refreshTimes);

        form.querySelectorAll('[data-rwexec-allergies]').forEach(function (container) {
            const details = container.querySelector('[data-rwexec-allergy-details]');
            const textarea = details ? details.querySelector('textarea[name="allergies"]') : null;
            container.querySelectorAll('input[name="rwexec_has_allergies"]').forEach(function (radio) {
                radio.addEventListener('change', function () {
                    const hasAllergies = radio.checked && radio.value === '1';
                    if (details) details.hidden = !hasAllergies;
                    if (textarea) {
                        textarea.required = hasAllergies;
                        if (!hasAllergies) textarea.value = '';
                    }
                });
            });
        });

        async function refreshBookingBootstrap() {
            const body = new URLSearchParams({ action: 'rwexec_booking_bootstrap' });

            try {
                const response = await fetch(RWExecReservations.ajaxUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString(),
                    credentials: 'same-origin',
                    cache: 'no-store'
                });
                const payload = await response.json();
                if (!payload.success || !payload.data) return;

                const freshToday = payload.data.today || '';
                const freshMaxDate = payload.data.maxDate || '';

                if (payload.data.nonce) {
                    RWExecReservations.nonce = payload.data.nonce;
                }

                if (freshToday) {
                    minDate = freshToday;
                    root.dataset.minDate = freshToday;
                    dateInput.min = freshToday;

                    if (!dateTouched || !dateInput.value || dateInput.value < freshToday) {
                        dateInput.value = freshToday;
                    }
                }

                if (freshMaxDate) {
                    maxDate = freshMaxDate;
                    root.dataset.maxDate = freshMaxDate;
                    dateInput.max = freshMaxDate;
                }
            } catch (error) {
                // Keep the server-rendered values as a fallback if the live bootstrap request fails.
            }
        }

        form.addEventListener('submit', async function (event) {
            event.preventDefault();
            clearNotice();

            if (!dateInput.value) {
                showNotice('Please choose a reservation date.', 'error');
                return;
            }
            if (!form.reportValidity()) return;

            submit.disabled = true;
            const originalText = submit.textContent;
            submit.textContent = 'Confirming…';

            const data = new FormData(form);
            data.append('action', 'rwexec_create_public_reservation');
            data.append('nonce', RWExecReservations.nonce);
            const body = new URLSearchParams();
            data.forEach(function (value, key) { body.append(key, value); });

            try {
                const response = await fetch(RWExecReservations.ajaxUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString(),
                    credentials: 'same-origin'
                });
                const payload = await response.json();

                if (!payload.success) {
                    showNotice(payload.data && payload.data.message ? payload.data.message : RWExecReservations.messages.error, 'error');
                    if (response.status === 409) {
                        refreshTimes();
                    }
                    return;
                }

                form.reset();
                dateInput.value = minDate || '';
                form.querySelectorAll('[data-rwexec-allergy-details]').forEach(function (details) {
                    details.hidden = true;
                    const textarea = details.querySelector('textarea[name="allergies"]');
                    if (textarea) textarea.required = false;
                });
                clearTimes(RWExecReservations.messages.chooseTime);
                showNotice(payload.data.message || 'Your reservation is confirmed.', 'success');
            } catch (error) {
                showNotice(RWExecReservations.messages.error, 'error');
            } finally {
                submit.disabled = false;
                submit.textContent = originalText;
            }
        });

        if (!dateInput.value && minDate) dateInput.value = minDate;
        clearTimes(RWExecReservations.messages.chooseTime);
        refreshBookingBootstrap();
    }

    function initAllBookings() {
        document.querySelectorAll('[data-rwexec-booking]').forEach(function (root) {
            if (root.dataset.rwexecInitialized === '1') return;
            root.dataset.rwexecInitialized = '1';
            initBooking(root);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAllBookings);
    } else {
        initAllBookings();
    }

    const observer = new MutationObserver(initAllBookings);
    if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
    } else {
        document.addEventListener('DOMContentLoaded', function () {
            observer.observe(document.body, { childList: true, subtree: true });
        });
    }
}());
