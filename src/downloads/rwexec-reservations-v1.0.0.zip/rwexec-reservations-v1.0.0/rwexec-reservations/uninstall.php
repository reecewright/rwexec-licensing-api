<?php

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/*
 * RWExec Reservations keeps all reservation/customer/settings data by default.
 * Data is only removed when an administrator explicitly enables:
 * Settings -> General -> Plugin Data on Uninstall.
 */
if ( '1' !== (string) get_option( 'rwexec_delete_data_on_uninstall', '0' ) ) {
    return;
}

global $wpdb;

// Stop scheduled automation.
wp_clear_scheduled_hook( 'rwexec_reservations_process_automatic_no_shows' );

// Remove plugin tables.
$tables = array(
    $wpdb->prefix . 'rwexec_reservations',
    $wpdb->prefix . 'rwexec_reservation_special_dates',
    $wpdb->prefix . 'rwexec_reservation_customers',
);

foreach ( $tables as $table ) {
    $wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

// Remove all plugin options, including temporary lock options.
$option_like = $wpdb->esc_like( 'rwexec_' ) . '%';
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
        $option_like
    )
);

// Remove RWExec transients that WordPress stores as options.
foreach ( array( '_transient_rwexec_', '_transient_timeout_rwexec_', '_site_transient_rwexec_', '_site_transient_timeout_rwexec_' ) as $prefix ) {
    $like = $wpdb->esc_like( $prefix ) . '%';
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
            $like
        )
    );
}

// Remove plugin-created roles and capabilities.
remove_role( 'rwexec_reservations_staff' );
remove_role( 'rwexec_reservations_admin' );

$administrator = get_role( 'administrator' );
if ( $administrator ) {
    $administrator->remove_cap( 'rwexec_manage_reservations' );
    $administrator->remove_cap( 'rwexec_admin_reservations' );
}
