# RWExec Reservations pre-release checklist

## Fresh install
- Activate on a clean WordPress site.
- Confirm automatic redirect to the setup wizard.
- Complete all five setup steps.
- Confirm the wizard is not visible in the Reservations sidebar menu.
- Confirm Settings > General shows the rerun button.
- Add `[rwexec_reservations]` and make a test booking.

## Upgrade
- Upgrade over an existing installation.
- Confirm reservations, customers, settings, email templates and special dates remain intact.
- Confirm the setup wizard does not automatically interrupt an existing configured installation.

## Roles
- Reservations Staff: front-end day-to-day access only.
- Reservations Admin: settings/export/delete access.
- WordPress Administrator: full access.

## Booking/capacity
- Test overlapping reservations at capacity boundaries.
- Test closed, walk-ins-only and special dates.
- Test public minimum notice and advance-booking window.
- Test simultaneous booking attempts if possible.

## Email
- Configure authenticated SMTP or transactional delivery.
- Confirm From Email is appropriate for the sending domain.
- Test confirmation, update, cancellation, reminder, feedback and restaurant notifications.
- Check inbox and spam placement.

## Responsive UI
- Desktop reservation list and settings.
- iPad/tablet staff list with no horizontal scrolling.
- iPhone/mobile booking form and staff cards.
- Native mobile date input alignment.

## Data retention
- Verify deactivation preserves data.
- Verify delete preserves data with cleanup disabled.
- On a disposable test site only, verify cleanup removes RWExec data when explicitly enabled.

## Release status
- Production licence service configured.
- Secure licence activation, validation and deactivation included.
- Core reservation functionality remains available regardless of temporary licence-service availability.
- Automatic update delivery and expanded translation packaging can be added in future releases.
