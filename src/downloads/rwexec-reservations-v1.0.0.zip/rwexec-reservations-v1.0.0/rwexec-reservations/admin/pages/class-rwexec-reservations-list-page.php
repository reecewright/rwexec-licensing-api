<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_List_Page {

    public static function render( $context = array() ) {
        $context = is_array( $context ) ? $context : array();
        global $wpdb;
        RWExec_Reservations_Automation::run();
        $frontend = ! empty( $context['frontend'] );
        $base_url = $frontend ? esc_url_raw( $context['base_url'] ?? '' ) : admin_url( 'admin.php' );

        $table = $wpdb->prefix . 'rwexec_reservations';
        $search = sanitize_text_field( wp_unslash( $_GET['rwexec_search'] ?? ( $frontend ? '' : ( $_GET['s'] ?? '' ) ) ) );
        $status = sanitize_key( wp_unslash( $_GET['status'] ?? '' ) );
        $date_start = sanitize_text_field( wp_unslash( $_GET['reservation_date_start'] ?? ( $_GET['reservation_date'] ?? '' ) ) );
        $date_end = sanitize_text_field( wp_unslash( $_GET['reservation_date_end'] ?? '' ) );
        $sort = sanitize_key( wp_unslash( $_GET['sort'] ?? 'asc' ) );
        $sort = 'desc' === $sort ? 'desc' : 'asc';
        $per_page = 25;
        $current_page = max( 1, absint( $_GET['reservation_page'] ?? 1 ) );

        $where = array( '1=1' );
        $params = array();
        $using_history_filter = (bool) ( $search || $date_start );

        if ( $search ) {
            $like = '%' . $wpdb->esc_like( $search ) . '%';
            $where[] = '(customer_name LIKE %s OR customer_email LIKE %s OR customer_phone LIKE %s)';
            array_push( $params, $like, $like, $like );
        }
        if ( $status ) {
            $where[] = 'status = %s';
            $params[] = $status;
        }
        if ( $date_start ) {
            if ( $date_end ) {
                $where[] = 'reservation_date BETWEEN %s AND %s';
                $params[] = $date_start;
                $params[] = $date_end;
            } else {
                $where[] = 'reservation_date = %s';
                $params[] = $date_start;
            }
        }

        // Keep the day-to-day list focused on active/upcoming reservations.
        // Historical reservations remain available through Search or explicit date filters.
        if ( ! $using_history_filter ) {
            $today = RWExec_Reservations_Service::restaurant_now()->format( 'Y-m-d' );
            $where[] = 'reservation_date >= %s';
            $params[] = $today;
        }

        $where_sql = implode( ' AND ', $where );
        $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
        if ( $params ) {
            $count_sql = $wpdb->prepare( $count_sql, $params );
        }
        $total_items = (int) $wpdb->get_var( $count_sql );
        $total_pages = max( 1, (int) ceil( $total_items / $per_page ) );
        if ( $current_page > $total_pages ) {
            $current_page = $total_pages;
        }
        $offset = ( $current_page - 1 ) * $per_page;

        $order = 'desc' === $sort ? 'DESC' : 'ASC';
        $sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY reservation_date {$order}, start_time {$order} LIMIT %d OFFSET %d";
        $query_params = array_merge( $params, array( $per_page, $offset ) );
        $sql = $wpdb->prepare( $sql, $query_params );
        $reservations = $wpdb->get_results( $sql ) ?: array();

        $return_args=array();
        if(!$frontend){$return_args['page']='rwexec-reservations';}
        if($search){$return_args['rwexec_search']=$search;} if($status){$return_args['status']=$status;} if($date_start){$return_args['reservation_date_start']=$date_start;}
        if($date_end){$return_args['reservation_date_end']=$date_end;}
        $return_args['sort']=$sort;
        if($current_page>1){$return_args['reservation_page']=$current_page;}
        $return_to=add_query_arg($return_args,$base_url);
        $list_url=$frontend?$base_url:admin_url('admin.php?page=rwexec-reservations');
        $add_url=$frontend?add_query_arg('rwexec_action','add',$base_url):admin_url('admin.php?page=rwexec-reservations-add');
        ?>
        <div class="<?php echo $frontend ? 'rwexec-admin rwexec-staff-frontend' : 'wrap rwexec-admin'; ?>">
            <div class="rwexec-page-header"><div><h1>Reservations</h1><p class="rwexec-page-subtitle">Manage bookings, check guests in and update reservation status.</p></div><div class="rwexec-header-actions"><?php if($frontend):?><a href="<?php echo esc_url(add_query_arg('rwexec_action','customers',$base_url)); ?>" class="button">Customers</a><?php endif;?><a href="<?php echo esc_url($add_url); ?>" class="button button-primary rwexec-primary-action">Add Reservation</a></div></div>
            <?php if(isset($_GET['created'])):?><div class="notice notice-success"><p>Reservation created successfully.</p></div><?php endif;?>
            <?php if(isset($_GET['deleted'])):?><div class="notice notice-success"><p>Reservation deleted.</p></div><?php endif;?>
            <?php if(isset($_GET['status_updated'])):?><div class="notice notice-success"><p>Reservation status updated.</p></div><?php endif;?>
            <?php if(isset($_GET['table_updated'])):?><div class="notice notice-success"><p>Table assignment saved.</p></div><?php endif;?>
            <?php if(isset($_GET['action_error'])):?><div class="notice notice-error"><p><?php echo esc_html(rawurldecode(wp_unslash($_GET['action_error']))); ?></p></div><?php endif;?>

            <?php $filters_active = (bool) ( $search || $status || $date_start || $date_end || 'desc' === $sort ); ?>
            <div class="rwexec-filter-panel<?php echo $filters_active ? ' is-open' : ''; ?>" data-rwexec-filter-panel>
                <div class="rwexec-filter-panel__header">
                    <button type="button" class="rwexec-filter-toggle" data-rwexec-filter-toggle aria-expanded="<?php echo $filters_active ? 'true' : 'false'; ?>">
                        <span>Filters</span><span class="rwexec-filter-toggle__arrow" aria-hidden="true">▶️</span>
                    </button>
                </div>
                <form method="get" action="<?php echo esc_url($list_url); ?>" class="rwexec-filter-row" data-rwexec-filter-content>
                    <?php if(!$frontend):?><input type="hidden" name="page" value="rwexec-reservations"><?php endif;?>
                    <label class="rwexec-filter-search">Search<input type="search" name="rwexec_search" value="<?php echo esc_attr($search); ?>" placeholder="Name, email or phone"></label>
                    <label class="rwexec-filter-control rwexec-filter-status">Status<select name="status"><option value="">All statuses</option><?php foreach(self::statuses() as $key=>$label):?><option value="<?php echo esc_attr($key); ?>" <?php selected($status,$key); ?>><?php echo esc_html($label); ?></option><?php endforeach;?></select></label>
                    <label class="rwexec-filter-control rwexec-filter-order">Order<select name="sort"><option value="asc" <?php selected($sort,'asc'); ?>>Earliest first</option><option value="desc" <?php selected($sort,'desc'); ?>>Latest first</option></select></label>
                    <label class="rwexec-filter-control rwexec-filter-start-date">Start Date<input type="date" name="reservation_date_start" value="<?php echo esc_attr($date_start); ?>"></label>
                    <label class="rwexec-filter-control rwexec-filter-end-date">End Date<input type="date" name="reservation_date_end" value="<?php echo esc_attr($date_end); ?>"></label>
                    <div class="rwexec-filter-actions">
                        <a class="button rwexec-button-danger-outline" href="<?php echo esc_url($list_url); ?>">Clear Filters</a>
                        <a class="button" href="<?php echo esc_url(add_query_arg('reservation_date_start',RWExec_Reservations_Service::restaurant_now()->modify('-1 day')->format('Y-m-d'),$list_url)); ?>">Yesterday</a>
                        <a class="button" href="<?php echo esc_url(add_query_arg('reservation_date_start',RWExec_Reservations_Service::restaurant_now()->format('Y-m-d'),$list_url)); ?>">Today</a>
                        <button class="button button-primary" type="submit">Apply Filters</button>
                    </div>
                </form>
            </div>
            <script>
            (function(){
                function initReservationFilters(){
                    var panel=document.querySelector('[data-rwexec-filter-panel]');
                    if(!panel){return;}
                    var toggle=panel.querySelector('[data-rwexec-filter-toggle]');
                    var content=panel.querySelector('[data-rwexec-filter-content]');
                    if(!toggle||!content){return;}
                    var arrow=toggle.querySelector('.rwexec-filter-toggle__arrow');
                    var active=<?php echo $filters_active ? 'true' : 'false'; ?>;
                    var stored=null;
                    try{stored=window.localStorage.getItem('rwexecReservationsFiltersOpen');}catch(e){}
                    var open=active ? true : stored==='1';
                    function render(){
                        panel.classList.toggle('is-open',open);
                        toggle.setAttribute('aria-expanded',open?'true':'false');
                        if(arrow){arrow.textContent=open?'🔽':'▶️';}
                    }
                    render();
                    toggle.addEventListener('click',function(){
                        open=!open;
                        render();
                        try{window.localStorage.setItem('rwexecReservationsFiltersOpen',open?'1':'0');}catch(e){}
                    });
                }
                if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',initReservationFilters);}else{initReservationFilters();}
            })();
            </script>
            <script>
            (function(){
                function updateLateIndicators(){
                    var now=Math.floor(Date.now()/1000);
                    document.querySelectorAll('.rwexec-status-indicator[data-rwexec-booking-timestamp]').forEach(function(indicator){
                        var status=indicator.getAttribute('data-rwexec-status')||'';
                        var booking=parseInt(indicator.getAttribute('data-rwexec-booking-timestamp')||'0',10);
                        var grace=parseInt(indicator.getAttribute('data-rwexec-late-grace')||'15',10);

                        if(status!=='confirmed'||!booking){ return; }

                        var secondsLate=now-(booking+(grace*60));
                        if(secondsLate>0){
                            var minutesSinceBooking=Math.max(1,Math.floor((now-booking)/60));
                            indicator.className='rwexec-status-indicator rwexec-status-indicator--late';
                            indicator.title='Late by '+minutesSinceBooking+' minutes';
                            var sr=indicator.querySelector('.screen-reader-text');
                            if(sr){ sr.textContent=indicator.title; }
                        }
                    });
                }

                if(document.readyState==='loading'){
                    document.addEventListener('DOMContentLoaded',updateLateIndicators);
                }else{
                    updateLateIndicators();
                }
                window.setInterval(updateLateIndicators,30000);
            })();
            </script>

            <?php if(empty($reservations)):?><div class="rwexec-empty-state"><span class="dashicons dashicons-calendar-alt"></span><h2>No reservations found</h2><p>Try changing the filters or add a new reservation.</p></div><?php else:?><div class="rwexec-table-card"><table class="widefat fixed rwexec-reservations-table"><colgroup><col class="rwexec-w-name"><col class="rwexec-w-date"><col class="rwexec-w-start"><col class="rwexec-w-end"><col class="rwexec-w-guests"><col class="rwexec-w-phone"><col class="rwexec-w-info"><col class="rwexec-w-table"><col class="rwexec-w-indicator"><col class="rwexec-w-status"><col class="rwexec-w-checkin"></colgroup><thead><tr><th class="rwexec-cell-name">Name</th><th class="rwexec-cell-date">Date</th><th class="rwexec-cell-start">Start</th><th class="rwexec-cell-end">End</th><th class="rwexec-cell-guests">Guests</th><th class="rwexec-cell-phone">Phone</th><th class="rwexec-cell-info">Info</th><th class="rwexec-cell-table">Table</th><th class="rwexec-col-indicator">Indicator</th><th class="rwexec-cell-status">Status</th><th class="rwexec-checkin-cell">Check In</th></tr></thead><tbody>
            <?php foreach($reservations as $reservation):$late=RWExec_Reservations_Service::get_late_minutes($reservation);$details_url=$frontend?add_query_arg(array('rwexec_action'=>'view','reservation_id'=>$reservation->id),$base_url):add_query_arg(array('page'=>'rwexec-reservation-details','reservation_id'=>$reservation->id),admin_url('admin.php'));$edit_url=$frontend?add_query_arg(array('rwexec_action'=>'edit','reservation_id'=>$reservation->id),$base_url):add_query_arg(array('page'=>'rwexec-reservation-edit','reservation_id'=>$reservation->id),admin_url('admin.php'));$customer_record=(RWExec_Reservations_License::is_premium()&&!empty($reservation->customer_id))?RWExec_Reservations_Customers::get((int)$reservation->customer_id):null;$has_customer_notes=$customer_record&&(!empty(trim((string)$customer_record->staff_notes))||!empty(trim((string)$customer_record->preferences)));$customer_notes_url='';if($customer_record){$customer_notes_url=$frontend?add_query_arg(array('rwexec_action'=>'customer','customer_id'=>$reservation->customer_id),$base_url):add_query_arg(array('page'=>'rwexec-reservations-customer','customer_id'=>$reservation->customer_id),admin_url('admin.php'));$customer_notes_url.='#staff-notes-preferences';}$is_today=(string)$reservation->reservation_date===RWExec_Reservations_Service::restaurant_now()->format('Y-m-d');$indicator_class=$late>0?'late':$reservation->status;$indicator_title=$late>0?sprintf('Late by %d minutes',$late):RWExec_Reservations_Service::get_status_label($reservation->status);$booking_datetime=DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$reservation->reservation_date.' '.$reservation->start_time,RWExec_Reservations_Service::restaurant_timezone());$booking_timestamp=$booking_datetime?$booking_datetime->getTimestamp():0;$late_grace=absint(get_option('rwexec_late_grace_minutes',15));?>
                <tr><td class="rwexec-cell-name"><a href="<?php echo esc_url($details_url); ?>"><strong><?php echo esc_html($reservation->customer_name); ?></strong></a><div class="row-actions"><span><a href="<?php echo esc_url($details_url); ?>"><span class="rwexec-action-desktop">View Booking</span><span class="rwexec-action-tablet">View</span></a> | </span><span><a href="<?php echo esc_url($edit_url); ?>"><span class="rwexec-action-desktop">Edit Booking</span><span class="rwexec-action-tablet">Edit</span></a></span></div></td><td class="rwexec-cell-date"><span class="rwexec-date-desktop"><?php echo esc_html(RWExec_Reservations_Service::format_date((string)$reservation->reservation_date)); ?></span><span class="rwexec-date-tablet"><?php echo esc_html(date_i18n('d.m.y',strtotime((string)$reservation->reservation_date))); ?></span></td><td class="rwexec-cell-start"><?php echo esc_html(substr($reservation->start_time,0,5)); ?></td><td class="rwexec-cell-end"><?php echo esc_html(substr($reservation->end_time,0,5)); ?></td><td class="rwexec-cell-guests"><?php echo esc_html($reservation->guest_count); ?></td><td class="rwexec-cell-phone"><?php echo esc_html($reservation->customer_phone ?: '—'); ?></td><td class="rwexec-cell-info"><span class="rwexec-info-icons"><?php if(!empty(trim((string)$reservation->allergies))):?><a class="rwexec-info-icon rwexec-info-icon--allergy" href="<?php echo esc_url($details_url . '#allergy-information'); ?>" title="Allergy information"><span class="dashicons dashicons-warning" aria-hidden="true"></span><span class="screen-reader-text">Allergy information</span></a><?php endif;?><?php if($has_customer_notes&&$customer_notes_url):?><a class="rwexec-info-icon rwexec-info-icon--notes" href="<?php echo esc_url($customer_notes_url); ?>" title="Customer notes"><span class="dashicons dashicons-media-document" aria-hidden="true"></span><span class="screen-reader-text">Customer notes</span></a><?php endif;?><?php if(empty(trim((string)$reservation->allergies))&&!$has_customer_notes):?><span class="rwexec-info-empty" aria-hidden="true">—</span><?php endif;?></span></td><td class="rwexec-cell-table"><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="rwexec-table-assignment-form"><input type="hidden" name="action" value="rwexec_set_table_reference"><input type="hidden" name="reservation_id" value="<?php echo esc_attr($reservation->id); ?>"><input type="hidden" name="return_to" value="<?php echo esc_url($return_to); ?>"><?php wp_nonce_field('rwexec_set_table_reference_'.$reservation->id,'rwexec_table_nonce'); ?><label class="screen-reader-text" for="rwexec-table-<?php echo esc_attr($reservation->id); ?>">Table for <?php echo esc_html($reservation->customer_name); ?></label><input id="rwexec-table-<?php echo esc_attr($reservation->id); ?>" class="rwexec-table-input" type="text" name="table_reference" maxlength="50" value="<?php echo esc_attr($reservation->table_reference ?? ''); ?>" placeholder="—" title="Table allocation, e.g. 21 or 21-24. Press Enter or click away to save."></form></td><td class="rwexec-col-indicator"><span class="rwexec-status-indicator rwexec-status-indicator--<?php echo esc_attr($indicator_class); ?>" title="<?php echo esc_attr($indicator_title); ?>" data-rwexec-status="<?php echo esc_attr($reservation->status); ?>" data-rwexec-booking-timestamp="<?php echo esc_attr($booking_timestamp); ?>" data-rwexec-late-grace="<?php echo esc_attr($late_grace); ?>"><span class="screen-reader-text"><?php echo esc_html($indicator_title); ?></span></span></td><td class="rwexec-cell-status"><?php self::status_dropdown($reservation->id,$reservation->status,$return_to); ?></td><td class="rwexec-checkin-cell"><?php if('confirmed'===$reservation->status):if($is_today):self::quick_status_button($reservation->id,'checked_in','Check In',$return_to,'button-primary');else:?><button type="button" class="button" disabled title="Check In is available on the reservation date">Check In</button><?php endif;else:?><span aria-hidden="true">—</span><?php endif;?></td></tr>
            <?php endforeach;?></tbody></table></div>
            <?php
            $first_item = $total_items ? ( ( $current_page - 1 ) * $per_page ) + 1 : 0;
            $last_item = min( $current_page * $per_page, $total_items );
            $pagination_args = $return_args;
            unset( $pagination_args['reservation_page'] );
            $pagination_base = add_query_arg( $pagination_args, $base_url );

            // Build pagination links directly. paginate_links() returns HTML-escaped
            // query separators, which can be escaped a second time by the front-end
            // rendering path and turn "&reservation_page=2" into "#038;reservation_page=2".
            // Once that happens reservation_page is a URL fragment, not a GET parameter.
            $pagination_pages = array();
            if ( $total_pages > 1 ) {
                $candidates = array( 1, $total_pages, $current_page - 1, $current_page, $current_page + 1 );
                foreach ( $candidates as $candidate ) {
                    if ( $candidate >= 1 && $candidate <= $total_pages ) {
                        $pagination_pages[] = (int) $candidate;
                    }
                }
                $pagination_pages = array_values( array_unique( $pagination_pages ) );
                sort( $pagination_pages, SORT_NUMERIC );
            }
            ?>
            <div class="rwexec-list-footer">
                <p class="rwexec-pagination-summary">Showing <?php echo esc_html( $first_item ); ?>–<?php echo esc_html( $last_item ); ?> of <?php echo esc_html( $total_items ); ?> reservations</p>
                <?php if ( $total_pages > 1 ) : ?>
                    <nav class="rwexec-pagination" aria-label="Reservations pagination">
                        <ul class="page-numbers">
                            <?php if ( $current_page > 1 ) : ?>
                                <li><a class="prev page-numbers" href="<?php echo esc_url( add_query_arg( 'reservation_page', $current_page - 1, $pagination_base ) ); ?>">&lsaquo;</a></li>
                            <?php endif; ?>
                            <?php $previous_page = 0; foreach ( $pagination_pages as $page_number ) : ?>
                                <?php if ( $previous_page && $page_number > $previous_page + 1 ) : ?>
                                    <li><span class="page-numbers dots">&hellip;</span></li>
                                <?php endif; ?>
                                <?php if ( $page_number === $current_page ) : ?>
                                    <li><span aria-current="page" class="page-numbers current"><?php echo esc_html( $page_number ); ?></span></li>
                                <?php else : ?>
                                    <li><a class="page-numbers" href="<?php echo esc_url( add_query_arg( 'reservation_page', $page_number, $pagination_base ) ); ?>"><?php echo esc_html( $page_number ); ?></a></li>
                                <?php endif; ?>
                                <?php $previous_page = $page_number; ?>
                            <?php endforeach; ?>
                            <?php if ( $current_page < $total_pages ) : ?>
                                <li><a class="next page-numbers" href="<?php echo esc_url( add_query_arg( 'reservation_page', $current_page + 1, $pagination_base ) ); ?>">&rsaquo;</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
            <?php if ( ! $using_history_filter ) : ?><p class="rwexec-history-note">Past bookings are hidden from the default view. Use Search or the date filters to find previous reservations.</p><?php endif; ?>
            <?php endif;?>
            <?php if ( $frontend ) { echo RWExec_Reservations_Staff::logout_section(); } ?>
            <script>document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.rwexec-table-input').forEach(function(input){var initial=input.value;function save(){if(input.value!==initial){initial=input.value;input.form.submit();}}input.addEventListener('change',save);input.addEventListener('keydown',function(event){if(event.key==='Enter'){event.preventDefault();save();}});});});</script>
        </div><?php
    }

    private static function statuses(): array {
        return array(
            'confirmed' => 'Confirmed',
            'checked_in' => 'Checked In',
            'completed' => 'Completed',
            'cancelled' => 'Cancelled',
            'no_show' => 'No Show',
        );
    }

    private static function quick_status_button( int $id, string $status, string $label, string $return_to, string $class = '' ) {
        ?>
        <form class="rwexec-quick-action-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="rwexec_set_reservation_status">
            <input type="hidden" name="reservation_id" value="<?php echo esc_attr( $id ); ?>">
            <input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>">
            <input type="hidden" name="return_to" value="<?php echo esc_url( $return_to ); ?>">
            <?php wp_nonce_field( 'rwexec_set_reservation_status', 'rwexec_status_nonce' ); ?>
            <button type="submit" class="button <?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
        </form>
        <?php
    }

    private static function status_dropdown( int $id, string $current_status, string $return_to ) {
        ?>
        <form class="rwexec-quick-status-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="rwexec_set_reservation_status">
            <input type="hidden" name="reservation_id" value="<?php echo esc_attr( $id ); ?>">
            <input type="hidden" name="return_to" value="<?php echo esc_url( $return_to ); ?>">
            <?php wp_nonce_field( 'rwexec_set_reservation_status', 'rwexec_status_nonce' ); ?>
            <label class="screen-reader-text" for="rwexec-status-<?php echo esc_attr( $id ); ?>">Change reservation status</label>
            <select id="rwexec-status-<?php echo esc_attr( $id ); ?>" name="status" onchange="this.form.submit()">
                <?php foreach ( self::statuses() as $key => $label ) : ?>
                    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current_status, $key ); ?>><?php echo esc_html( $label ); ?></option>
                <?php endforeach; ?>
            </select>
            <noscript><button type="submit" class="button">Update</button></noscript>
        </form>
        <?php
    }
}
