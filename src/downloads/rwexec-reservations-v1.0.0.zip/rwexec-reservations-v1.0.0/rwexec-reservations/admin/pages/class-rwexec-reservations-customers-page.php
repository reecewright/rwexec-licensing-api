<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Customers_Page {
    public static function render( $context = array() ) {
        $context = is_array( $context ) ? $context : array();
        if ( ! RWExec_Reservations_Staff::can_manage() ) { return; }
        global $wpdb;
        $frontend = ! empty( $context['frontend'] );
        $base_url = $frontend ? esc_url_raw( $context['base_url'] ?? home_url('/') ) : admin_url( 'admin.php?page=rwexec-reservations-customers' );
        if ( ! RWExec_Reservations_License::is_premium() ) {
            ?>
            <div class="<?php echo $frontend ? 'rwexec-admin rwexec-staff-frontend' : 'wrap rwexec-admin'; ?>">
                <div class="rwexec-page-header"><div><h1>Customers <?php echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></h1><p class="rwexec-page-subtitle">Returning customer records, attendance history, staff notes and marketing preferences.</p></div><a class="button" href="<?php echo esc_url( $frontend ? $base_url : admin_url('admin.php?page=rwexec-reservations') ); ?>">Reservations</a></div>
                <div class="rwexec-premium-gate"><div class="rwexec-premium-gate__icon"><?php echo wp_kses_post( RWExec_Reservations_License::premium_icon() ); ?></div><div><h3>Customer management is a Premium feature</h3><p>Upgrade to view returning-customer history, staff notes, preferences, marketing consent and contact exports. Reservation data is retained safely if Premium is inactive.</p><?php if ( ! $frontend ) : ?><?php echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?><?php endif; ?></div></div>
            </div>
            <?php
            return;
        }
        $search = sanitize_text_field( wp_unslash( $_GET['customer_search'] ?? '' ) );
        $marketing = sanitize_key( wp_unslash( $_GET['marketing'] ?? '' ) );
        $where = '1=1'; $params = array();
        if ( $search ) { $like = '%' . $wpdb->esc_like( $search ) . '%'; $where .= ' AND (customer_name LIKE %s OR customer_email LIKE %s OR customer_phone LIKE %s)'; $params = array($like,$like,$like); }
        if ( 'consented' === $marketing ) { $where .= ' AND c.marketing_email_consent = 1'; } elseif ( 'not_consented' === $marketing ) { $where .= ' AND c.marketing_email_consent = 0'; }
        $sql = 'SELECT c.*, COUNT(r.id) reservation_count, MAX(r.reservation_date) last_booking FROM ' . RWExec_Reservations_Customers::table() . ' c LEFT JOIN ' . $wpdb->prefix . 'rwexec_reservations r ON r.customer_id=c.id WHERE ' . $where . ' GROUP BY c.id ORDER BY COALESCE(MAX(r.reservation_date), c.last_seen_at) DESC, c.customer_name ASC LIMIT 200';
        if ( $params ) { $sql = $wpdb->prepare( $sql, $params ); }
        $customers = $wpdb->get_results( $sql ) ?: array();
        ?>
        <div class="<?php echo $frontend ? 'rwexec-admin rwexec-staff-frontend' : 'wrap rwexec-admin'; ?>">
            <div class="rwexec-page-header"><div><h1>Customers</h1><p class="rwexec-page-subtitle">Returning customer records, attendance history, staff notes and marketing preferences.</p></div><div class="rwexec-header-actions"><?php if(RWExec_Reservations_Staff::can_admin()):$export=wp_nonce_url(admin_url('admin-post.php?action=rwexec_export_marketing_contacts'),'rwexec_export_marketing_contacts');?><a class="button" href="<?php echo esc_url($export); ?>">Export Marketing Contacts</a><?php endif;?><a class="button" href="<?php echo esc_url( $frontend ? $base_url : admin_url('admin.php?page=rwexec-reservations') ); ?>">Reservations</a></div></div>
            <form method="get" action="<?php echo esc_url($base_url); ?>" class="rwexec-filter-row rwexec-customer-filter"><?php if(!$frontend):?><input type="hidden" name="page" value="rwexec-reservations-customers"><?php else:?><input type="hidden" name="rwexec_action" value="customers"><?php endif;?><label class="rwexec-filter-search">Search customers<input type="search" name="customer_search" value="<?php echo esc_attr($search); ?>" placeholder="Name, email or phone"></label><label>Marketing<select name="marketing"><option value="">All customers</option><option value="consented" <?php selected($marketing,'consented'); ?>>Email consent</option><option value="not_consented" <?php selected($marketing,'not_consented'); ?>>No email consent</option></select></label><button class="button button-primary" type="submit">Apply</button><a class="button" href="<?php echo esc_url($frontend?add_query_arg('rwexec_action','customers',$base_url):$base_url); ?>">Clear</a></form>
            <div class="rwexec-table-card"><table class="widefat striped rwexec-customers-table"><thead><tr><th>Customer</th><th>Email</th><th>Phone</th><th>Bookings</th><th>Marketing</th><th>Last Booking</th></tr></thead><tbody>
            <?php if(!$customers):?><tr><td colspan="6">No customer records found.</td></tr><?php endif; foreach($customers as $c): $url=$frontend?add_query_arg(array('rwexec_action'=>'customer','customer_id'=>$c->id),$base_url):add_query_arg(array('page'=>'rwexec-reservations-customer','customer_id'=>$c->id),admin_url('admin.php'));?><tr><td><a href="<?php echo esc_url($url); ?>"><strong><?php echo esc_html($c->customer_name); ?></strong></a></td><td><?php echo esc_html($c->customer_email ?: 'No email provided'); ?></td><td><?php echo esc_html($c->customer_phone ?: 'No telephone number provided'); ?></td><td><?php echo esc_html($c->reservation_count); ?></td><td><?php echo !empty($c->marketing_email_consent)?'<span class="rwexec-badge rwexec-badge--success">Email consent</span>':'—'; ?></td><td><?php echo esc_html($c->last_booking?RWExec_Reservations_Service::format_date($c->last_booking):'—'); ?></td></tr><?php endforeach; ?>
            </tbody></table></div>
        </div><?php
    }
}
