<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservation_Add_Page {

    public static function render( $context = array() ) {
        $context = is_array( $context ) ? $context : array();
        $frontend = ! empty( $context['frontend'] );
        $base_url = $frontend ? esc_url_raw( $context['base_url'] ?? '' ) : '';
        $state_token = sanitize_key( wp_unslash( $_GET['form_state'] ?? '' ) );
        $form_state = RWExec_Reservations_Actions::consume_form_state( $state_token );
        $source = ! empty( $form_state ) ? $form_state : $_GET;
        $values = array(
            'customer_name' => sanitize_text_field( wp_unslash( $source['customer_name'] ?? '' ) ),
            'customer_email' => sanitize_email( wp_unslash( $source['customer_email'] ?? '' ) ),
            'customer_phone' => sanitize_text_field( wp_unslash( $source['customer_phone'] ?? '' ) ),
            'no_customer_email' => ! empty( $source['no_customer_email'] ) ? 1 : 0,
            'no_customer_phone' => ! empty( $source['no_customer_phone'] ) ? 1 : 0,
            'is_historic' => ! empty( $source['is_historic'] ) ? 1 : 0,
            'reservation_date' => sanitize_text_field( wp_unslash( $source['reservation_date'] ?? '' ) ),
            'start_time' => sanitize_text_field( wp_unslash( $source['start_time'] ?? '' ) ),
            'guest_count' => absint( $source['guest_count'] ?? 0 ),
            'table_reference' => sanitize_text_field( wp_unslash( $source['table_reference'] ?? '' ) ),
            'allergies' => sanitize_textarea_field( wp_unslash( $source['allergies'] ?? '' ) ),
            'additional_information' => sanitize_textarea_field( wp_unslash( $source['additional_information'] ?? '' ) ),
            'marketing_email_consent' => ! empty( $source['marketing_email_consent'] ) ? 1 : 0,
        );

        $error_message = sanitize_text_field( wp_unslash( $source['reservation_message'] ?? '' ) );
        $weekly_hours = RWExec_Reservations_Settings::get_weekly_hours();
        $special_dates = array();
        foreach ( RWExec_Reservations_Special_Dates::get_all() as $item ) {
            $special_dates[ $item->special_date ] = array(
                'status' => $item->booking_status,
                'start' => $item->booking_start ? substr( $item->booking_start, 0, 5 ) : '',
                'end' => $item->booking_end ? substr( $item->booking_end, 0, 5 ) : '',
                'label' => $item->label ?: '',
            );
        }
        $booking_interval = absint( get_option( 'rwexec_booking_interval', 15 ) );
        $customer_lookup = RWExec_Reservations_Customers::manual_lookup();
        ?>
        <div class="<?php echo $frontend ? 'rwexec-admin rwexec-staff-frontend' : 'wrap rwexec-admin'; ?>">
            <div class="rwexec-page-header">
                <div><h1>Add Reservation</h1><p class="rwexec-page-subtitle">Create a booking manually for a phone, walk-in or staff reservation.</p></div>
                <div class="rwexec-page-header__actions">
                    <label class="rwexec-historic-header-toggle" title="Add a previous reservation to customer history. Historic bookings are saved as Completed and no booking emails are sent.">
                        <input type="checkbox" id="is_historic" name="is_historic" value="1" form="rwexec-add-reservation-form" <?php checked( $values['is_historic'], 1 ); ?>>
                        <span>Historic booking</span>
                    </label>
                    <a class="button" href="<?php echo esc_url( $frontend ? $base_url : admin_url( 'admin.php?page=rwexec-reservations' ) ); ?>">← Reservations</a>
                </div>
            </div>
            <?php if ( $error_message ) : ?><div class="notice notice-error"><p><?php echo esc_html( $error_message ); ?></p></div><?php endif; ?>

            <form id="rwexec-add-reservation-form" class="rwexec-admin-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="rwexec_create_reservation">
                <?php if ( $frontend ) : ?><input type="hidden" name="rwexec_frontend_base" value="<?php echo esc_url( $base_url ); ?>"><?php endif; ?>
                <?php wp_nonce_field( 'rwexec_create_reservation', 'rwexec_reservation_nonce' ); ?>
                <div class="rwexec-customer-lookup">
                    <label for="rwexec-returning-customer"><strong>Returning Customer</strong></label>
                    <div class="rwexec-customer-lookup__control">
                        <input type="search" id="rwexec-returning-customer" autocomplete="off" placeholder="Search name, email or phone">
                        <div id="rwexec-customer-lookup-results" class="rwexec-customer-lookup__results" hidden></div>
                    </div>
                    <p id="rwexec-customer-lookup-message" class="description">Optional — select an existing customer to fill their contact details automatically.</p>
                </div>
                <table class="form-table" role="presentation">
                    <tr><th><label for="customer_name">Customer Name</label></th><td><input class="regular-text" type="text" id="customer_name" name="customer_name" value="<?php echo esc_attr( $values['customer_name'] ); ?>" required></td></tr>
                    <tr><th><label for="customer_email">Email</label></th><td><input class="regular-text" type="email" id="customer_email" name="customer_email" value="<?php echo esc_attr( $values['customer_email'] ); ?>" <?php echo $values['no_customer_email'] ? 'disabled' : 'required'; ?>><p><label class="rwexec-contact-unavailable"><input type="checkbox" id="no_customer_email" name="no_customer_email" value="1" <?php checked( $values['no_customer_email'], 1 ); ?>> No email address provided</label></p></td></tr>
                    <tr><th><label for="customer_phone">Phone</label></th><td><input class="regular-text" type="tel" id="customer_phone" name="customer_phone" value="<?php echo esc_attr( $values['customer_phone'] ); ?>" <?php echo $values['no_customer_phone'] ? 'disabled' : 'required'; ?>><p><label class="rwexec-contact-unavailable"><input type="checkbox" id="no_customer_phone" name="no_customer_phone" value="1" <?php checked( $values['no_customer_phone'], 1 ); ?>> No telephone number provided</label></p></td></tr>
                    <tr><th><label for="reservation_date">Reservation Date</label></th><td><input type="date" id="reservation_date" name="reservation_date" value="<?php echo esc_attr( $values['reservation_date'] ); ?>" required></td></tr>
                    <tr><th><label for="start_time">Start Time</label></th><td>
                        <select id="start_time" name="start_time" data-selected-time="<?php echo esc_attr( $values['start_time'] ); ?>" required><option value="">Select a date first</option></select>
                        <p id="booking_status_message" class="description" style="display:none;font-weight:600"></p>
                        <p class="description">Available times use the weekly schedule and any special-date override.</p>
                    </td></tr>
                    <tr><th><label for="guest_count">Number of Guests</label></th><td><input type="number" id="guest_count" name="guest_count" min="1" step="1" value="<?php echo esc_attr( $values['guest_count'] ?: '' ); ?>" required></td></tr>
                    <tr><th><label for="table_reference">Table</label></th><td><input type="text" id="table_reference" name="table_reference" maxlength="50" value="<?php echo esc_attr( $values['table_reference'] ); ?>" placeholder="e.g. 21 or 21-24"><p class="description">Optional internal table allocation.</p></td></tr>
                    <tr><th><label for="allergies">Any Allergies?</label></th><td><textarea id="allergies" name="allergies" rows="3" class="large-text"><?php echo esc_textarea( $values['allergies'] ); ?></textarea></td></tr>
                    <tr><th><label for="additional_information">Additional Information</label></th><td><textarea id="additional_information" name="additional_information" rows="4" class="large-text"><?php echo esc_textarea( $values['additional_information'] ); ?></textarea></td></tr>
                    <?php $marketing_label = (string) get_option( 'rwexec_marketing_consent_label', 'Keep me updated' ); $marketing_text = str_replace( '{restaurant_name}', (string) get_option( 'rwexec_email_restaurant_name', get_bloginfo( 'name' ) ), (string) get_option( 'rwexec_marketing_consent_text', 'I’d like to receive occasional news, offers and updates from {restaurant_name} by email.' ) ); ?>
                    <tr><th>Marketing Preferences</th><td><label class="rwexec-admin-consent"><input type="checkbox" name="marketing_email_consent" value="1" <?php checked( $values['marketing_email_consent'], 1 ); ?>> <strong><?php echo esc_html( $marketing_label ); ?></strong></label><p class="description"><?php echo esc_html( $marketing_text ); ?></p><p class="description"><strong>Leave unchecked unless the customer has explicitly agreed.</strong> The exact wording, time and manual-booking source are recorded when selected.</p></td></tr>
                </table>
                <?php submit_button( 'Create Reservation' ); ?>
            </form>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function(){
            const lookupInput=document.getElementById('rwexec-returning-customer');
            const lookupResults=document.getElementById('rwexec-customer-lookup-results');
            const lookupMessage=document.getElementById('rwexec-customer-lookup-message');
            const customers=<?php echo wp_json_encode( $customer_lookup ); ?>;
            const nameInput=document.getElementById('customer_name');
            const emailInput=document.getElementById('customer_email');
            const phoneInput=document.getElementById('customer_phone');
            const noEmailInput=document.getElementById('no_customer_email');
            const noPhoneInput=document.getElementById('no_customer_phone');
            const marketingInput=document.querySelector('input[name="marketing_email_consent"]');
            const historicInput=document.getElementById('is_historic');
            function syncContactField(field,checkbox){
                field.disabled=checkbox.checked;field.required=!checkbox.checked;
                if(checkbox.checked)field.value='';
            }
            function syncMarketing(){if(marketingInput){marketingInput.disabled=noEmailInput.checked;if(noEmailInput.checked)marketingInput.checked=false}}
            noEmailInput.addEventListener('change',function(){syncContactField(emailInput,noEmailInput);syncMarketing()});
            noPhoneInput.addEventListener('change',function(){syncContactField(phoneInput,noPhoneInput)});
            function customerHaystack(customer){return [customer.name,customer.email,customer.phone].join(' ').toLowerCase()}
            function closeCustomerResults(){lookupResults.hidden=true;lookupResults.innerHTML=''}
            function selectCustomer(customer){
                nameInput.value=customer.name||'';emailInput.value=customer.email||'';phoneInput.value=customer.phone||'';
                noEmailInput.checked=!customer.email;noPhoneInput.checked=!customer.phone;
                syncContactField(emailInput,noEmailInput);syncContactField(phoneInput,noPhoneInput);syncMarketing();
                lookupInput.value=customer.name||customer.email||customer.phone||'';
                lookupMessage.textContent='Existing customer selected'+(customer.has_notes?' — this customer has staff notes/preferences on their customer record.':'.');
                closeCustomerResults();nameInput.focus();
            }
            function renderCustomerResults(){
                const query=(lookupInput.value||'').trim().toLowerCase();
                lookupResults.innerHTML='';
                if(query.length<2){closeCustomerResults();return}
                const matches=customers.filter(customer=>customerHaystack(customer).includes(query)).slice(0,8);
                if(!matches.length){const empty=document.createElement('div');empty.className='rwexec-customer-lookup__empty';empty.textContent='No existing customers found';lookupResults.appendChild(empty);lookupResults.hidden=false;return}
                matches.forEach(customer=>{const button=document.createElement('button');button.type='button';button.className='rwexec-customer-lookup__result';const title=document.createElement('strong');title.textContent=customer.name||'Unnamed customer';const detail=document.createElement('span');detail.textContent=[customer.email,customer.phone].filter(Boolean).join(' · ');button.appendChild(title);button.appendChild(detail);button.addEventListener('click',()=>selectCustomer(customer));lookupResults.appendChild(button)});
                lookupResults.hidden=false;
            }
            syncContactField(emailInput,noEmailInput);syncContactField(phoneInput,noPhoneInput);syncMarketing();
            lookupInput.addEventListener('input',renderCustomerResults);
            lookupInput.addEventListener('keydown',function(event){if(event.key==='Escape')closeCustomerResults()});
            document.addEventListener('click',function(event){if(!event.target.closest('.rwexec-customer-lookup'))closeCustomerResults()});

            const dateInput=document.getElementById('reservation_date');
            const timeSelect=document.getElementById('start_time');
            const message=document.getElementById('booking_status_message');
            const weekly=<?php echo wp_json_encode( $weekly_hours ); ?>;
            const specials=<?php echo wp_json_encode( $special_dates ); ?>;
            const interval=<?php echo (int) $booking_interval; ?>;
            const selected=timeSelect.dataset.selectedTime||'';
            const dayNames=['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
            function mins(t){const p=t.split(':');return parseInt(p[0],10)*60+parseInt(p[1],10)}
            function fmt(m){const h=Math.floor(m/60),mi=m%60,v=String(h).padStart(2,'0')+':'+String(mi).padStart(2,'0'),s=h>=12?'pm':'am',dh=(h%12)||12;return {value:v,label:dh+':'+String(mi).padStart(2,'0')+' '+s}}
            function option(text,value=''){const o=document.createElement('option');o.textContent=text;o.value=value;timeSelect.appendChild(o);return o}
            function refresh(){
                timeSelect.innerHTML='';message.style.display='none';message.textContent='';
                if(!dateInput.value){option('Select a date first');return}
                if(historicInput&&historicInput.checked){
                    option('Select a time');
                    for(let m=0;m<24*60;m+=interval){const t=fmt(m),o=option(t.label,t.value);if(t.value===selected)o.selected=true}
                    message.textContent='Historic booking: availability and capacity checks are skipped, and no booking emails will be sent.';message.style.display='block';return
                }
                const d=new Date(dateInput.value+'T12:00:00');
                const rule=specials[dateInput.value]||weekly[dayNames[d.getDay()]];
                if(!rule){option('No booking times available');return}
                const suffix=rule.label?' ('+rule.label+')':'';
                if(rule.status==='closed'){option('No booking times available');message.textContent='The venue is closed on this date'+suffix+'.';message.style.display='block';return}
                if(rule.status==='walk_ins_only'){option('Reservations unavailable');message.textContent='Reservations are unavailable on this date'+suffix+'. Walk-ins are welcome.';message.style.display='block';return}
                if(!rule.start||!rule.end){option('No booking times available');return}
                option('Select a time');
                for(let m=mins(rule.start),end=mins(rule.end);m<=end;m+=interval){const t=fmt(m),o=option(t.label,t.value);if(t.value===selected)o.selected=true}
            }
            dateInput.addEventListener('change',refresh);if(historicInput)historicInput.addEventListener('change',refresh);refresh();
        });
        </script>
        <?php
    }
}
