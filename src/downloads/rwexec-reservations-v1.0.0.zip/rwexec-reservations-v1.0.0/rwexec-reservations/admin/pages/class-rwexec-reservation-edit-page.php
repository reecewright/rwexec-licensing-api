<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservation_Edit_Page {

    public static function render( $context = array() ) {
        $context = is_array( $context ) ? $context : array();
        $frontend = ! empty( $context['frontend'] );
        $base_url = $frontend ? esc_url_raw( $context['base_url'] ?? '' ) : '';
        $reservation_id = absint( $_GET['reservation_id'] ?? 0 );
        $reservation = RWExec_Reservations_Service::get_reservation( $reservation_id );
        if ( ! $reservation ) { wp_die( 'Reservation not found.' ); }

        $state_token = sanitize_key( wp_unslash( $_GET['form_state'] ?? '' ) );
        $form_state = RWExec_Reservations_Actions::consume_form_state( $state_token );
        $source = ! empty( $form_state ) ? $form_state : $_GET;
        $override_required = sanitize_key( wp_unslash( $source['override_required'] ?? '' ) );
        $override_message = sanitize_text_field( wp_unslash( $source['override_message'] ?? '' ) );
        $error_message = sanitize_text_field( wp_unslash( $source['reservation_message'] ?? '' ) );
        $field = function( string $key, $fallback, string $type = 'text' ) use ( $source ) {
            if ( ! isset( $source[ $key ] ) ) { return $fallback; }
            $value = wp_unslash( $source[ $key ] );
            if ( 'email' === $type ) { return sanitize_email( $value ); }
            if ( 'int' === $type ) { return absint( $value ); }
            if ( 'textarea' === $type ) { return sanitize_textarea_field( $value ); }
            return sanitize_text_field( $value );
        };
        $no_customer_email = isset( $source['no_customer_email'] ) ? ! empty( $source['no_customer_email'] ) : empty( $reservation->customer_email );
        $no_customer_phone = isset( $source['no_customer_phone'] ) ? ! empty( $source['no_customer_phone'] ) : empty( $reservation->customer_phone );
        ?>
        <div class="<?php echo $frontend ? 'rwexec-admin rwexec-staff-frontend' : 'wrap rwexec-admin'; ?>">
            <div class="rwexec-page-header">
                <div><h1>Edit Reservation</h1><p class="rwexec-page-subtitle">Update customer details, time or party size.</p></div>
                <a class="button" href="<?php echo esc_url( $frontend ? add_query_arg( array( 'rwexec_action'=>'view','reservation_id'=>$reservation->id ), $base_url ) : add_query_arg( array( 'page'=>'rwexec-reservation-details','reservation_id'=>$reservation->id ), admin_url( 'admin.php' ) ) ); ?>">← Back to Reservation</a>
            </div>

            <?php if ( $error_message ) : ?><div class="notice notice-error"><p><?php echo esc_html( $error_message ); ?></p></div><?php endif; ?>

            <?php if ( $override_required ) : ?>
                <div class="notice notice-warning"><p><strong>Manual override required</strong></p><p><?php echo esc_html( $override_message ); ?></p><p>Saving this exact version of the reservation will override the normal booking settings.</p></div>
            <?php endif; ?>

            <form class="rwexec-admin-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="rwexec_update_reservation">
                <?php if ( $frontend ) : ?><input type="hidden" name="rwexec_frontend_base" value="<?php echo esc_url( $base_url ); ?>"><?php endif; ?>
                <input type="hidden" name="reservation_id" value="<?php echo esc_attr( $reservation->id ); ?>">
                <input type="hidden" name="override_reason" value="<?php echo esc_attr( $override_required ); ?>">
                <?php wp_nonce_field( 'rwexec_update_reservation', 'rwexec_update_reservation_nonce' ); ?>
                <?php if ( $override_required ) : ?>
                    <input type="hidden" name="allow_override" value="1">
                    <input type="hidden" name="override_signature" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $source['override_signature'] ?? '' ) ) ); ?>">
                <?php endif; ?>

                <table class="form-table" role="presentation">
                    <tr><th><label for="customer_name">Customer Name</label></th><td><input class="regular-text" type="text" id="customer_name" name="customer_name" value="<?php echo esc_attr( $field( 'customer_name', $reservation->customer_name ) ); ?>" required></td></tr>
                    <tr><th><label for="customer_email">Email</label></th><td><input class="regular-text" type="email" id="customer_email" name="customer_email" value="<?php echo esc_attr( $field( 'customer_email', $reservation->customer_email, 'email' ) ); ?>" <?php echo $no_customer_email ? 'disabled' : 'required'; ?>><p><label class="rwexec-contact-unavailable"><input type="checkbox" id="no_customer_email" name="no_customer_email" value="1" <?php checked( $no_customer_email ); ?>> No email address provided</label></p></td></tr>
                    <tr><th><label for="customer_phone">Phone</label></th><td><input class="regular-text" type="tel" id="customer_phone" name="customer_phone" value="<?php echo esc_attr( $field( 'customer_phone', $reservation->customer_phone ) ); ?>" <?php echo $no_customer_phone ? 'disabled' : 'required'; ?>><p><label class="rwexec-contact-unavailable"><input type="checkbox" id="no_customer_phone" name="no_customer_phone" value="1" <?php checked( $no_customer_phone ); ?>> No telephone number provided</label></p></td></tr>
                    <tr><th><label for="reservation_date">Reservation Date</label></th><td><input type="date" id="reservation_date" name="reservation_date" value="<?php echo esc_attr( $field( 'reservation_date', $reservation->reservation_date ) ); ?>" required></td></tr>
                    <tr><th><label for="start_time">Start Time</label></th><td><input type="time" id="start_time" name="start_time" value="<?php echo esc_attr( $field( 'start_time', substr( $reservation->start_time, 0, 5 ) ) ); ?>" required><p class="description">End time is recalculated automatically. Admin edits may be overridden after a warning.</p></td></tr>
                    <tr><th><label for="guest_count">Number of Guests</label></th><td><input type="number" id="guest_count" name="guest_count" min="1" step="1" value="<?php echo esc_attr( $field( 'guest_count', $reservation->guest_count, 'int' ) ); ?>" required></td></tr>
                    <tr><th><label for="table_reference">Table</label></th><td><input type="text" id="table_reference" name="table_reference" maxlength="50" value="<?php echo esc_attr( $field( 'table_reference', $reservation->table_reference ?? '' ) ); ?>" placeholder="e.g. 21 or 21-24"><p class="description">Optional internal table allocation.</p></td></tr>
                    <tr><th><label for="allergies">Any Allergies?</label></th><td><textarea id="allergies" name="allergies" rows="3" class="large-text"><?php echo esc_textarea( $field( 'allergies', $reservation->allergies, 'textarea' ) ); ?></textarea></td></tr>
                    <tr><th><label for="additional_information">Additional Information</label></th><td><textarea id="additional_information" name="additional_information" rows="4" class="large-text"><?php echo esc_textarea( $field( 'additional_information', $reservation->additional_information, 'textarea' ) ); ?></textarea></td></tr>
                </table>
                <?php submit_button( $override_required ? 'Save Anyway' : 'Save Changes' ); ?>
            </form>
        </div>
        <script>
        document.addEventListener('DOMContentLoaded', function(){
            const email=document.getElementById('customer_email');
            const phone=document.getElementById('customer_phone');
            const noEmail=document.getElementById('no_customer_email');
            const noPhone=document.getElementById('no_customer_phone');
            function sync(field,checkbox){field.disabled=checkbox.checked;field.required=!checkbox.checked;if(checkbox.checked)field.value=''}
            noEmail.addEventListener('change',function(){sync(email,noEmail)});
            noPhone.addEventListener('change',function(){sync(phone,noPhone)});
            sync(email,noEmail);sync(phone,noPhone);
        });
        </script>
        <?php
    }
}
