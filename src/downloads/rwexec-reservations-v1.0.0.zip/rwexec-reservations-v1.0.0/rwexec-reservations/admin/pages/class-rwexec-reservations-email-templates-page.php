<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Email_Templates_Page {

    public static function render( bool $embedded = false ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $types = RWExec_Reservations_Email::template_types();
        $active = sanitize_key( wp_unslash( $_GET['template'] ?? 'confirmation' ) );
        if ( ! isset( $types[ $active ] ) ) {
            $active = 'confirmation';
        }

        $test_sent = isset( $_GET['test_sent'] );
        $test_failed = isset( $_GET['test_failed'] );
        $premium = RWExec_Reservations_License::is_premium();
        ?>
        <?php if ( ! $embedded ) : ?><div class="wrap rwexec-email-templates"><?php else : ?><div class="rwexec-email-templates"><?php endif; ?>
            <h2>Email Templates <?php if ( ! $premium ) echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></h2>
            <p>Configure each email without writing HTML. Choose the booking details to show, edit the message and optional button, then preview the complete branded email.</p>

            <?php if ( ! $premium ) : ?>
                <div class="rwexec-premium-gate">
                    <div class="rwexec-premium-gate__icon"><?php echo wp_kses_post( RWExec_Reservations_License::premium_icon() ); ?></div>
                    <div><h3>Premium email customisation</h3><p>The Free edition still sends the built-in confirmation, cancellation and 12-hour reminder emails. Premium unlocks editable subjects, headings, content, reservation-detail fields, buttons and branded templates.</p><?php echo wp_kses_post( RWExec_Reservations_License::premium_badge() ); ?></div>
                </div>
                <?php if ( ! $embedded ) : ?></div><?php else : ?></div><?php endif; ?>
                <?php return; ?>
            <?php endif; ?>

            <?php if ( $test_sent ) : ?>
                <div class="notice notice-success is-dismissible"><p>Test email sent.</p></div>
            <?php elseif ( $test_failed ) : ?>
                <div class="notice notice-error is-dismissible"><p>The test email could not be sent. Check the recipient address and WordPress mail/SMTP configuration.</p></div>
            <?php endif; ?>

            <nav class="nav-tab-wrapper" style="margin-bottom:20px">
                <?php foreach ( $types as $key => $config ) :
                    $url = add_query_arg(
                        $embedded
                            ? array( 'page' => 'rwexec-reservations-settings', 'tab' => 'email-templates', 'template' => $key )
                            : array( 'page' => 'rwexec-reservations-emails', 'template' => $key ),
                        admin_url( 'admin.php' )
                    );
                    ?>
                    <a class="nav-tab <?php echo $active === $key ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $config['label'] ); ?></a>
                <?php endforeach; ?>
            </nav>

            <form method="post" action="options.php">
                <?php settings_fields( 'rwexec_reservations_email_template_' . $active ); ?>
                <input type="hidden" name="rwexec_email_templates_last_tab" value="<?php echo esc_attr( $active ); ?>">

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Enabled</th>
                        <td>
                            <input type="hidden" name="<?php echo esc_attr( 'rwexec_email_' . $active . '_enabled' ); ?>" value="0">
                            <label><input type="checkbox" name="<?php echo esc_attr( 'rwexec_email_' . $active . '_enabled' ); ?>" value="1" <?php checked( get_option( 'rwexec_email_' . $active . '_enabled', '1' ), '1' ); ?>> Send this email automatically</label>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="rwexec_email_template_<?php echo esc_attr( $active ); ?>_subject">Subject</label></th>
                        <td><input type="text" class="large-text" id="rwexec_email_template_<?php echo esc_attr( $active ); ?>_subject" name="rwexec_email_template_<?php echo esc_attr( $active ); ?>_subject" value="<?php echo esc_attr( RWExec_Reservations_Email::template_value( $active, 'subject' ) ); ?>"></td>
                    </tr>
                    <tr>
                        <th><label for="rwexec_email_template_<?php echo esc_attr( $active ); ?>_heading">Email Heading</label></th>
                        <td><input type="text" class="large-text" id="rwexec_email_template_<?php echo esc_attr( $active ); ?>_heading" name="rwexec_email_template_<?php echo esc_attr( $active ); ?>_heading" value="<?php echo esc_attr( RWExec_Reservations_Email::template_value( $active, 'heading' ) ); ?>"></td>
                    </tr>
                    <tr>
                        <th>Reservation Details</th>
                        <td>
                            <p class="description" style="margin-top:0">Choose which fields appear inside the styled Reservation Details box for this email.</p>
                            <input type="hidden" name="<?php echo esc_attr( 'rwexec_email_template_' . $active . '_detail_fields[]' ); ?>" value="">
                            <div class="rwexec-email-field-grid">
                                <?php $selected_fields = RWExec_Reservations_Email::template_detail_fields( $active ); foreach ( RWExec_Reservations_Email::detail_field_choices() as $field_key => $field_label ) : ?>
                                    <label><input type="checkbox" name="<?php echo esc_attr( 'rwexec_email_template_' . $active . '_detail_fields[]' ); ?>" value="<?php echo esc_attr( $field_key ); ?>" <?php checked( in_array( $field_key, $selected_fields, true ) ); ?>> <?php echo esc_html( $field_label ); ?></label>
                                <?php endforeach; ?>
                            </div>
                            <p class="description">The details box is inserted wherever <code>{reservation_details}</code> appears in the email body.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Email Body</th>
                        <td>
                            <?php
                            wp_editor(
                                RWExec_Reservations_Email::template_value( $active, 'body' ),
                                'rwexec_email_body_' . $active,
                                array(
                                    'textarea_name' => 'rwexec_email_template_' . $active . '_body',
                                    'textarea_rows' => 14,
                                    'media_buttons' => false,
                                    'teeny' => false,
                                )
                            );
                            ?>
                            <p class="description">Use the placeholders below to insert live booking information.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="rwexec_email_template_<?php echo esc_attr( $active ); ?>_button_text">Button Text</label></th>
                        <td><input type="text" class="regular-text" id="rwexec_email_template_<?php echo esc_attr( $active ); ?>_button_text" name="rwexec_email_template_<?php echo esc_attr( $active ); ?>_button_text" value="<?php echo esc_attr( RWExec_Reservations_Email::template_value( $active, 'button_text' ) ); ?>"><p class="description">Optional. Leave blank for no button.</p></td>
                    </tr>
                    <tr>
                        <th><label for="rwexec_email_template_<?php echo esc_attr( $active ); ?>_button_url">Button URL</label></th>
                        <td><input type="text" class="large-text" id="rwexec_email_template_<?php echo esc_attr( $active ); ?>_button_url" name="rwexec_email_template_<?php echo esc_attr( $active ); ?>_button_url" value="<?php echo esc_attr( RWExec_Reservations_Email::template_value( $active, 'button_url' ) ); ?>"><p class="description">Can be a normal URL or a placeholder such as <code>{feedback_url}</code>.</p></td>
                    </tr>
                </table>

                <div class="rwexec-email-placeholders">
                    <h2>Available Placeholders</h2>
                    <p>
                        <?php foreach ( RWExec_Reservations_Email::placeholders() as $placeholder ) : ?>
                            <code style="display:inline-block;margin:0 6px 7px 0"><?php echo esc_html( $placeholder ); ?></code>
                        <?php endforeach; ?>
                    </p>
                </div>

                <?php submit_button( 'Save Email Template' ); ?>
            </form>

            <hr style="margin:28px 0">
            <h2>Preview & Test</h2>
            <p>Preview renders the complete saved email using sample booking data, including logo, heading, selected reservation details, button and footer. Save changes before previewing or testing.</p>
            <?php
            $preview_url = wp_nonce_url(
                add_query_arg(
                    array( 'action' => 'rwexec_preview_email', 'type' => $active ),
                    admin_url( 'admin-post.php' )
                ),
                'rwexec_preview_email_' . $active
            );
            $test_url = wp_nonce_url(
                add_query_arg(
                    array( 'action' => 'rwexec_test_email', 'type' => $active ),
                    admin_url( 'admin-post.php' )
                ),
                'rwexec_test_email_' . $active
            );
            ?>
            <p>
                <a class="button" href="<?php echo esc_url( $preview_url ); ?>" target="_blank" rel="noopener">Preview Email</a>
                <a class="button button-secondary" href="<?php echo esc_url( $test_url ); ?>">Send Test Email</a>
            </p>
            <p class="description">Test recipient: <strong><?php echo esc_html( get_option( 'rwexec_email_test_recipient', get_option( 'admin_email' ) ) ); ?></strong>. Change this under Settings → Email Settings.</p>
        </div>
        <?php
    }
}
