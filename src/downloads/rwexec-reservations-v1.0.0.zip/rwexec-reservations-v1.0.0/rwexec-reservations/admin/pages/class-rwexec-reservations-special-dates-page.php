<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Special_Dates_Page {

    public static function render( bool $embedded = false ) {
        $dates = RWExec_Reservations_Special_Dates::get_all();
        if ( ! $embedded ) : ?>
            <div class="wrap rwexec-admin">
        <?php endif; ?>

        <h2>Special Dates</h2>
        <p>Override the normal weekly schedule for bank holidays, Christmas, private events or one-off opening hours.</p>

        <?php if ( isset( $_GET['special_saved'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Special date saved.</p></div><?php endif; ?>
        <?php if ( isset( $_GET['special_deleted'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Special date deleted.</p></div><?php endif; ?>
        <?php if ( isset( $_GET['special_error'] ) ) : ?><div class="notice notice-error"><p><?php echo esc_html( rawurldecode( wp_unslash( $_GET['special_error'] ) ) ); ?></p></div><?php endif; ?>

        <form class="rwexec-special-date-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="rwexec_save_special_date">
            <?php wp_nonce_field( 'rwexec_save_special_date', 'rwexec_special_date_nonce' ); ?>
            <div class="row">
                <label>Date<input type="date" name="special_date" required></label>
                <label>Status
                    <select name="booking_status" id="rwexec-special-status">
                        <option value="closed">Closed</option>
                        <option value="walk_ins_only">Walk-ins only</option>
                        <option value="open">Open for bookings</option>
                    </select>
                </label>
                <label>Label<input type="text" name="label" placeholder="e.g. Christmas Day"></label>
            </div>
            <div class="row" id="rwexec-special-hours">
                <label>First booking<input type="time" name="booking_start" value="12:00"></label>
                <label>Last booking<input type="time" name="booking_end" value="22:00"></label>
            </div>
            <button type="submit" class="button button-primary">Save Special Date</button>
        </form>

        <script>
        document.addEventListener('DOMContentLoaded', function(){
            const status=document.getElementById('rwexec-special-status');
            const hours=document.getElementById('rwexec-special-hours');
            if(!status||!hours)return;
            function toggle(){hours.style.display=status.value==='open'?'flex':'none';}
            status.addEventListener('change',toggle); toggle();
        });
        </script>

        <h2>Configured Special Dates</h2>
        <?php if ( empty( $dates ) ) : ?><p>No special dates configured.</p><?php else : ?>
            <div class="rwexec-table-card rwexec-special-dates-card"><table class="widefat rwexec-special-dates-table">
                <thead><tr><th>Date</th><th>Label</th><th>Status</th><th>Hours</th><th></th></tr></thead>
                <tbody>
                <?php foreach ( $dates as $item ) : ?>
                    <tr>
                        <td><?php echo esc_html( RWExec_Reservations_Service::format_date( (string) $item->special_date ) ); ?></td>
                        <td><?php echo esc_html( $item->label ?: '—' ); ?></td>
                        <td><?php echo esc_html( ucwords( str_replace( '_', ' ', $item->booking_status ) ) ); ?></td>
                        <td><?php echo 'open' === $item->booking_status ? esc_html( substr( $item->booking_start,0,5 ) . ' – ' . substr( $item->booking_end,0,5 ) ) : '—'; ?></td>
                        <td class="rwexec-special-date-actions">
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Delete this special date override?');">
                                <input type="hidden" name="action" value="rwexec_delete_special_date">
                                <input type="hidden" name="special_date_id" value="<?php echo esc_attr( $item->id ); ?>">
                                <?php wp_nonce_field( 'rwexec_delete_special_date', 'rwexec_delete_special_nonce' ); ?>
                                <button class="button" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
        <?php endif; ?>

        <?php if ( ! $embedded ) : ?>
            </div>
        <?php endif;
    }
}
