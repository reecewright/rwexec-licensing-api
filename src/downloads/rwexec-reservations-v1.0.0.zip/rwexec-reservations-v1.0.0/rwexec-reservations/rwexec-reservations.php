<?php

/**
 * Plugin Name: RWExec Reservations
 * Plugin URI: https://rwexec.com
 * Description: Restaurant reservation, availability and capacity management for WordPress.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: RWExec
 * Author URI: https://rwexec.com
 * Text Domain: rwexec-reservations
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', static function () {
    load_plugin_textdomain(
        'rwexec-reservations',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
} );

define( 'RWEXEC_RESERVATIONS_VERSION', '1.0.0' );
define( 'RWEXEC_RESERVATIONS_FILE', __FILE__ );
define( 'RWEXEC_RESERVATIONS_PATH', plugin_dir_path( __FILE__ ) );
define( 'RWEXEC_RESERVATIONS_URL', plugin_dir_url( __FILE__ ) );

require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-activator.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-special-dates.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-availability.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-capacity.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-service.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-email.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-automation.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-form-builder.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-public.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-staff.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-customers.php';
require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-license.php';

require_once RWEXEC_RESERVATIONS_PATH . 'admin/class-rwexec-reservations-actions.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/class-rwexec-reservations-settings.php';

require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservations-list-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservation-add-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservation-details-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservation-edit-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservations-special-dates-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservations-settings-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservations-email-templates-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservations-customers-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservations-customer-details-page.php';
require_once RWEXEC_RESERVATIONS_PATH . 'admin/pages/class-rwexec-reservations-setup-page.php';

require_once RWEXEC_RESERVATIONS_PATH . 'includes/class-rwexec-reservations-admin.php';

register_activation_hook(
    RWEXEC_RESERVATIONS_FILE,
    array( 'RWExec_Reservations_Activator', 'activate' )
);

register_deactivation_hook(
    RWEXEC_RESERVATIONS_FILE,
    array( 'RWExec_Reservations_Automation', 'deactivate' )
);

register_deactivation_hook(
    RWEXEC_RESERVATIONS_FILE,
    array( 'RWExec_Reservations_License', 'clear_schedule' )
);

add_action(
    'plugins_loaded',
    array( 'RWExec_Reservations_Activator', 'maybe_upgrade' )
);

RWExec_Reservations_Automation::init();
RWExec_Reservations_License::init();
RWExec_Reservations_Public::init();
RWExec_Reservations_Staff::init();
RWExec_Reservations_Admin::init();
