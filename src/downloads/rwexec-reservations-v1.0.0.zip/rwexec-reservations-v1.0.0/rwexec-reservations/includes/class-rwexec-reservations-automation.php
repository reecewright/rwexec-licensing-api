<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Automation {

    const CRON_HOOK = 'rwexec_reservations_process_automatic_no_shows';

    public static function init() {
        add_filter( 'cron_schedules', array( __CLASS__, 'add_cron_schedule' ) );
        add_action( self::CRON_HOOK, array( __CLASS__, 'run' ) );
        add_action( 'init', array( __CLASS__, 'ensure_scheduled' ) );
    }

    public static function add_cron_schedule( array $schedules ): array {
        if ( ! isset( $schedules['rwexec_every_fifteen_minutes'] ) ) {
            $schedules['rwexec_every_fifteen_minutes'] = array(
                'interval' => 15 * MINUTE_IN_SECONDS,
                'display'  => 'Every 15 minutes (RWExec Reservations)',
            );
        }

        return $schedules;
    }

    public static function ensure_scheduled() {
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event(
                time() + MINUTE_IN_SECONDS,
                'rwexec_every_fifteen_minutes',
                self::CRON_HOOK
            );
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( self::CRON_HOOK );
    }

    public static function run(): int {
        $lock_key = 'rwexec_reservations_automation_lock';
        $now = time();

        if ( ! add_option( $lock_key, $now, '', 'no' ) ) {
            $started = absint( get_option( $lock_key, 0 ) );
            if ( ! $started || ( $now - $started ) <= 10 * MINUTE_IN_SECONDS ) {
                return 0;
            }
            delete_option( $lock_key );
            if ( ! add_option( $lock_key, $now, '', 'no' ) ) {
                return 0;
            }
        }

        try {
            $processed = RWExec_Reservations_Service::process_automatic_no_shows();
            $processed += RWExec_Reservations_Service::process_automatic_completions();
            $processed += RWExec_Reservations_Email::process_scheduled();
            return $processed;
        } finally {
            delete_option( $lock_key );
        }
    }
}
