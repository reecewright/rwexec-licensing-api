<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Activator {

    const DB_VERSION = '0.10.15';

    public static function activate() {
        global $wpdb;

        $is_new_install = false === get_option( 'rwexec_reservations_db_version', false );

        $charset_collate = $wpdb->get_charset_collate();
        $reservations_table = $wpdb->prefix . 'rwexec_reservations';
        $special_dates_table = $wpdb->prefix . 'rwexec_reservation_special_dates';
        $customers_table = $wpdb->prefix . 'rwexec_reservation_customers';

        $reservations_sql = "CREATE TABLE {$reservations_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            customer_id BIGINT UNSIGNED NULL,
            customer_name VARCHAR(150) NOT NULL,
            customer_email VARCHAR(190) NOT NULL,
            customer_phone VARCHAR(50) NOT NULL,
            reservation_date DATE NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            guest_count SMALLINT UNSIGNED NOT NULL,
            table_reference VARCHAR(50) NOT NULL DEFAULT '',
            allergies TEXT NULL,
            additional_information TEXT NULL,
            custom_fields_json LONGTEXT NULL,
            marketing_email_consent TINYINT(1) NOT NULL DEFAULT 0,
            marketing_consent_text TEXT NULL,
            marketing_consent_at DATETIME NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'confirmed',
            source VARCHAR(30) NOT NULL DEFAULT 'online',
            is_historic TINYINT(1) NOT NULL DEFAULT 0,
            arrived_at DATETIME NULL,
            completed_at DATETIME NULL,
            completion_source VARCHAR(20) NULL,
            cancelled_at DATETIME NULL,
            no_show_at DATETIME NULL,
            late_minutes SMALLINT UNSIGNED NULL,
            confirmation_sent_at DATETIME NULL,
            update_email_sent_at DATETIME NULL,
            cancellation_sent_at DATETIME NULL,
            reminder_sent_at DATETIME NULL,
            feedback_sent_at DATETIME NULL,
            override_used TINYINT(1) NOT NULL DEFAULT 0,
            override_reason VARCHAR(100) DEFAULT NULL,
            override_by BIGINT UNSIGNED DEFAULT NULL,
            override_at DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY customer_id (customer_id),
            KEY reservation_date (reservation_date),
            KEY status (status),
            KEY is_historic (is_historic),
            KEY customer_email (customer_email),
            KEY customer_phone (customer_phone)
        ) {$charset_collate};";

        $special_dates_sql = "CREATE TABLE {$special_dates_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            special_date DATE NOT NULL,
            booking_status VARCHAR(30) NOT NULL DEFAULT 'closed',
            booking_start TIME NULL,
            booking_end TIME NULL,
            label VARCHAR(190) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY special_date (special_date)
        ) {$charset_collate};";


        $customers_sql = "CREATE TABLE {$customers_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            customer_name VARCHAR(150) NOT NULL,
            customer_email VARCHAR(190) NOT NULL DEFAULT '',
            customer_phone VARCHAR(50) NOT NULL DEFAULT '',
            staff_notes TEXT NULL,
            preferences TEXT NULL,
            marketing_email_consent TINYINT(1) NOT NULL DEFAULT 0,
            marketing_consent_at DATETIME NULL,
            marketing_consent_source VARCHAR(30) NULL,
            marketing_consent_text TEXT NULL,
            marketing_consent_updated_at DATETIME NULL,
            first_seen_at DATETIME NULL,
            last_seen_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY customer_email (customer_email),
            KEY customer_phone (customer_phone),
            KEY customer_name (customer_name)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $reservations_sql );
        dbDelta( $special_dates_sql );
        dbDelta( $customers_sql );

        update_option( 'rwexec_reservations_db_version', self::DB_VERSION );

        if ( $is_new_install && ! get_option( 'rwexec_setup_wizard_completed', false ) ) {
            update_option( 'rwexec_setup_wizard_pending', '1', false );
        }

        if ( class_exists( 'RWExec_Reservations_Customers' ) ) {
            RWExec_Reservations_Customers::backfill();
        }
    }

    public static function maybe_upgrade() {
        $installed_version = get_option( 'rwexec_reservations_db_version', '0' );

        if ( version_compare( $installed_version, self::DB_VERSION, '<' ) ) {
            self::activate();
        }
    }
}
