<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Admin {

    public static function init() {
        RWExec_Reservations_Actions::init();
        RWExec_Reservations_Settings::init();
        RWExec_Reservations_Setup_Page::init();
        add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
    }

    public static function register_admin_menu() {
        add_menu_page(
            __( 'RWExec Reservations', 'rwexec-reservations' ),
            __( 'Reservations', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations',
            array( 'RWExec_Reservations_List_Page', 'render' ),
            'dashicons-calendar-alt',
            30
        );

        add_submenu_page(
            'rwexec-reservations',
            __( 'Reservations', 'rwexec-reservations' ),
            __( 'Reservations', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations',
            array( 'RWExec_Reservations_List_Page', 'render' )
        );

        add_submenu_page(
            'rwexec-reservations',
            __( 'Add Reservation', 'rwexec-reservations' ),
            __( 'Add Reservation', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-add',
            array( 'RWExec_Reservation_Add_Page', 'render' )
        );

        add_submenu_page(
            'rwexec-reservations',
            __( 'Customers', 'rwexec-reservations' ),
            __( 'Customers', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-customers',
            array( 'RWExec_Reservations_Customers_Page', 'render' )
        );

        add_submenu_page(
            'rwexec-reservations',
            __( 'Reservation Settings', 'rwexec-reservations' ),
            __( 'Settings', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-settings',
            array( 'RWExec_Reservations_Settings_Page', 'render' )
        );

        add_submenu_page(
            null,
            __( 'Setup Wizard', 'rwexec-reservations' ),
            __( 'Setup Wizard', 'rwexec-reservations' ),
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-setup',
            array( 'RWExec_Reservations_Setup_Page', 'render' )
        );

        add_submenu_page(
            null,
            'Customer Details',
            'Customer Details',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-customer',
            array( 'RWExec_Reservations_Customer_Details_Page', 'render' )
        );

        add_submenu_page(
            null,
            'Special Dates',
            'Special Dates',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-special-dates',
            array( 'RWExec_Reservations_Special_Dates_Page', 'render' )
        );

        add_submenu_page(
            null,
            'Email Templates',
            'Email Templates',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservations-emails',
            array( 'RWExec_Reservations_Email_Templates_Page', 'render' )
        );

        add_submenu_page(
            null,
            'Reservation Details',
            'Reservation Details',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservation-details',
            array( 'RWExec_Reservation_Details_Page', 'render' )
        );

        add_submenu_page(
            null,
            'Edit Reservation',
            'Edit Reservation',
            RWExec_Reservations_Staff::ADMIN_CAPABILITY,
            'rwexec-reservation-edit',
            array( 'RWExec_Reservation_Edit_Page', 'render' )
        );
    }

    public static function enqueue_assets( string $hook_suffix ) {
        if ( false === strpos( $hook_suffix, 'rwexec' ) && empty( $_GET['page'] ) ) {
            return;
        }

        $page = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
        if ( 0 !== strpos( $page, 'rwexec-' ) ) {
            return;
        }

        $css_file = RWEXEC_RESERVATIONS_PATH . 'assets/css/admin.css';
        $css_version = file_exists( $css_file ) ? (string) filemtime( $css_file ) : RWEXEC_RESERVATIONS_VERSION;

        wp_enqueue_style(
            'rwexec-reservations-admin',
            RWEXEC_RESERVATIONS_URL . 'assets/css/admin.css',
            array(),
            $css_version
        );
    }
}
