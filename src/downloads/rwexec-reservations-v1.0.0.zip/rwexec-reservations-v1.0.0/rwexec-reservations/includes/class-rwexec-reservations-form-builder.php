<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Form_Builder {

    public static function default_core_fields(): array {
        return array(
            'guests' => array( 'visible' => 1, 'required' => 1, 'label' => 'Guests', 'placeholder' => 'Select guests' ),
            'time' => array( 'visible' => 1, 'required' => 1, 'label' => 'Available time', 'placeholder' => 'Select an available time' ),
            'name' => array( 'visible' => 1, 'required' => 1, 'label' => 'Name', 'placeholder' => '' ),
            'phone' => array( 'visible' => 1, 'required' => 1, 'label' => 'Phone', 'placeholder' => '' ),
            'email' => array( 'visible' => 1, 'required' => 1, 'label' => 'Email', 'placeholder' => '' ),
            'allergies' => array( 'visible' => 1, 'required' => 0, 'label' => 'Any allergies?', 'placeholder' => 'Please tell us about any allergies or dietary requirements.' ),
            'additional_information' => array( 'visible' => 1, 'required' => 0, 'label' => 'Additional information', 'placeholder' => 'Special requests or anything else we should know.' ),
        );
    }

    public static function get_core_fields(): array {
        $saved = get_option( 'rwexec_public_core_fields', array() );
        $defaults = self::default_core_fields();
        if ( ! is_array( $saved ) ) {
            return $defaults;
        }
        foreach ( $defaults as $key => $default ) {
            $defaults[ $key ] = wp_parse_args( $saved[ $key ] ?? array(), $default );
        }
        // These are protected booking fields.
        foreach ( array( 'guests', 'time', 'name' ) as $protected_key ) {
            $defaults[ $protected_key ]['visible'] = 1;
            $defaults[ $protected_key ]['required'] = 1;
        }
        return $defaults;
    }

    public static function sanitize_core_fields( $value ): array {
        $defaults = self::default_core_fields();
        $value = is_array( $value ) ? $value : array();
        $clean = array();
        foreach ( $defaults as $key => $default ) {
            $row = isset( $value[ $key ] ) && is_array( $value[ $key ] ) ? $value[ $key ] : array();
            $clean[ $key ] = array(
                'visible' => in_array( $key, array( 'guests', 'time', 'name' ), true ) ? 1 : ( ! empty( $row['visible'] ) ? 1 : 0 ),
                'required' => in_array( $key, array( 'guests', 'time', 'name' ), true ) ? 1 : ( ! empty( $row['required'] ) ? 1 : 0 ),
                'label' => sanitize_text_field( $row['label'] ?? $default['label'] ),
                'placeholder' => sanitize_text_field( $row['placeholder'] ?? $default['placeholder'] ),
            );
        }

        // A public booking must always collect at least one required contact method.
        $phone_required = ! empty( $clean['phone']['visible'] ) && ! empty( $clean['phone']['required'] );
        $email_required = ! empty( $clean['email']['visible'] ) && ! empty( $clean['email']['required'] );
        if ( ! $phone_required && ! $email_required ) {
            add_settings_error(
                'rwexec_public_core_fields',
                'rwexec_contact_method_required',
                'At least one contact method must be visible and required: Email or Phone.',
                'error'
            );
            $previous = self::get_core_fields();
            $clean['phone'] = $previous['phone'];
            $clean['email'] = $previous['email'];
        }
        return $clean;
    }

    public static function core_field( string $key ): array {
        $fields = self::get_core_fields();
        return $fields[ $key ] ?? array();
    }

    public static function get_fields(): array {
        $fields = get_option( 'rwexec_public_custom_fields', array() );
        return is_array( $fields ) ? $fields : array();
    }

    /**
     * Customer-detail fields can be reordered together. The booking-selection
     * fields (Date, Guests and Time) remain fixed at the top of the form.
     */
    public static function get_field_order(): array {
        $custom_fields = self::get_fields();
        $custom_ids = array();
        foreach ( $custom_fields as $field ) {
            $id = sanitize_key( $field['id'] ?? '' );
            if ( '' !== $id ) {
                $custom_ids[] = $id;
            }
        }

        $default_core = array(
            'core:name',
            'core:phone',
            'core:email',
            'core:allergies',
            'core:additional_information',
        );

        $saved = get_option( 'rwexec_public_field_order', array() );
        $saved = is_array( $saved ) ? $saved : array();

        // First-time migration from the old "Place after" model.
        if ( empty( $saved ) ) {
            $legacy_groups = array(
                'after_name' => array(),
                'after_phone' => array(),
                'after_email' => array(),
                'after_allergies' => array(),
                'after_additional_information' => array(),
            );
            foreach ( $custom_fields as $field ) {
                $id = sanitize_key( $field['id'] ?? '' );
                if ( '' === $id ) {
                    continue;
                }
                $position = sanitize_key( $field['position'] ?? 'after_email' );
                if ( ! isset( $legacy_groups[ $position ] ) ) {
                    $position = 'after_email';
                }
                $legacy_groups[ $position ][] = 'custom:' . $id;
            }
            $saved = array(
                'core:name',
                ...$legacy_groups['after_name'],
                'core:phone',
                ...$legacy_groups['after_phone'],
                'core:email',
                ...$legacy_groups['after_email'],
                'core:allergies',
                ...$legacy_groups['after_allergies'],
                'core:additional_information',
                ...$legacy_groups['after_additional_information'],
            );
        }

        $valid = array_fill_keys( $default_core, true );
        foreach ( $custom_ids as $id ) {
            $valid[ 'custom:' . $id ] = true;
        }

        $order = array();
        foreach ( $saved as $token ) {
            $token = sanitize_text_field( (string) $token );
            if ( isset( $valid[ $token ] ) && ! in_array( $token, $order, true ) ) {
                $order[] = $token;
            }
        }

        // Never lose a field if an older/newer saved order is incomplete.
        foreach ( $default_core as $token ) {
            if ( ! in_array( $token, $order, true ) ) {
                $order[] = $token;
            }
        }
        foreach ( $custom_ids as $id ) {
            $token = 'custom:' . $id;
            if ( ! in_array( $token, $order, true ) ) {
                $order[] = $token;
            }
        }

        return $order;
    }

    public static function sanitize_field_order( $value ): array {
        if ( ! is_array( $value ) ) {
            return array();
        }
        $clean = array();
        foreach ( $value as $token ) {
            $token = sanitize_text_field( (string) $token );
            if ( preg_match( '/^(core:(name|phone|email|allergies|additional_information)|custom:[a-z0-9_\-]+)$/', $token ) && ! in_array( $token, $clean, true ) ) {
                $clean[] = $token;
            }
        }
        return $clean;
    }

    public static function get_custom_field( string $id ): array {
        $id = sanitize_key( $id );
        foreach ( self::get_fields() as $field ) {
            if ( sanitize_key( $field['id'] ?? '' ) === $id ) {
                return $field;
            }
        }
        return array();
    }

    public static function sanitize_fields( $value ): array {
        // Custom booking fields are Premium. When Premium is inactive, retain
        // the previously saved configuration without allowing changes through
        // a manipulated settings request.
        if ( ! RWExec_Reservations_License::is_premium() ) {
            $existing = get_option( 'rwexec_public_custom_fields', array() );
            return is_array( $existing ) ? $existing : array();
        }
        if ( ! is_array( $value ) ) {
            return array();
        }

        $allowed_types = array( 'text', 'textarea', 'checkbox', 'select', 'info' );
        $clean = array();

        foreach ( $value as $field ) {
            if ( ! is_array( $field ) ) {
                continue;
            }

            $type = sanitize_key( $field['type'] ?? 'text' );
            if ( ! in_array( $type, $allowed_types, true ) ) {
                $type = 'text';
            }

            $id = sanitize_key( $field['id'] ?? '' );
            if ( '' === $id ) {
                $id = 'field_' . wp_generate_password( 8, false, false );
            }

            $label = sanitize_text_field( $field['label'] ?? '' );
            $content = wp_kses_post( $field['content'] ?? '' );
            if ( 'info' !== $type && '' === $label ) {
                continue;
            }
            if ( 'info' === $type && '' === trim( wp_strip_all_tags( $content ) ) ) {
                continue;
            }

            $options = array();
            if ( 'select' === $type ) {
                $raw_options = $field['options'] ?? '';
                $source = is_array( $raw_options ) ? $raw_options : preg_split( '/\r\n|\r|\n/', (string) $raw_options );
                foreach ( $source as $option ) {
                    $option = sanitize_text_field( $option );
                    if ( '' !== $option ) {
                        $options[] = $option;
                    }
                }
            }

            $clean[] = array(
                'id' => $id,
                'type' => $type,
                'label' => $label,
                'content' => $content,
                'placeholder' => sanitize_text_field( $field['placeholder'] ?? '' ),
                // Kept for backward compatibility only; ordering is now handled
                // by rwexec_public_field_order.
                'position' => sanitize_key( $field['position'] ?? 'after_email' ),
                'required' => ! empty( $field['required'] ) ? 1 : 0,
                'show_admin' => 'info' === $type ? 0 : ( ! empty( $field['show_admin'] ) ? 1 : 0 ),
                'show_email' => 'info' === $type ? 0 : ( ! empty( $field['show_email'] ) ? 1 : 0 ),
                'record_consent' => ( 'checkbox' === $type && ! empty( $field['record_consent'] ) ) ? 1 : 0,
                'options' => $options,
            );
        }

        return array_values( $clean );
    }

    // Legacy helpers retained so older templates/customisations do not break.
    public static function fields_for_position( string $position ): array {
        return array_values( array_filter( self::get_fields(), function ( $field ) use ( $position ) {
            return ( $field['position'] ?? '' ) === $position;
        } ) );
    }

    public static function replace_info_placeholders( string $content ): string {
        return strtr(
            $content,
            array(
                '{max_guests}' => (string) max( 1, absint( get_option( 'rwexec_public_max_party_size', 12 ) ) ),
                '{restaurant_phone}' => esc_html( (string) get_option( 'rwexec_email_restaurant_phone', '' ) ),
                '{restaurant_email}' => esc_html( (string) get_option( 'rwexec_email_contact_email', get_option( 'admin_email' ) ) ),
                '{restaurant_name}' => esc_html( (string) get_option( 'rwexec_email_restaurant_name', get_bloginfo( 'name' ) ) ),
            )
        );
    }

    public static function render_position( string $position ): void {
        foreach ( self::fields_for_position( $position ) as $field ) {
            self::render_field( $field );
        }
    }

    public static function render_field( array $field ): void {
        $id = 'rwexec_custom_' . sanitize_key( $field['id'] );
        $name = 'rwexec_custom[' . sanitize_key( $field['id'] ) . ']';
        $required = ! empty( $field['required'] );
        $required_html = $required ? ' required' : '';
        $required_mark = $required ? ' <span aria-hidden="true">*</span>' : '';
        $type = $field['type'] ?? 'text';

        if ( 'info' === $type ) {
            echo '<div class="rwexec-form-note rwexec-field--full">' . wp_kses_post( self::replace_info_placeholders( (string) $field['content'] ) ) . '</div>';
            return;
        }

        if ( 'checkbox' === $type ) {
            echo '<div class="rwexec-field rwexec-field--full rwexec-field--checkbox">';
            echo '<label for="' . esc_attr( $id ) . '"><input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="1"' . $required_html . '> ' . esc_html( $field['label'] ) . $required_mark . '</label>';
            echo '</div>';
            return;
        }

        echo '<div class="rwexec-field rwexec-field--full">';
        echo '<label for="' . esc_attr( $id ) . '">' . esc_html( $field['label'] ) . $required_mark . '</label>';

        if ( 'textarea' === $type ) {
            echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="3" placeholder="' . esc_attr( $field['placeholder'] ?? '' ) . '"' . $required_html . '></textarea>';
        } elseif ( 'select' === $type ) {
            echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"' . $required_html . '>';
            echo '<option value="">Select an option</option>';
            foreach ( (array) ( $field['options'] ?? array() ) as $option ) {
                echo '<option value="' . esc_attr( $option ) . '">' . esc_html( $option ) . '</option>';
            }
            echo '</select>';
        } else {
            echo '<input type="text" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" maxlength="255" placeholder="' . esc_attr( $field['placeholder'] ?? '' ) . '"' . $required_html . '>';
        }
        echo '</div>';
    }

    public static function collect_submission( array $post ) {
        if ( ! RWExec_Reservations_License::is_premium() ) {
            return array();
        }
        $submitted = isset( $post['rwexec_custom'] ) && is_array( $post['rwexec_custom'] ) ? $post['rwexec_custom'] : array();
        $result = array();

        foreach ( self::get_fields() as $field ) {
            if ( 'info' === ( $field['type'] ?? '' ) ) {
                continue;
            }

            $id = sanitize_key( $field['id'] ?? '' );
            $type = $field['type'] ?? 'text';
            $raw = $submitted[ $id ] ?? '';

            if ( 'checkbox' === $type ) {
                $checked = '1' === (string) $raw;
                if ( ! empty( $field['required'] ) && ! $checked ) {
                    return new WP_Error( 'rwexec_required_custom_field', sprintf( 'Please complete: %s.', $field['label'] ) );
                }
                $entry = array(
                    'id' => $id,
                    'label' => $field['label'],
                    'type' => $type,
                    'value' => $checked ? 'Yes' : 'No',
                    'show_admin' => ! empty( $field['show_admin'] ),
                    'show_email' => ! empty( $field['show_email'] ),
                );
                if ( ! empty( $field['record_consent'] ) && $checked ) {
                    $entry['consent_text'] = $field['label'];
                    $entry['consent_at'] = current_time( 'mysql' );
                }
                $result[] = $entry;
                continue;
            }

            $value = 'textarea' === $type
                ? sanitize_textarea_field( wp_unslash( $raw ) )
                : sanitize_text_field( wp_unslash( $raw ) );

            if ( ! empty( $field['required'] ) && '' === trim( $value ) ) {
                return new WP_Error( 'rwexec_required_custom_field', sprintf( 'Please complete: %s.', $field['label'] ) );
            }

            if ( 'select' === $type && '' !== $value && ! in_array( $value, (array) ( $field['options'] ?? array() ), true ) ) {
                return new WP_Error( 'rwexec_invalid_custom_field', sprintf( 'Please choose a valid option for %s.', $field['label'] ) );
            }

            $result[] = array(
                'id' => $id,
                'label' => $field['label'],
                'type' => $type,
                'value' => $value,
                'show_admin' => ! empty( $field['show_admin'] ),
                'show_email' => ! empty( $field['show_email'] ),
            );
        }

        return $result;
    }

    public static function decode_responses( $reservation ): array {
        $raw = (string) ( $reservation->custom_fields_json ?? '' );
        if ( '' === $raw ) {
            return array();
        }
        $decoded = json_decode( $raw, true );
        return is_array( $decoded ) ? $decoded : array();
    }

    public static function email_html( $reservation ): string {
        $rows = array_filter( self::decode_responses( $reservation ), function ( $entry ) {
            return ! empty( $entry['show_email'] );
        } );
        if ( empty( $rows ) ) {
            return '';
        }

        $html = '<table role="presentation" style="width:100%;border-collapse:collapse;margin:20px 0">';
        foreach ( $rows as $entry ) {
            $html .= '<tr><td style="padding:9px 0;border-bottom:1px solid #e5e7eb;color:#6b7280;width:35%">' . esc_html( $entry['label'] ?? '' ) . '</td><td style="padding:9px 0;border-bottom:1px solid #e5e7eb;font-weight:600">' . nl2br( esc_html( $entry['value'] ?? '' ) ) . '</td></tr>';
        }
        $html .= '</table>';
        return $html;
    }
}
