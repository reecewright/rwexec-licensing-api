<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Public {

    private static $instance = 0;

    public static function init() {
        add_shortcode( 'rwexec_reservations', array( __CLASS__, 'render_shortcode' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_public_styles' ) );
        add_action( 'wp_ajax_rwexec_booking_bootstrap', array( __CLASS__, 'ajax_booking_bootstrap' ) );
        add_action( 'wp_ajax_nopriv_rwexec_booking_bootstrap', array( __CLASS__, 'ajax_booking_bootstrap' ) );
        add_action( 'wp_ajax_rwexec_get_booking_times', array( __CLASS__, 'ajax_get_booking_times' ) );
        add_action( 'wp_ajax_nopriv_rwexec_get_booking_times', array( __CLASS__, 'ajax_get_booking_times' ) );
        add_action( 'wp_ajax_rwexec_get_calendar_availability', array( __CLASS__, 'ajax_get_calendar_availability' ) );
        add_action( 'wp_ajax_nopriv_rwexec_get_calendar_availability', array( __CLASS__, 'ajax_get_calendar_availability' ) );
        add_action( 'wp_ajax_rwexec_create_public_reservation', array( __CLASS__, 'ajax_create_reservation' ) );
        add_action( 'wp_ajax_nopriv_rwexec_create_public_reservation', array( __CLASS__, 'ajax_create_reservation' ) );
    }

    public static function enqueue_public_styles(): void {
        $css_file = RWEXEC_RESERVATIONS_PATH . 'assets/css/public.css';
        $css_version = file_exists( $css_file ) ? (string) filemtime( $css_file ) : RWEXEC_RESERVATIONS_VERSION;

        wp_enqueue_style(
            'rwexec-reservations-public',
            RWEXEC_RESERVATIONS_URL . 'assets/css/public.css',
            array(),
            $css_version
        );
    }

    public static function render_shortcode(): string {
        self::$instance++;
        $instance = self::$instance;

        self::enqueue_public_styles();

        $font_stacks = array(
            'inherit' => 'inherit',
            'system' => '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',
            'arial' => 'Arial,sans-serif',
            'helvetica' => 'Helvetica,Arial,sans-serif',
            'georgia' => 'Georgia,serif',
            'verdana' => 'Verdana,Geneva,sans-serif',
            'trebuchet' => '"Trebuchet MS",Arial,sans-serif',
        );
        $font_key = sanitize_key( (string) get_option( 'rwexec_form_font_family', 'inherit' ) );
        $font_stack = $font_stacks[ $font_key ] ?? $font_stacks['inherit'];

        $style_values = array(
            '--rwexec-font-family' => $font_stack,
            '--rwexec-font-size' => max( 12, min( 20, absint( get_option( 'rwexec_form_font_size', 14 ) ) ) ) . 'px',
            '--rwexec-label-font-size' => max( 11, min( 18, absint( get_option( 'rwexec_form_label_font_size', 13 ) ) ) ) . 'px',
            '--rwexec-control-radius' => max( 0, min( 24, absint( get_option( 'rwexec_form_border_radius', 7 ) ) ) ) . 'px',
            '--rwexec-form-bg' => sanitize_hex_color( get_option( 'rwexec_form_background_color', '#ffffff' ) ) ?: '#ffffff',
            '--rwexec-form-border' => sanitize_hex_color( get_option( 'rwexec_form_border_color', '#e2e8f0' ) ) ?: '#e2e8f0',
            '--rwexec-label-color' => sanitize_hex_color( get_option( 'rwexec_form_label_color', '#1e293b' ) ) ?: '#1e293b',
            '--rwexec-required-color' => sanitize_hex_color( get_option( 'rwexec_form_required_color', '#dc2626' ) ) ?: '#dc2626',
            '--rwexec-heading-color' => sanitize_hex_color( get_option( 'rwexec_form_heading_color', '#1e293b' ) ) ?: '#1e293b',
            '--rwexec-subheading-color' => sanitize_hex_color( get_option( 'rwexec_form_subheading_color', '#64748b' ) ) ?: '#64748b',
            '--rwexec-heading-size' => max( 16, min( 48, absint( get_option( 'rwexec_form_heading_font_size', 28 ) ) ) ) . 'px',
            '--rwexec-heading-weight' => in_array( absint( get_option( 'rwexec_form_heading_font_weight', 700 ) ), array( 400, 500, 600, 700, 800 ), true ) ? absint( get_option( 'rwexec_form_heading_font_weight', 700 ) ) : 700,
            '--rwexec-subheading-size' => max( 11, min( 24, absint( get_option( 'rwexec_form_subheading_font_size', 14 ) ) ) ) . 'px',
            '--rwexec-control-bg' => sanitize_hex_color( get_option( 'rwexec_form_field_background_color', '#ffffff' ) ) ?: '#ffffff',
            '--rwexec-control-border' => sanitize_hex_color( get_option( 'rwexec_form_field_border_color', '#cbd5e1' ) ) ?: '#cbd5e1',
            '--rwexec-control-text' => sanitize_hex_color( get_option( 'rwexec_form_field_text_color', '#1e293b' ) ) ?: '#1e293b',
            '--rwexec-placeholder-color' => sanitize_hex_color( get_option( 'rwexec_form_placeholder_color', '#94a3b8' ) ) ?: '#94a3b8',
            '--rwexec-focus-color' => sanitize_hex_color( get_option( 'rwexec_form_focus_color', '#1e293b' ) ) ?: '#1e293b',
            '--rwexec-button-bg' => sanitize_hex_color( get_option( 'rwexec_form_button_background_color', '#1e293b' ) ) ?: '#1e293b',
            '--rwexec-button-text' => sanitize_hex_color( get_option( 'rwexec_form_button_text_color', '#ffffff' ) ) ?: '#ffffff',
            '--rwexec-button-hover-bg' => sanitize_hex_color( get_option( 'rwexec_form_button_hover_background_color', '#334155' ) ) ?: '#334155',
            '--rwexec-button-hover-text' => sanitize_hex_color( get_option( 'rwexec_form_button_hover_text_color', '#ffffff' ) ) ?: '#ffffff',
            '--rwexec-consent-bg' => sanitize_hex_color( get_option( 'rwexec_form_consent_background_color', '#f8fafc' ) ) ?: '#f8fafc',
            '--rwexec-consent-border' => sanitize_hex_color( get_option( 'rwexec_form_consent_border_color', '#e2e8f0' ) ) ?: '#e2e8f0',
            '--rwexec-consent-text' => sanitize_hex_color( get_option( 'rwexec_form_consent_text_color', '#1e293b' ) ) ?: '#1e293b',
            '--rwexec-consent-muted' => sanitize_hex_color( get_option( 'rwexec_form_consent_muted_color', '#64748b' ) ) ?: '#64748b',
        );
        $inline_style = '';
        foreach ( $style_values as $property => $value ) {
            $inline_style .= $property . ':' . $value . ';';
        }

        wp_enqueue_script(
            'rwexec-reservations-public',
            RWEXEC_RESERVATIONS_URL . 'assets/js/public.js',
            array(),
            RWEXEC_RESERVATIONS_VERSION,
            true
        );

        wp_localize_script(
            'rwexec-reservations-public',
            'RWExecReservations',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'rwexec_public_booking' ),
                'maxPartySize' => absint( get_option( 'rwexec_public_max_party_size', 12 ) ),
                'messages' => array(
                    'loading' => 'Checking availability…',
                    'chooseDateParty' => 'Choose a date and party size to see available times.',
                    'chooseTime' => sanitize_text_field( RWExec_Reservations_Form_Builder::core_field( 'time' )['placeholder'] ?? 'Select an available time' ),
                    'noTimes' => 'No times are available for this party size on this date. Please choose another date or party size.',
                    'limitedTimes' => 'Can’t see the time you want? Times not shown are unavailable for your selected party size.',
                    'error' => 'Something went wrong. Please try again.',
                ),
            )
        );

        $today = ( new DateTimeImmutable( 'today', RWExec_Reservations_Service::restaurant_timezone() ) )->format( 'Y-m-d' );
        $advance_days = max( 1, absint( get_option( 'rwexec_public_advance_days', 90 ) ) );
        $max_date = ( new DateTimeImmutable( 'today', RWExec_Reservations_Service::restaurant_timezone() ) )
            ->modify( '+' . $advance_days . ' days' )
            ->format( 'Y-m-d' );
        $max_party = max( 1, absint( get_option( 'rwexec_public_max_party_size', 12 ) ) );
        $core_fields = RWExec_Reservations_Form_Builder::get_core_fields();
        $guest_field = $core_fields['guests'];
        $time_field = $core_fields['time'];

        $id = function ( string $name ) use ( $instance ): string {
            return 'rwexec_' . $name . '_' . $instance;
        };

        $form_heading = trim( (string) get_option( 'rwexec_form_heading', '' ) );
        $form_subheading = trim( (string) get_option( 'rwexec_form_subheading', '' ) );

        ob_start();
        ?>
        <div class="rwexec-booking" style="<?php echo esc_attr( $inline_style ); ?>" data-rwexec-booking data-min-date="<?php echo esc_attr( $today ); ?>" data-max-date="<?php echo esc_attr( $max_date ); ?>">
            <?php if ( '' !== $form_heading || '' !== $form_subheading ) : ?>
                <div class="rwexec-booking__intro">
                    <?php if ( '' !== $form_heading ) : ?><h2 class="rwexec-booking__heading"><?php echo esc_html( $form_heading ); ?></h2><?php endif; ?>
                    <?php if ( '' !== $form_subheading ) : ?><p class="rwexec-booking__subheading"><?php echo esc_html( $form_subheading ); ?></p><?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="rwexec-booking__notice" data-rwexec-notice hidden></div>

            <form class="rwexec-booking__form" data-rwexec-form novalidate>
                <div class="rwexec-booking__quick-grid">
                    <div class="rwexec-field">
                        <label for="<?php echo esc_attr( $id( 'reservation_date' ) ); ?>">Date <span aria-hidden="true">*</span></label>
                        <input type="date" id="<?php echo esc_attr( $id( 'reservation_date' ) ); ?>" name="reservation_date" value="<?php echo esc_attr( $today ); ?>" min="<?php echo esc_attr( $today ); ?>" max="<?php echo esc_attr( $max_date ); ?>" data-rwexec-date-input required>
                    </div>

                    <div class="rwexec-field">
                        <label for="<?php echo esc_attr( $id( 'guest_count' ) ); ?>"><?php echo esc_html( $guest_field['label'] ); ?> <span aria-hidden="true">*</span></label>
                        <select id="<?php echo esc_attr( $id( 'guest_count' ) ); ?>" name="guest_count" required>
                            <option value=""><?php echo esc_html( $guest_field['placeholder'] ?: 'Select guests' ); ?></option>
                            <?php for ( $i = 1; $i <= $max_party; $i++ ) : ?>
                                <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_html( $i . ( 1 === $i ? ' guest' : ' guests' ) ); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="rwexec-field">
                        <label for="<?php echo esc_attr( $id( 'start_time' ) ); ?>"><?php echo esc_html( $time_field['label'] ); ?> <span aria-hidden="true">*</span></label>
                        <select id="<?php echo esc_attr( $id( 'start_time' ) ); ?>" name="start_time" data-rwexec-time-select required disabled>
                            <option value=""><?php echo esc_html( $time_field['placeholder'] ?: 'Select an available time' ); ?></option>
                        </select>
                        <div class="rwexec-field__message" data-rwexec-times-message></div>
                    </div>
                </div>

                <div class="rwexec-booking__grid">
                    <?php foreach ( RWExec_Reservations_Form_Builder::get_field_order() as $token ) : ?>
                        <?php if ( 0 === strpos( $token, 'core:' ) ) : ?>
                            <?php $core_key = substr( $token, 5 ); ?>
                            <?php if ( ! in_array( $core_key, array( 'allergies', 'additional_information' ), true ) ) : self::render_public_core_field( $core_key, $core_fields, $id ); endif; ?>
                        <?php elseif ( 0 === strpos( $token, 'custom:' ) ) : ?>
                            <?php if ( ! RWExec_Reservations_License::is_premium() ) { continue; } ?>
                            <?php $custom_field = RWExec_Reservations_Form_Builder::get_custom_field( substr( $token, 7 ) ); ?>
                            <?php if ( $custom_field ) : RWExec_Reservations_Form_Builder::render_field( $custom_field ); endif; ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>

                <?php self::render_public_service_row( $core_fields, $id ); ?>

                <?php
                $communications_text = (string) get_option( 'rwexec_booking_communications_text', 'We’ll use your contact details to send information about this reservation, such as your confirmation, updates and reminders.' );
                $marketing_label = (string) get_option( 'rwexec_marketing_consent_label', 'Keep me updated' );
                $marketing_text = (string) get_option( 'rwexec_marketing_consent_text', 'I’d like to receive occasional news, offers and updates from {restaurant_name} by email.' );
                $marketing_text = str_replace( '{restaurant_name}', (string) get_option( 'rwexec_email_restaurant_name', get_bloginfo( 'name' ) ), $marketing_text );
                ?>
                <div class="rwexec-booking__actions">
                    <div class="rwexec-booking-consent">
                        <?php if ( '' !== trim( $communications_text ) ) : ?><p class="rwexec-booking-consent__service"><?php echo esc_html( $communications_text ); ?></p><?php endif; ?>
                        <?php if ( RWExec_Reservations_License::is_premium() ) : ?>
                        <label class="rwexec-booking-consent__marketing" for="<?php echo esc_attr( $id( 'marketing_email_consent' ) ); ?>">
                            <input type="checkbox" id="<?php echo esc_attr( $id( 'marketing_email_consent' ) ); ?>" name="marketing_email_consent" value="1">
                            <span><strong><?php echo esc_html( $marketing_label ); ?></strong><?php if ( '' !== trim( $marketing_text ) ) : ?><small><?php echo esc_html( $marketing_text ); ?></small><?php endif; ?></span>
                        </label>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="rwexec-booking__submit" data-rwexec-submit>Book Table</button>
                </div>

                <div class="rwexec-hp" aria-hidden="true">
                    <label>Leave this field empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
                </div>
            </form>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    private static function render_public_core_field( string $key, array $core_fields, callable $id ): void {
        if ( ! isset( $core_fields[ $key ] ) ) {
            return;
        }
        $f = $core_fields[ $key ];
        if ( 'name' !== $key && empty( $f['visible'] ) ) {
            return;
        }
        $required = 'name' === $key || ! empty( $f['required'] );
        $required_mark = $required ? ' <span aria-hidden="true">*</span>' : '';

        $field_class = 'rwexec-field';
        echo '<div class="' . esc_attr( $field_class ) . '">';
        if ( 'name' === $key ) {
            echo '<label for="' . esc_attr( $id( 'customer_name' ) ) . '">' . esc_html( $f['label'] ) . $required_mark . '</label>';
            echo '<input type="text" id="' . esc_attr( $id( 'customer_name' ) ) . '" name="customer_name" autocomplete="name" maxlength="150" placeholder="' . esc_attr( $f['placeholder'] ) . '" required>';
        } elseif ( 'phone' === $key ) {
            echo '<label for="' . esc_attr( $id( 'customer_phone' ) ) . '">' . esc_html( $f['label'] ) . $required_mark . '</label>';
            echo '<input type="tel" id="' . esc_attr( $id( 'customer_phone' ) ) . '" name="customer_phone" autocomplete="tel" maxlength="50" placeholder="' . esc_attr( $f['placeholder'] ) . '"' . ( $required ? ' required' : '' ) . '>';
        } elseif ( 'email' === $key ) {
            echo '<label for="' . esc_attr( $id( 'customer_email' ) ) . '">' . esc_html( $f['label'] ) . $required_mark . '</label>';
            echo '<input type="email" id="' . esc_attr( $id( 'customer_email' ) ) . '" name="customer_email" autocomplete="email" maxlength="190" placeholder="' . esc_attr( $f['placeholder'] ) . '"' . ( $required ? ' required' : '' ) . '>';
        }
        echo '</div>';
    }

    private static function render_public_service_row( array $core_fields, callable $id ): void {
        $allergy_field = $core_fields['allergies'] ?? array();
        $additional_field = $core_fields['additional_information'] ?? array();
        $show_allergies = ! empty( $allergy_field['visible'] );
        $show_additional = ! empty( $additional_field['visible'] );

        if ( ! $show_allergies && ! $show_additional ) {
            return;
        }

        $allergy_required = $show_allergies && ! empty( $allergy_field['required'] );
        $additional_required = $show_additional && ! empty( $additional_field['required'] );
        ?>
        <div class="rwexec-booking__service-grid<?php echo ! $show_allergies ? ' rwexec-booking__service-grid--additional-only' : ''; ?>"<?php if ( $show_allergies ) : ?> data-rwexec-allergies<?php endif; ?>>
            <?php if ( $show_allergies ) : ?>
                <fieldset class="rwexec-allergy-field rwexec-service-panel">
                    <legend><?php echo esc_html( $allergy_field['label'] ); ?><?php if ( $allergy_required ) : ?> <span aria-hidden="true">*</span><?php endif; ?></legend>
                    <div class="rwexec-allergy-choice">
                        <label><input type="radio" name="rwexec_has_allergies" value="0"<?php echo $allergy_required ? ' required' : ''; ?>> <span>No</span></label>
                        <label><input type="radio" name="rwexec_has_allergies" value="1"<?php echo $allergy_required ? ' required' : ''; ?>> <span>Yes</span></label>
                    </div>
                </fieldset>
            <?php endif; ?>

            <?php if ( $show_additional ) : ?>
                <div class="rwexec-field rwexec-service-panel rwexec-service-panel--textarea">
                    <label for="<?php echo esc_attr( $id( 'additional_information' ) ); ?>"><?php echo esc_html( $additional_field['label'] ); ?><?php if ( $additional_required ) : ?> <span aria-hidden="true">*</span><?php endif; ?></label>
                    <textarea id="<?php echo esc_attr( $id( 'additional_information' ) ); ?>" name="additional_information" rows="2" placeholder="<?php echo esc_attr( $additional_field['placeholder'] ); ?>"<?php echo $additional_required ? ' required' : ''; ?>></textarea>
                </div>
            <?php endif; ?>

            <?php if ( $show_allergies ) : ?>
                <div class="rwexec-field rwexec-service-panel rwexec-service-panel--textarea rwexec-allergy-details" data-rwexec-allergy-details hidden>
                    <label for="<?php echo esc_attr( $id( 'allergies' ) ); ?>">Allergy Details</label>
                    <textarea id="<?php echo esc_attr( $id( 'allergies' ) ); ?>" name="allergies" rows="2" placeholder="<?php echo esc_attr( $allergy_field['placeholder'] ?: 'Enter allergy requirements' ); ?>"></textarea>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function ajax_booking_bootstrap() {
        nocache_headers();

        $timezone = RWExec_Reservations_Service::restaurant_timezone();
        $today_object = new DateTimeImmutable( 'today', $timezone );
        $advance_days = max( 1, absint( get_option( 'rwexec_public_advance_days', 90 ) ) );

        wp_send_json_success(
            array(
                'today' => $today_object->format( 'Y-m-d' ),
                'maxDate' => $today_object->modify( '+' . $advance_days . ' days' )->format( 'Y-m-d' ),
                'nonce' => wp_create_nonce( 'rwexec_public_booking' ),
            )
        );
    }

    public static function ajax_get_booking_times() {
        self::verify_public_request();

        $date = sanitize_text_field( wp_unslash( $_POST['reservation_date'] ?? '' ) );
        $guest_count = absint( $_POST['guest_count'] ?? 0 );
        $validation = self::validate_public_selection( $date, $guest_count );

        if ( is_wp_error( $validation ) ) {
            wp_send_json_error( array( 'message' => $validation->get_error_message() ), 400 );
        }

        $result = self::get_available_times( $date, $guest_count );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
        }

        wp_send_json_success( array( 'times' => $result ) );
    }

    public static function ajax_get_calendar_availability() {
        self::verify_public_request();

        $month = sanitize_text_field( wp_unslash( $_POST['month'] ?? '' ) );
        $guest_count = absint( $_POST['guest_count'] ?? 0 );
        $month_date = DateTimeImmutable::createFromFormat( '!Y-m', $month, RWExec_Reservations_Service::restaurant_timezone() );

        if ( false === $month_date || $month_date->format( 'Y-m' ) !== $month ) {
            wp_send_json_error( array( 'message' => 'Invalid calendar month.' ), 400 );
        }

        $today = new DateTimeImmutable( 'today', RWExec_Reservations_Service::restaurant_timezone() );
        $advance_days = max( 1, absint( get_option( 'rwexec_public_advance_days', 90 ) ) );
        $max_date = $today->modify( '+' . $advance_days . ' days' );
        $days_in_month = (int) $month_date->format( 't' );
        $days = array();

        for ( $day = 1; $day <= $days_in_month; $day++ ) {
            $date = $month_date->setDate( (int) $month_date->format( 'Y' ), (int) $month_date->format( 'm' ), $day );
            $date_string = $date->format( 'Y-m-d' );
            $state = 'available';
            $label = '';
            $times = null;

            if ( $date < $today || $date > $max_date ) {
                $state = 'unavailable';
            } else {
                $rules = RWExec_Reservations_Availability::get_rules_for_date( $date_string );
                $label = (string) ( $rules['label'] ?? '' );
                if ( 'closed' === ( $rules['status'] ?? '' ) || 'walk_ins_only' === ( $rules['status'] ?? '' ) || empty( $rules['start'] ) || empty( $rules['end'] ) ) {
                    $state = 'unavailable';
                } elseif ( $guest_count > 0 ) {
                    $max_party = max( 1, absint( get_option( 'rwexec_public_max_party_size', 12 ) ) );
                    if ( $guest_count <= $max_party ) {
                        $times = self::get_available_times( $date_string, $guest_count );
                        if ( is_wp_error( $times ) || empty( $times ) ) {
                            $state = 'full';
                        }
                    }
                }
            }

            $days[ $date_string ] = array(
                'state' => $state,
                'label' => $label,
                'available_slots' => isset( $times ) && is_array( $times ) ? count( $times ) : null,
            );
        }

        wp_send_json_success( array( 'days' => $days ) );
    }

    public static function ajax_create_reservation() {
        self::verify_public_request();

        if ( ! empty( $_POST['website'] ) ) {
            wp_send_json_error( array( 'message' => 'Unable to submit this reservation.' ), 400 );
        }

        $date = sanitize_text_field( wp_unslash( $_POST['reservation_date'] ?? '' ) );
        $time = sanitize_text_field( wp_unslash( $_POST['start_time'] ?? '' ) );
        $guest_count = absint( $_POST['guest_count'] ?? 0 );
        $name = sanitize_text_field( wp_unslash( $_POST['customer_name'] ?? '' ) );
        $email = sanitize_email( wp_unslash( $_POST['customer_email'] ?? '' ) );
        $phone = sanitize_text_field( wp_unslash( $_POST['customer_phone'] ?? '' ) );

        $validation = self::validate_public_selection( $date, $guest_count );
        if ( is_wp_error( $validation ) ) {
            wp_send_json_error( array( 'message' => $validation->get_error_message() ), 400 );
        }

        $core_fields = RWExec_Reservations_Form_Builder::get_core_fields();
        $guest_field = $core_fields['guests'];
        $time_field = $core_fields['time'];
        if ( '' === $name ) {
            wp_send_json_error( array( 'message' => 'Please enter your name.' ), 400 );
        }
        if ( ! empty( $core_fields['phone']['visible'] ) && ! empty( $core_fields['phone']['required'] ) && '' === $phone ) {
            wp_send_json_error( array( 'message' => 'Please enter your phone number.' ), 400 );
        }
        if ( ! empty( $core_fields['email']['visible'] ) && ! empty( $core_fields['email']['required'] ) && ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => 'Please enter a valid email address.' ), 400 );
        }
        if ( '' !== $email && ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => 'Please enter a valid email address.' ), 400 );
        }

        $allergies = sanitize_textarea_field( wp_unslash( $_POST['allergies'] ?? '' ) );
        if ( ! empty( $core_fields['allergies']['visible'] ) ) {
            $has_allergies = isset( $_POST['rwexec_has_allergies'] ) ? sanitize_text_field( wp_unslash( $_POST['rwexec_has_allergies'] ) ) : '';
            if ( ! empty( $core_fields['allergies']['required'] ) && ! in_array( $has_allergies, array( '0', '1' ), true ) ) {
                wp_send_json_error( array( 'message' => 'Please tell us whether you have any allergies.' ), 400 );
            }
            if ( '1' === $has_allergies && '' === trim( $allergies ) ) {
                wp_send_json_error( array( 'message' => 'Please enter your allergy requirements.' ), 400 );
            }
            if ( '1' !== $has_allergies ) {
                $allergies = '';
            }
        }

        $custom_fields = RWExec_Reservations_Form_Builder::collect_submission( $_POST );
        if ( is_wp_error( $custom_fields ) ) {
            wp_send_json_error( array( 'message' => $custom_fields->get_error_message() ), 400 );
        }

        // Recheck immediately before creation. The service serializes capacity-changing
        // writes per reservation date so simultaneous staff/public requests cannot overbook.
        $available_times = self::get_available_times( $date, $guest_count );
        if ( is_wp_error( $available_times ) ) {
            wp_send_json_error( array( 'message' => $available_times->get_error_message() ), 400 );
        }

        $valid_time = false;
        foreach ( $available_times as $available_time ) {
            if ( $available_time['value'] === substr( $time, 0, 5 ) ) {
                $valid_time = true;
                break;
            }
        }

        if ( ! $valid_time ) {
            wp_send_json_error( array( 'message' => 'That time is no longer available. Please choose another time.' ), 409 );
        }

        $marketing_consent = RWExec_Reservations_License::is_premium() && ! empty( $_POST['marketing_email_consent'] ) && '1' === (string) wp_unslash( $_POST['marketing_email_consent'] );
        $marketing_text = (string) get_option( 'rwexec_marketing_consent_text', 'I’d like to receive occasional news, offers and updates from {restaurant_name} by email.' );
        $marketing_text = str_replace( '{restaurant_name}', (string) get_option( 'rwexec_email_restaurant_name', get_bloginfo( 'name' ) ), $marketing_text );
        $marketing_label = (string) get_option( 'rwexec_marketing_consent_label', 'Keep me updated' );
        $marketing_evidence = trim( $marketing_label . ( $marketing_text ? ': ' . $marketing_text : '' ) );

        $reservation_id = RWExec_Reservations_Service::create_reservation(
            array(
                'customer_name' => $name,
                'customer_email' => $email,
                'customer_phone' => $phone,
                'reservation_date' => $date,
                'start_time' => substr( $time, 0, 5 ),
                'guest_count' => $guest_count,
                'allergies' => $allergies,
                'additional_information' => sanitize_textarea_field( wp_unslash( $_POST['additional_information'] ?? '' ) ),
                'custom_fields_json' => wp_json_encode( $custom_fields ),
                'marketing_email_consent' => $marketing_consent ? 1 : 0,
                'marketing_consent_text' => $marketing_consent ? $marketing_evidence : '',
                'marketing_consent_at' => $marketing_consent ? RWExec_Reservations_Service::restaurant_now()->format( 'Y-m-d H:i:s' ) : null,
                'status' => 'confirmed',
                'source' => 'online',
            )
        );

        if ( is_wp_error( $reservation_id ) ) {
            $http_status = 'rwexec_capacity_busy' === $reservation_id->get_error_code() ? 409 : 400;
            wp_send_json_error( array( 'message' => $reservation_id->get_error_message() ), $http_status );
        }

        wp_send_json_success( array(
            'message' => 'Your reservation is confirmed. Please check your email for confirmation.',
        ) );
    }

    private static function verify_public_request(): void {
        if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
            wp_send_json_error( array( 'message' => 'Invalid request method.' ), 405 );
        }

        $nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ?? '' ) );
        if ( ! wp_verify_nonce( $nonce, 'rwexec_public_booking' ) ) {
            wp_send_json_error( array( 'message' => 'Your booking session has expired. Please refresh the page and try again.' ), 403 );
        }
    }

    private static function validate_public_selection( string $date, int $guest_count ) {
        $date_object = DateTimeImmutable::createFromFormat( '!Y-m-d', $date, RWExec_Reservations_Service::restaurant_timezone() );
        if ( false === $date_object || $date_object->format( 'Y-m-d' ) !== $date ) {
            return new WP_Error( 'rwexec_invalid_date', 'Please choose a valid reservation date.' );
        }

        $today = new DateTimeImmutable( 'today', RWExec_Reservations_Service::restaurant_timezone() );
        $advance_days = max( 1, absint( get_option( 'rwexec_public_advance_days', 90 ) ) );
        $max_date = $today->modify( '+' . $advance_days . ' days' );

        if ( $date_object < $today || $date_object > $max_date ) {
            return new WP_Error( 'rwexec_date_out_of_range', 'That date is outside the online booking window.' );
        }

        $max_party = max( 1, absint( get_option( 'rwexec_public_max_party_size', 12 ) ) );
        if ( $guest_count < 1 || $guest_count > $max_party ) {
            return new WP_Error( 'rwexec_invalid_party_size', 'Please choose a valid party size.' );
        }

        return true;
    }

    private static function get_available_times( string $date, int $guest_count ) {
        $rules = RWExec_Reservations_Availability::get_rules_for_date( $date );

        if ( 'closed' === $rules['status'] ) {
            return new WP_Error( 'rwexec_closed', 'Online reservations are not available on this date.' );
        }

        if ( 'walk_ins_only' === $rules['status'] ) {
            return new WP_Error( 'rwexec_walk_ins_only', 'This date is currently walk-ins only.' );
        }

        if ( empty( $rules['start'] ) || empty( $rules['end'] ) ) {
            return new WP_Error( 'rwexec_no_hours', 'No online reservation hours are available for this date.' );
        }

        $interval = max( 5, absint( get_option( 'rwexec_booking_interval', 15 ) ) );
        $duration = max( 15, absint( get_option( 'rwexec_reservation_duration', 105 ) ) );
        $notice_minutes = absint( get_option( 'rwexec_public_min_notice_minutes', 60 ) );
        $timezone = RWExec_Reservations_Service::restaurant_timezone();

        $start = DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $date . ' ' . substr( $rules['start'], 0, 5 ), $timezone );
        $end = DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $date . ' ' . substr( $rules['end'], 0, 5 ), $timezone );
        if ( false === $start || false === $end || $end < $start ) {
            return new WP_Error( 'rwexec_invalid_hours', 'The booking hours for this date are invalid.' );
        }

        $now = new DateTimeImmutable( 'now', $timezone );
        $minimum_start = $now->modify( '+' . $notice_minutes . ' minutes' );
        $times = array();

        for ( $slot = $start; $slot <= $end; $slot = $slot->modify( '+' . $interval . ' minutes' ) ) {
            if ( $slot < $minimum_start ) {
                continue;
            }

            $slot_end = $slot->modify( '+' . $duration . ' minutes' );

            // Capacity is evaluated for this exact date and this exact visit window.
            // A reservation on another date, or one that does not overlap this slot,
            // cannot make the slot unavailable.
            $remaining_capacity = RWExec_Reservations_Capacity::get_remaining_capacity(
                $date,
                $slot->format( 'H:i:s' ),
                $slot_end->format( 'H:i:s' )
            );

            if ( $guest_count > $remaining_capacity ) {
                continue;
            }

            $times[] = array(
                'value' => $slot->format( 'H:i' ),
                'label' => wp_date( get_option( 'time_format' ), $slot->getTimestamp(), $timezone ),
                'remaining_capacity' => $remaining_capacity,
            );
        }

        return $times;
    }
}
