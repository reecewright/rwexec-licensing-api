<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Capacity {

    public static function get_existing_guests(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $exclude_reservation_id = 0
    ): int {
        global $wpdb;

        $table_name = $wpdb->prefix . 'rwexec_reservations';
        $active_statuses = "'confirmed','checked_in','arrived'";

        if ( $exclude_reservation_id > 0 ) {
            $sql = $wpdb->prepare(
                "SELECT COALESCE(SUM(guest_count),0)
                 FROM {$table_name}
                 WHERE reservation_date = %s
                 AND id != %d
                 AND status IN ({$active_statuses})
                 AND start_time < %s
                 AND end_time > %s",
                $reservation_date,
                $exclude_reservation_id,
                $end_time,
                $start_time
            );
        } else {
            $sql = $wpdb->prepare(
                "SELECT COALESCE(SUM(guest_count),0)
                 FROM {$table_name}
                 WHERE reservation_date = %s
                 AND status IN ({$active_statuses})
                 AND start_time < %s
                 AND end_time > %s",
                $reservation_date,
                $end_time,
                $start_time
            );
        }

        return absint( $wpdb->get_var( $sql ) );
    }

    public static function get_remaining_capacity(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $exclude_reservation_id = 0
    ): int {
        $capacity = absint( get_option( 'rwexec_online_capacity', 45 ) );
        $existing_guests = self::get_existing_guests(
            $reservation_date,
            $start_time,
            $end_time,
            $exclude_reservation_id
        );

        return max( 0, $capacity - $existing_guests );
    }

    public static function check(
        string $reservation_date,
        string $start_time,
        string $end_time,
        int $guest_count,
        int $exclude_reservation_id = 0
    ) {
        $remaining_capacity = self::get_remaining_capacity(
            $reservation_date,
            $start_time,
            $end_time,
            $exclude_reservation_id
        );

        if ( $guest_count > $remaining_capacity ) {
            return new WP_Error(
                'rwexec_capacity_exceeded',
                sprintf(
                    'This reservation would exceed the configured reservation capacity by %d guest(s).',
                    $guest_count - $remaining_capacity
                )
            );
        }

        return true;
    }
}
