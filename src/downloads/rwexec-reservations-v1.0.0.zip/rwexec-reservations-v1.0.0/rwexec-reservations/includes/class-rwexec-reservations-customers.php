<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Customers {
    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'rwexec_reservation_customers';
    }

    public static function get( int $customer_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $customer_id ) );
    }


    public static function manual_lookup( int $limit = 500 ): array {
        global $wpdb;
        $limit = max( 1, min( 1000, $limit ) );
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, customer_name, customer_email, customer_phone, staff_notes, preferences FROM ' . self::table() . ' ORDER BY last_seen_at DESC, customer_name ASC LIMIT %d',
                $limit
            )
        ) ?: array();

        return array_map(
            static function ( $row ) {
                return array(
                    'id' => (int) $row->id,
                    'name' => (string) $row->customer_name,
                    'email' => (string) $row->customer_email,
                    'phone' => (string) $row->customer_phone,
                    'has_notes' => ! empty( trim( (string) $row->staff_notes ) ) || ! empty( trim( (string) $row->preferences ) ),
                );
            },
            $rows
        );
    }

    public static function sync_from_values( array $data ): int {
        global $wpdb;
        $email = sanitize_email( $data['customer_email'] ?? '' );
        $phone = sanitize_text_field( $data['customer_phone'] ?? '' );
        $name  = sanitize_text_field( $data['customer_name'] ?? '' );
        if ( ! $email && ! $phone ) { return 0; }

        $customer = null;
        if ( $email ) {
            $customer = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE customer_email = %s ORDER BY id ASC LIMIT 1', $email ) );
        }
        if ( ! $customer && $phone ) {
            $customer = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE customer_phone = %s ORDER BY id ASC LIMIT 1', $phone ) );
        }

        $now = RWExec_Reservations_Service::restaurant_now()->format( 'Y-m-d H:i:s' );
        $consented = ! empty( $data['marketing_email_consent'] );
        $consent_at = sanitize_text_field( $data['marketing_consent_at'] ?? '' );
        $consent_text = sanitize_textarea_field( $data['marketing_consent_text'] ?? '' );
        $consent_source = sanitize_key( $data['source'] ?? $data['marketing_consent_source'] ?? '' );

        if ( $customer ) {
            $update = array(
                'customer_name' => $name ?: $customer->customer_name,
                // A manual booking may legitimately omit one contact method. Do not
                // erase a previously known email/phone from the customer record.
                'customer_email' => $email ?: (string) $customer->customer_email,
                'customer_phone' => $phone ?: (string) $customer->customer_phone,
                'last_seen_at' => $now,
                'updated_at' => $now,
            );
            // A later unchecked booking does not silently withdraw an earlier opt-in.
            // Withdrawal should be an explicit customer-record action.
            if ( $consented && $email ) {
                $update['marketing_email_consent'] = 1;
                $update['marketing_consent_at'] = $consent_at ?: $now;
                $update['marketing_consent_source'] = $consent_source ?: 'online';
                $update['marketing_consent_text'] = $consent_text;
                $update['marketing_consent_updated_at'] = $now;
            }
            $wpdb->update( self::table(), $update, array( 'id' => (int) $customer->id ) );
            return (int) $customer->id;
        }

        $wpdb->insert( self::table(), array(
            'customer_name' => $name,
            'customer_email' => $email,
            'customer_phone' => $phone,
            'staff_notes' => '',
            'preferences' => '',
            'marketing_email_consent' => ( $consented && $email ) ? 1 : 0,
            'marketing_consent_at' => ( $consented && $email ) ? ( $consent_at ?: $now ) : null,
            'marketing_consent_source' => ( $consented && $email ) ? ( $consent_source ?: 'online' ) : null,
            'marketing_consent_text' => ( $consented && $email ) ? $consent_text : '',
            'marketing_consent_updated_at' => ( $consented && $email ) ? $now : null,
            'first_seen_at' => $now,
            'last_seen_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ) );
        return (int) $wpdb->insert_id;
    }

    public static function sync_reservation( int $reservation_id ): int {
        global $wpdb;
        $r = RWExec_Reservations_Service::get_reservation( $reservation_id );
        if ( ! $r ) { return 0; }
        $customer_id = self::sync_from_values( (array) $r );
        if ( $customer_id ) {
            $wpdb->update( $wpdb->prefix . 'rwexec_reservations', array( 'customer_id' => $customer_id ), array( 'id' => $reservation_id ) );
        }
        return $customer_id;
    }

    public static function backfill(): void {
        global $wpdb;
        $rows = $wpdb->get_results( 'SELECT id, customer_name, customer_email, customer_phone, marketing_email_consent, marketing_consent_text, marketing_consent_at, source FROM ' . $wpdb->prefix . 'rwexec_reservations WHERE customer_id IS NULL OR customer_id = 0 ORDER BY id ASC' );
        foreach ( $rows ?: array() as $row ) {
            $customer_id = self::sync_from_values( (array) $row );
            if ( $customer_id ) {
                $wpdb->update( $wpdb->prefix . 'rwexec_reservations', array( 'customer_id' => $customer_id ), array( 'id' => (int) $row->id ) );
            }
        }
    }

    public static function reservations( int $customer_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . $wpdb->prefix . 'rwexec_reservations WHERE customer_id = %d ORDER BY reservation_date DESC, start_time DESC', $customer_id ) ) ?: array();
    }

    public static function stats( int $customer_id ): array {
        $reservations = self::reservations( $customer_id );
        $stats = array( 'visits'=>count($reservations), 'completed'=>0, 'no_show'=>0, 'cancelled'=>0, 'late'=>0 );
        foreach ( $reservations as $r ) {
            if ( isset( $stats[ $r->status ] ) ) { $stats[ $r->status ]++; }
            // Late arrivals counts actual arrivals only; No Shows have their own statistic.
            if ( ! empty( $r->arrived_at ) && RWExec_Reservations_Service::get_history_late_minutes( $r ) > 0 ) {
                $stats['late']++;
            }
        }
        return $stats;
    }


    public static function marketing_contacts(): array {
        global $wpdb;
        $sql = "SELECT c.*, MAX(r.reservation_date) AS last_booking FROM " . self::table() . " c LEFT JOIN " . $wpdb->prefix . "rwexec_reservations r ON r.customer_id = c.id WHERE c.marketing_email_consent = 1 AND c.customer_email <> '' GROUP BY c.id ORDER BY c.customer_name ASC";
        return $wpdb->get_results( $sql ) ?: array();
    }

    public static function record_marketing_consent( int $customer_id, string $consent_text ): bool {
        global $wpdb;
        $customer = self::get( $customer_id );
        if ( ! $customer || empty( $customer->customer_email ) ) {
            return false;
        }
        $now = RWExec_Reservations_Service::restaurant_now()->format( 'Y-m-d H:i:s' );
        return false !== $wpdb->update( self::table(), array(
            'marketing_email_consent' => 1,
            'marketing_consent_at' => $now,
            'marketing_consent_source' => 'staff_recorded',
            'marketing_consent_text' => sanitize_textarea_field( $consent_text ),
            'marketing_consent_updated_at' => $now,
            'updated_at' => $now,
        ), array( 'id' => $customer_id ) );
    }

    public static function withdraw_marketing_consent( int $customer_id ): bool {
        global $wpdb;
        return false !== $wpdb->update( self::table(), array(
            'marketing_email_consent' => 0,
            'marketing_consent_updated_at' => RWExec_Reservations_Service::restaurant_now()->format( 'Y-m-d H:i:s' ),
            'updated_at' => RWExec_Reservations_Service::restaurant_now()->format( 'Y-m-d H:i:s' ),
        ), array( 'id' => $customer_id ) );
    }

    public static function save_notes( int $customer_id, string $notes, string $preferences ): bool {
        global $wpdb;
        return false !== $wpdb->update( self::table(), array(
            'staff_notes' => sanitize_textarea_field( $notes ),
            'preferences' => sanitize_textarea_field( $preferences ),
            'updated_at' => RWExec_Reservations_Service::restaurant_now()->format( 'Y-m-d H:i:s' ),
        ), array( 'id' => $customer_id ) );
    }
}
