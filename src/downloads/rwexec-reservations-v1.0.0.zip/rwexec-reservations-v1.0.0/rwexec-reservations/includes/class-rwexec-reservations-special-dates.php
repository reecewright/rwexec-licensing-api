<?php

defined( 'ABSPATH' ) || exit;

class RWExec_Reservations_Special_Dates {

    public static function get_for_date( string $date ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'rwexec_reservation_special_dates';

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE special_date = %s",
                sanitize_text_field( $date )
            )
        );
    }

    public static function get_all(): array {
        global $wpdb;

        $table_name = $wpdb->prefix . 'rwexec_reservation_special_dates';

        return $wpdb->get_results(
            "SELECT * FROM {$table_name} ORDER BY special_date ASC"
        ) ?: array();
    }

    public static function save( array $data ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'rwexec_reservation_special_dates';
        $date = sanitize_text_field( $data['special_date'] ?? '' );
        $status = sanitize_key( $data['booking_status'] ?? 'closed' );
        $start = sanitize_text_field( $data['booking_start'] ?? '' );
        $end = sanitize_text_field( $data['booking_end'] ?? '' );
        $label = sanitize_text_field( $data['label'] ?? '' );

        $date_object = DateTimeImmutable::createFromFormat( '!Y-m-d', $date, RWExec_Reservations_Service::restaurant_timezone() );
        $date_errors = DateTimeImmutable::getLastErrors();
        if (
            ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ||
            false === $date_object ||
            ( is_array( $date_errors ) && ( $date_errors['warning_count'] > 0 || $date_errors['error_count'] > 0 ) ) ||
            $date_object->format( 'Y-m-d' ) !== $date
        ) {
            return new WP_Error( 'rwexec_invalid_special_date', 'Please choose a valid special date.' );
        }

        if ( ! in_array( $status, array( 'open', 'walk_ins_only', 'closed' ), true ) ) {
            return new WP_Error( 'rwexec_invalid_special_status', 'Please choose a valid booking status.' );
        }

        if ( 'open' === $status && ( empty( $start ) || empty( $end ) ) ) {
            return new WP_Error( 'rwexec_special_hours_required', 'Open special dates require start and end times.' );
        }

        if ( 'open' === $status ) {
            $time_pattern = '/^(?:[01]\d|2[0-3]):[0-5]\d$/';
            if ( ! preg_match( $time_pattern, substr( $start, 0, 5 ) ) || ! preg_match( $time_pattern, substr( $end, 0, 5 ) ) ) {
                return new WP_Error( 'rwexec_invalid_special_hours', 'Please enter valid start and end times.' );
            }
            $start = substr( $start, 0, 5 );
            $end = substr( $end, 0, 5 );
            if ( $end < $start ) {
                return new WP_Error( 'rwexec_invalid_special_hours', 'The special-date end time must be after the start time.' );
            }
        }

        $existing = self::get_for_date( $date );
        $now = current_time( 'mysql' );
        $row = array(
            'special_date' => $date,
            'booking_status' => $status,
            'booking_start' => 'open' === $status ? $start : null,
            'booking_end' => 'open' === $status ? $end : null,
            'label' => $label ?: null,
            'updated_at' => $now,
        );

        if ( $existing ) {
            $result = $wpdb->update( $table_name, $row, array( 'id' => (int) $existing->id ) );
        } else {
            $row['created_at'] = $now;
            $result = $wpdb->insert( $table_name, $row );
        }

        if ( false === $result ) {
            return new WP_Error( 'rwexec_special_date_save_failed', 'The special date could not be saved.' );
        }

        return true;
    }

    public static function delete( int $id ): bool {
        global $wpdb;

        if ( $id <= 0 ) {
            return false;
        }

        $table_name = $wpdb->prefix . 'rwexec_reservation_special_dates';
        return false !== $wpdb->delete( $table_name, array( 'id' => $id ), array( '%d' ) );
    }
}
